-- ============================================================
-- BoisEnergie MVP V1 — Modèles de données CMR & BL PDF
-- Format : SQL (structure) + JSON (payload) + HTML (template)
-- Version 1.0 — Juin 2025
-- ============================================================


-- ============================================================
-- PARTIE 1 : MODÈLE DE DONNÉES COMPLET — BON DE LIVRAISON
-- ============================================================

-- Requête SQL de génération du payload BL complet
-- (utilisée par le service PDF au moment de l'export)

CREATE OR REPLACE FUNCTION get_bl_payload(p_livraison_id UUID)
RETURNS JSONB AS $$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_build_object(

        -- En-tête BL
        'document', jsonb_build_object(
            'type',        'BON DE LIVRAISON',
            'numero',      l.numero_bl,
            'date_edition',TO_CHAR(NOW(), 'DD/MM/YYYY HH24:MI'),
            'statut',      l.statut
        ),

        -- Émetteur (exploitant / donneur d'ordre)
        'emetteur', jsonb_build_object(
            'raison_sociale', ae.raison_sociale,
            'siret',          ae.siret,
            'adresse',        ae.adresse,
            'code_postal',    ae.code_postal,
            'ville',          ae.ville,
            'telephone',      ae.telephone,
            'email',          ae.email
        ),

        -- Chantier d'origine
        'chantier', jsonb_build_object(
            'reference',   c.reference,
            'lot_ref',     lot.reference,
            'commune',     lot.commune,
            'essence',     l.essence,
            'certification', lot.certification
        ),

        -- Produit
        'produit', jsonb_build_object(
            'designation',   l.produit,
            'granulometrie', l.granulometrie,
            'essence',       l.essence,
            'norme',         'EN ISO 17225-4'
        ),

        -- Transporteur & véhicule
        'transport', jsonb_build_object(
            'transporteur',          at.raison_sociale,
            'siret_transporteur',    at.siret,
            'chauffeur',             uc.prenom || ' ' || uc.nom,
            'immatriculation_camion', vc.immatriculation,
            'immatriculation_remorque', COALESCE(vr.immatriculation, '—'),
            'ptac_t',                vc.ptac_t
        ),

        -- Chargement (départ)
        'chargement', jsonb_build_object(
            'lieu',              lot.commune || ' (' || COALESCE(lot.departement,'') || ')',
            'adresse_lot',       lot.commune,
            'gps_depart',        CASE WHEN l.gps_depart IS NOT NULL
                                 THEN ST_AsGeoJSON(l.gps_depart)::jsonb
                                 ELSE NULL END,
            'heure_depart',      TO_CHAR(l.heure_depart AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY HH24:MI'),
            'poids_brut_t',      l.poids_brut_depart_t,
            'tare_t',            l.tare_depart_t,
            'poids_net_t',       l.poids_net_depart_t,
            'signature_chauffeur_url', l.signature_chauffeur_url
        ),

        -- Destination & réception
        'livraison', jsonb_build_object(
            'client',            ac.raison_sociale,
            'siret_client',      ac.siret,
            'adresse_destination', l.adresse_destination,
            'gps_arrivee',       CASE WHEN l.gps_arrivee IS NOT NULL
                                 THEN ST_AsGeoJSON(l.gps_arrivee)::jsonb
                                 ELSE NULL END,
            'heure_arrivee',     TO_CHAR(l.heure_arrivee AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY HH24:MI'),
            'poids_brut_t',      l.poids_brut_arrivee_t,
            'tare_t',            l.tare_arrivee_t,
            'poids_net_t',       l.poids_net_arrivee_t,
            'ticket_bascule',    l.ticket_bascule_ref,
            'distance_km',       l.distance_km,
            'signature_client_url',  l.signature_client_url,
            'date_signature',    TO_CHAR(l.date_signature_client AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY HH24:MI')
        ),

        -- Qualité (si contrôle effectué)
        'qualite', CASE WHEN cq.id IS NOT NULL THEN
            jsonb_build_object(
                'humidite_pct',      cq.humidite_pct,
                'methode_mesure',    cq.methode_mesure,
                'granulometrie',     cq.granulometrie_constatee,
                'taux_fines_pct',    cq.taux_fines_pct,
                'pci_kwh_t',         cq.pci_estime_kwh_t,
                'conforme',          cq.conforme,
                'seuil_pct',         cq.seuil_contractuel_pct,
                'penalite_eur_t',    cq.penalite_eur_t
            )
        ELSE NULL END,

        -- Documents annexés
        'documents', (
            SELECT jsonb_agg(jsonb_build_object(
                'type', d.type, 'url', d.url_stockage
            ))
            FROM documents d
            WHERE d.ref_table = 'livraisons' AND d.ref_id = l.id
        ),

        -- CMR lié
        'cmr_numero', cmr.numero_cmr,

        -- Traçabilité
        'tracabilite', jsonb_build_object(
            'lot_reference',    lot.reference,
            'certification',    lot.certification,
            'chantier_ref',     c.reference,
            'date_exploitation', c.date_debut_reelle,
            'dechiquetage_date', d.date_dechiquetage,
            'granulometrie_prod', d.granulometrie,
            'humidite_prod_pct',  d.humidite_sortie_pct
        )

    )
    INTO v_result
    FROM livraisons l
    JOIN chantiers c     ON c.id = l.chantier_id
    JOIN lots lot        ON lot.id = c.lot_id
    JOIN acteurs ac      ON ac.id = l.client_id
    JOIN acteurs at      ON at.id = l.transporteur_id
    JOIN acteurs ae      ON ae.id = c.donneur_ordre_id  -- via utilisateurs
    LEFT JOIN utilisateurs uc ON uc.id = l.chauffeur_id
    LEFT JOIN vehicules vc    ON vc.id = l.vehicule_camion_id
    LEFT JOIN vehicules vr    ON vr.id = l.vehicule_remorque_id
    LEFT JOIN controles_qualite cq ON cq.livraison_id = l.id
    LEFT JOIN dechiquetages d      ON d.id = l.dechiquetage_id
    LEFT JOIN cmr                  ON cmr.livraison_id = l.id
    WHERE l.id = p_livraison_id;

    RETURN v_result;
END;
$$ LANGUAGE plpgsql STABLE;


-- ============================================================
-- PARTIE 2 : MODÈLE DE DONNÉES COMPLET — CMR
-- ============================================================

CREATE OR REPLACE FUNCTION get_cmr_payload(p_cmr_id UUID)
RETURNS JSONB AS $$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_build_object(

        -- En-tête CMR
        'document', jsonb_build_object(
            'type',          'LETTRE DE VOITURE INTERNATIONALE — CMR',
            'numero',        cmr.numero_cmr,
            'date_emission', TO_CHAR(cmr.created_at AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY'),
            'norme',         'Convention CMR — Genève 19/05/1956'
        ),

        -- Case 1 : Expéditeur
        'expediteur', jsonb_build_object(
            'raison_sociale', ae.raison_sociale,
            'adresse',        ae.adresse,
            'code_postal',    ae.code_postal,
            'ville',          ae.ville,
            'pays',           'France',
            'siret',          ae.siret
        ),

        -- Case 2 : Destinataire
        'destinataire', jsonb_build_object(
            'raison_sociale', ad.raison_sociale,
            'adresse',        ad.adresse,
            'code_postal',    ad.code_postal,
            'ville',          ad.ville,
            'pays',           'France',
            'siret',          ad.siret
        ),

        -- Case 3 : Lieu de livraison
        'lieu_livraison', jsonb_build_object(
            'adresse', cmr.adresse_livraison,
            'date_prevue', TO_CHAR(l.heure_arrivee AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY')
        ),

        -- Case 4 : Lieu et date de chargement
        'lieu_chargement', jsonb_build_object(
            'adresse',    cmr.adresse_chargement,
            'date',       TO_CHAR(cmr.date_chargement, 'DD/MM/YYYY'),
            'heure',      TO_CHAR(l.heure_depart AT TIME ZONE 'Europe/Paris', 'HH24:MI')
        ),

        -- Case 5 : Documents annexés
        'documents_annexes', ARRAY['Bon d''achat', 'Fiche lot ' || lot.reference,
                                   'Certificat ' || lot.certification],

        -- Case 6/7 : Marques et numéros / Nombre de colis
        'marchandise', jsonb_build_object(
            'reference_lot',  lot.reference,
            'numero_bl',      l.numero_bl,
            'nb_colis',       cmr.nb_colis,
            'emballage',      'Vrac — plaquettes forestières',
            'nature',         cmr.marchandise,
            'granulometrie',  l.granulometrie,
            'norme_produit',  'EN ISO 17225-4'
        ),

        -- Case 11 : Poids brut
        'poids', jsonb_build_object(
            'brut_kg',  ROUND((l.poids_brut_depart_t * 1000)::NUMERIC, 0),
            'tare_kg',  ROUND((l.tare_depart_t * 1000)::NUMERIC, 0),
            'net_kg',   ROUND((l.poids_net_depart_t * 1000)::NUMERIC, 0)
        ),

        -- Case 16 : Transporteur
        'transporteur', jsonb_build_object(
            'raison_sociale', atr.raison_sociale,
            'adresse',        atr.adresse,
            'code_postal',    atr.code_postal,
            'ville',          atr.ville,
            'siret',          atr.siret,
            'immatriculation_camion',   vc.immatriculation,
            'immatriculation_remorque', COALESCE(vr.immatriculation, '—')
        ),

        -- Case 13 : Instrutions expéditeur
        'instructions', cmr.instructions,

        -- Case 18 : Réserves et observations
        'reserves', jsonb_build_object(
            'expediteur',   cmr.remarques_expediteur,
            'chauffeur',    cmr.remarques_chauffeur
        ),

        -- Signatures (cases 22, 23, 24)
        'signatures', jsonb_build_object(
            'expediteur',  jsonb_build_object(
                'nom',  ae.raison_sociale,
                'date', TO_CHAR(cmr.created_at AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY'),
                'url',  cmr.signature_expediteur_url
            ),
            'transporteur', jsonb_build_object(
                'nom',  atr.raison_sociale,
                'date', TO_CHAR(l.heure_depart AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY'),
                'url',  cmr.signature_chauffeur_url
            ),
            'destinataire', jsonb_build_object(
                'nom',  ad.raison_sociale,
                'date', TO_CHAR(cmr.date_signature_dest AT TIME ZONE 'Europe/Paris', 'DD/MM/YYYY'),
                'url',  cmr.signature_destinataire_url
            )
        ),

        -- Traçabilité additionnelle (hors CMR standard)
        'tracabilite_bois', jsonb_build_object(
            'lot_reference',   lot.reference,
            'commune_origine', lot.commune,
            'certification',   lot.certification,
            'numero_certificat', lot.numero_certificat,
            'chantier_ref',    c.reference,
            'dechiquetage_id', l.dechiquetage_id
        )

    )
    INTO v_result
    FROM cmr
    JOIN livraisons l       ON l.id = cmr.livraison_id
    JOIN chantiers c        ON c.id = l.chantier_id
    JOIN lots lot           ON lot.id = c.lot_id
    JOIN acteurs ae         ON ae.id = cmr.expediteur_id
    JOIN acteurs ad         ON ad.id = cmr.destinataire_id
    JOIN acteurs atr        ON atr.id = cmr.transporteur_id
    LEFT JOIN vehicules vc  ON vc.id = l.vehicule_camion_id
    LEFT JOIN vehicules vr  ON vr.id = l.vehicule_remorque_id
    WHERE cmr.id = p_cmr_id;

    RETURN v_result;
END;
$$ LANGUAGE plpgsql STABLE;


-- ============================================================
-- PARTIE 3 : SERVICE PDF — TEMPLATE HTML (Node.js / Puppeteer)
-- Fichier : services/pdf/bl-template.html
-- ============================================================

/*
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <style>
    @page { size: A4; margin: 15mm 12mm; }
    body { font-family: Arial, sans-serif; font-size: 10pt; color: #1a1a1a; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1D9E75; padding-bottom: 8px; margin-bottom: 12px; }
    .logo-zone { font-size: 18pt; font-weight: bold; color: #1D9E75; }
    .doc-title { text-align: right; }
    .doc-title h1 { font-size: 14pt; color: #1a1a1a; margin: 0; }
    .doc-title .ref { font-size: 11pt; color: #555; }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px; }
    .box { border: 0.5pt solid #bbb; border-radius: 4px; padding: 8px 10px; }
    .box-title { font-size: 8pt; font-weight: bold; text-transform: uppercase; letter-spacing: 0.05em; color: #555; margin-bottom: 5px; }
    .field-row { display: flex; justify-content: space-between; padding: 2px 0; border-bottom: 0.3pt solid #eee; font-size: 9pt; }
    .field-row:last-child { border-bottom: none; }
    .field-key { color: #666; }
    .field-val { font-weight: bold; text-align: right; }
    .poids-section { background: #E1F5EE; border: 1pt solid #5DCAA5; border-radius: 4px; padding: 10px; text-align: center; margin: 10px 0; }
    .poids-val { font-size: 18pt; font-weight: bold; color: #085041; }
    .poids-label { font-size: 8pt; color: #0F6E56; }
    .conformite-ok { background: #E1F5EE; color: #085041; padding: 4px 10px; border-radius: 20px; font-size: 9pt; font-weight: bold; display: inline-block; }
    .conformite-nok { background: #FCEBEB; color: #A32D2D; padding: 4px 10px; border-radius: 20px; font-size: 9pt; font-weight: bold; display: inline-block; }
    .sig-box { border: 0.5pt solid #bbb; border-radius: 4px; padding: 8px; text-align: center; min-height: 60px; }
    .sig-box img { max-height: 50px; max-width: 150px; }
    .footer { border-top: 0.5pt solid #bbb; margin-top: 10px; padding-top: 6px; font-size: 8pt; color: #888; display: flex; justify-content: space-between; }
    .tracabilite { background: #F1EFE8; border-radius: 4px; padding: 8px 10px; font-size: 8pt; margin-top: 8px; }
    .badge-certif { display: inline-block; background: #EAF3DE; color: #173404; padding: 2px 8px; border-radius: 20px; font-size: 8pt; font-weight: bold; }
    table.qualite { width: 100%; border-collapse: collapse; font-size: 9pt; }
    table.qualite th { background: #f5f5f5; padding: 4px 8px; text-align: left; font-weight: bold; font-size: 8pt; border: 0.3pt solid #ddd; }
    table.qualite td { padding: 4px 8px; border: 0.3pt solid #ddd; }
  </style>
</head>
<body>

<!-- EN-TÊTE -->
<div class="header">
  <div class="logo-zone">BoisEnergie</div>
  <div class="doc-title">
    <h1>Bon de Livraison</h1>
    <div class="ref">{{document.numero}} — édité le {{document.date_edition}}</div>
  </div>
</div>

<!-- ÉMETTEUR & CLIENT -->
<div class="grid-2">
  <div class="box">
    <div class="box-title">Émetteur (fournisseur)</div>
    <div style="font-weight:bold">{{emetteur.raison_sociale}}</div>
    <div>{{emetteur.adresse}}</div>
    <div>{{emetteur.code_postal}} {{emetteur.ville}}</div>
    <div>SIRET : {{emetteur.siret}}</div>
  </div>
  <div class="box">
    <div class="box-title">Client destinataire</div>
    <div style="font-weight:bold">{{livraison.client}}</div>
    <div>{{livraison.adresse_destination}}</div>
  </div>
</div>

<!-- PRODUIT & CHANTIER -->
<div class="grid-2">
  <div class="box">
    <div class="box-title">Produit livré</div>
    <div class="field-row"><span class="field-key">Désignation</span><span class="field-val">{{produit.designation}}</span></div>
    <div class="field-row"><span class="field-key">Granulométrie</span><span class="field-val">{{produit.granulometrie}}</span></div>
    <div class="field-row"><span class="field-key">Essence</span><span class="field-val">{{produit.essence}}</span></div>
    <div class="field-row"><span class="field-key">Norme</span><span class="field-val">{{produit.norme}}</span></div>
  </div>
  <div class="box">
    <div class="box-title">Origine — Traçabilité</div>
    <div class="field-row"><span class="field-key">Lot</span><span class="field-val">{{tracabilite.lot_reference}}</span></div>
    <div class="field-row"><span class="field-key">Commune</span><span class="field-val">{{chantier.commune}}</span></div>
    <div class="field-row"><span class="field-key">Chantier</span><span class="field-val">{{chantier.reference}}</span></div>
    <div class="field-row"><span class="field-key">Déchiquetage</span><span class="field-val">{{tracabilite.dechiquetage_date}}</span></div>
    {{#if tracabilite.certification}}
    <div style="margin-top:5px"><span class="badge-certif">{{tracabilite.certification}}</span></div>
    {{/if}}
  </div>
</div>

<!-- TRANSPORT -->
<div class="box" style="margin-bottom:10px">
  <div class="box-title">Transport</div>
  <div class="grid-2">
    <div>
      <div class="field-row"><span class="field-key">Transporteur</span><span class="field-val">{{transport.transporteur}}</span></div>
      <div class="field-row"><span class="field-key">Chauffeur</span><span class="field-val">{{transport.chauffeur}}</span></div>
    </div>
    <div>
      <div class="field-row"><span class="field-key">Camion</span><span class="field-val">{{transport.immatriculation_camion}}</span></div>
      <div class="field-row"><span class="field-key">Remorque</span><span class="field-val">{{transport.immatriculation_remorque}}</span></div>
      <div class="field-row"><span class="field-key">Distance</span><span class="field-val">{{livraison.distance_km}} km</span></div>
    </div>
  </div>
</div>

<!-- PESÉES -->
<div class="grid-2">
  <div class="box">
    <div class="box-title">Chargement (départ)</div>
    <div class="field-row"><span class="field-key">Heure départ</span><span class="field-val">{{chargement.heure_depart}}</span></div>
    <div class="field-row"><span class="field-key">Poids brut</span><span class="field-val">{{chargement.poids_brut_t}} t</span></div>
    <div class="field-row"><span class="field-key">Tare</span><span class="field-val">{{chargement.tare_t}} t</span></div>
    <div class="field-row"><span class="field-key">Poids net</span><span class="field-val" style="color:#085041;font-size:11pt">{{chargement.poids_net_t}} t</span></div>
  </div>
  <div class="box">
    <div class="box-title">Réception (arrivée)</div>
    <div class="field-row"><span class="field-key">Heure arrivée</span><span class="field-val">{{livraison.heure_arrivee}}</span></div>
    <div class="field-row"><span class="field-key">Poids brut</span><span class="field-val">{{livraison.poids_brut_t}} t</span></div>
    <div class="field-row"><span class="field-key">Tare</span><span class="field-val">{{livraison.tare_t}} t</span></div>
    <div class="field-row"><span class="field-key">Ticket bascule</span><span class="field-val">{{livraison.ticket_bascule}}</span></div>
    <div class="poids-section" style="margin-top:6px;padding:6px">
      <div class="poids-val">{{livraison.poids_net_t}} t</div>
      <div class="poids-label">Poids net réceptionné</div>
    </div>
  </div>
</div>

<!-- QUALITÉ -->
{{#if qualite}}
<div class="box" style="margin-top:10px">
  <div class="box-title">Contrôle qualité</div>
  <table class="qualite">
    <tr>
      <th>Critère</th><th>Valeur</th><th>Seuil</th><th>PCI estimé</th><th>Conformité</th>
    </tr>
    <tr>
      <td>Humidité</td>
      <td>{{qualite.humidite_pct}} %</td>
      <td>≤ {{qualite.seuil_pct}} %</td>
      <td>{{qualite.pci_kwh_t}} kWh/t</td>
      <td>
        {{#if qualite.conforme}}
          <span class="conformite-ok">Conforme</span>
        {{else}}
          <span class="conformite-nok">Non conforme</span>
        {{/if}}
      </td>
    </tr>
  </table>
</div>
{{/if}}

<!-- SIGNATURES -->
<div class="grid-2" style="margin-top:10px">
  <div class="box">
    <div class="box-title">Signature chauffeur (départ)</div>
    <div class="sig-box">
      {{#if chargement.signature_chauffeur_url}}
        <img src="{{chargement.signature_chauffeur_url}}">
      {{else}}
        <div style="color:#bbb;line-height:50px">— non signée —</div>
      {{/if}}
    </div>
    <div style="font-size:8pt;color:#888;margin-top:4px">{{transport.chauffeur}}</div>
  </div>
  <div class="box">
    <div class="box-title">Signature client — réception</div>
    <div class="sig-box">
      {{#if livraison.signature_client_url}}
        <img src="{{livraison.signature_client_url}}">
      {{else}}
        <div style="color:#bbb;line-height:50px">— en attente —</div>
      {{/if}}
    </div>
    <div style="font-size:8pt;color:#888;margin-top:4px">{{livraison.client}} — {{livraison.date_signature}}</div>
  </div>
</div>

<!-- CMR RÉFÉRENCÉ -->
{{#if cmr_numero}}
<div style="font-size:8pt;color:#555;margin-top:8px;text-align:right">
  CMR associé : <b>{{cmr_numero}}</b>
</div>
{{/if}}

<!-- PIED DE PAGE -->
<div class="footer">
  <div>BoisEnergie — Filière bois énergie | app.bois-energie.app</div>
  <div>{{document.numero}} | généré le {{document.date_edition}}</div>
  <div>Page 1/1</div>
</div>

</body>
</html>
*/


-- ============================================================
-- PARTIE 4 : SERVICE PDF NODE.JS
-- Fichier : services/pdf/generate-pdf.js
-- ============================================================

/*
import puppeteer from 'puppeteer';
import Handlebars from 'handlebars';
import fs from 'fs';
import path from 'path';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';

const s3 = new S3Client({ region: process.env.AWS_REGION });

export async function generateBL(livraisonId, pool) {
  // 1. Récupérer le payload depuis PostgreSQL
  const { rows } = await pool.query(
    'SELECT get_bl_payload($1) AS payload',
    [livraisonId]
  );
  const data = rows[0].payload;

  // 2. Compiler le template Handlebars
  const templateHtml = fs.readFileSync(
    path.resolve('services/pdf/bl-template.html'), 'utf8'
  );
  const template = Handlebars.compile(templateHtml);
  const html = template(data);

  // 3. Générer le PDF avec Puppeteer
  const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle0' });
  const pdfBuffer = await page.pdf({
    format: 'A4',
    printBackground: true,
    margin: { top: '15mm', bottom: '15mm', left: '12mm', right: '12mm' }
  });
  await browser.close();

  // 4. Upload S3
  const key = `bl/${new Date().getFullYear()}/${data.document.numero}.pdf`;
  await s3.send(new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: key,
    Body: pdfBuffer,
    ContentType: 'application/pdf'
  }));

  const pdfUrl = `https://${process.env.S3_BUCKET}.s3.amazonaws.com/${key}`;

  // 5. Mettre à jour la livraison avec l'URL du PDF
  await pool.query(
    `UPDATE documents SET url_stockage = $1
     WHERE ref_table = 'livraisons' AND ref_id = $2 AND type = 'bl_pdf'`,
    [pdfUrl, livraisonId]
  );

  return { url: pdfUrl, numero: data.document.numero };
}

// Même logique pour generateCMR(cmrId, pool)
// — remplacer get_bl_payload par get_cmr_payload
// — utiliser cmr-template.html
*/

-- ============================================================
-- FIN DU FICHIER
-- ============================================================
