# BoisÉnergie — Règles de Gestion Métier
## Référentiel complet V1 · 12 domaines · 47 règles

---

## CONVENTIONS

| Notation | Signification |
|---|---|
| `RG-XXX-NNN` | Identifiant unique de règle |
| `[BLOQUANT]` | Empêche l'action si non respecté |
| `[AUTO]` | Déclenché automatiquement par le système |
| `[ALERTE]` | Génère une alerte visible sur le tableau de bord |
| `[LOG]` | Inscrit une entrée dans l'historique |

---

## 1. RÈGLES — LOT

### RG-LOT-001 · Unicité et traçabilité
**Chaque lot possède un numéro unique, un statut unique, un historique complet.**

- `numero_lot` généré automatiquement au format `LOT-AAAA-XXX` à la création `[AUTO]`
- Ce numéro est **immuable** — jamais modifiable, jamais réutilisé
- `numero_lot` est dénormalisé sur chaque BL pour traçabilité permanente `[AUTO]`
- Tout changement de statut produit une entrée dans `historiques` `[LOG]`
- L'historique est **immuable** — aucun enregistrement ne peut être supprimé

**Implémentation SQL :**
```sql
-- Contrainte d'unicité
ALTER TABLE lots ADD CONSTRAINT uq_numero_lot UNIQUE (numero_lot);
-- Séquence non recyclable
CREATE SEQUENCE lot_seq START 1 NO CYCLE;
```

---

### RG-LOT-002 · Suppression conditionnelle
**Un lot ne peut être supprimé après création d'un chantier, d'un transport, ou ajout d'un document officiel.**

| Condition | Suppression physique | Soft delete |
|---|---|---|
| Lot en statut BROUILLON, aucun enfant | ✅ Admin uniquement | ✅ |
| Visite terrain créée | ❌ | ✅ Admin uniquement |
| Chantier / opération créée | ❌ | ❌ |
| Transport créé | ❌ | ❌ |
| Document officiel joint (CMR, BL, contrat) | ❌ | ❌ |

- Documents officiels = `type IN ('cmr', 'bl', 'contrat', 'bon_achat')`
- Toute tentative de suppression interdite → erreur `422` avec message explicite `[BLOQUANT]`
- Un lot peut être passé en statut `ANNULE` à la place, avec motif obligatoire

---

### RG-LOT-003 · Transitions de statut automatiques
**Le statut évolue automatiquement selon les actions réalisées.**

| Action déclenchante | Statut résultant | Mode |
|---|---|---|
| Lot créé avec commune | `BROUILLON` | `[AUTO]` |
| GPS + propriétaire saisis | `A_VISITER` | `[AUTO]` |
| Rapport de visite soumis et signé | `VISITE_REALISEE` | `[AUTO]` |
| Verdict visite = validé | `VALIDE_EXPLOITATION` | Manuel exploitant |
| Premier chantier démarré (date_debut saisie) | `EN_EXPLOITATION` | `[AUTO]` |
| Premier tas `complet = true` | `BORD_ROUTE` | `[AUTO]` |
| Déchiquetage créé + engin immatriculé | `A_DECHIQUETER` | `[AUTO]` |
| Volume chargé validé + CMR signé | `DECHIQUETAGE_EN_COURS` | `[AUTO]` |
| CMR signé + heure départ GPS | `EN_TRANSPORT` | `[AUTO]` |
| ≥ 1 livraison validée, d'autres en cours | `PARTIELLEMENT_LIVRE` | `[AUTO]` trigger |
| Toutes livraisons validées | `LIVRE` | `[AUTO]` trigger |
| 5 conditions de clôture remplies | `CLOTURE` | Manuel exploitant |

**Toute transition invalide lève une exception PostgreSQL `[BLOQUANT]`**

---

## 2. RÈGLES — VISITE TERRAIN

### RG-VISITE-001 · Champs obligatoires
**Une visite doit obligatoirement contenir : GPS, photo, volume estimé, essence principale.**

Champs bloquants à la soumission :

| Champ | Contrainte | Erreur si absent |
|---|---|---|
| `gps_lat` / `gps_lng` | Required, précision ≥ 4 décimales | `VISITE_GPS_MANQUANT` |
| Photos | ≥ 1 photo de type `photo` liée à la visite | `VISITE_PHOTO_MANQUANTE` |
| `volume_estime` | Required, > 0 | `VISITE_VOLUME_MANQUANT` |
| `essences` | ≥ 1 entrée avec `essence` définie | `VISITE_ESSENCE_MANQUANTE` |
| `essences[].pct` | Somme ∈ [98, 102] % | `VISITE_POURCENTAGES_INVALIDES` |

**La visite ne peut pas être soumise si ces conditions ne sont pas remplies** `[BLOQUANT]`

---

### RG-VISITE-002 · Immutabilité après validation
**Une visite validée devient non modifiable sauf par administrateur ou exploitant principal.**

```
visite.validation = true
→ PATCH /visites/:id → 403 Forbidden (role: operateur, etf, chauffeur)
→ PATCH /visites/:id → 200 OK      (role: admin, exploitant)
→ Toute modification par admin/exploitant → entrée [LOG] obligatoire
```

---

### RG-VISITE-003 · Automatismes post-validation
**La validation visite peut générer automatiquement :**

```
visite.validation = true  →  [AUTO]
  1. Génération bon d'achat PDF (si lot.certification = true)
  2. Génération ordre d'exploitation PDF (brouillon pré-rempli)
  3. Notification donneur d'ordre  →  [ALERTE] niveau INFO
  4. lot.statut → VISITE_REALISEE  →  [LOG]
```

---

## 3. RÈGLES — EXPLOITATION

### RG-EXP-001 · Conditions de démarrage chantier
**Un chantier ne peut démarrer que si : lot validé, opérateurs affectés, autorisations présentes.**

```
[BLOQUANT] lot.statut MUST BE 'VALIDE_EXPLOITATION'
[BLOQUANT] chantier.entreprise_id IS NOT NULL
[BLOQUANT] COUNT(operateurs WHERE chantier_id = ?) >= 1
[BLOQUANT] visite.validation = true EXISTS pour ce lot
```

Si une condition échoue → erreur `422` avec code et message précis.

---

### RG-EXP-002 · Obligations de saisie opérateur
**Chaque opérateur doit saisir quotidiennement : production, tas, horaires, anomalies.**

Champs obligatoires dans `chantiers_operations` (relevé journalier) :

| Champ | Obligatoire | Valeur par défaut |
|---|---|---|
| `date` | Oui | Automatique |
| `tonnage_jour` | Oui | — |
| `nb_tas_crees` | Oui (si > 0 tas) | 0 |
| `meteo` | Oui | — |
| `incident` | Oui | `aucun` |
| GPS tas | Oui si `nb_tas_crees > 0` | — |

---

### RG-EXP-003 · Rappels automatiques saisie opérateur
**Si aucune saisie opérateur → rappel automatique.**

```
Heure de référence : 17h00 chaque jour ouvré

H+0   (17h00) : Aucune saisie détectée
H+12  (05h00) : Rappel SMS + notification app → opérateur  [AUTO][ALERTE INFO]
H+24  (17h00) : Toujours aucune saisie → notification ETF + exploitant  [AUTO][ALERTE WARNING]
H+48           : Alerte critique → exploitant + admin  [AUTO][ALERTE CRITIQUE]
```

Job cron : `0 17 * * 1-5` (lun-ven à 17h)

---

### RG-EXP-004 · GPS obligatoire sur les tas
**Chaque tas doit être géolocalisé.**

```
[BLOQUANT] tas.gps_lat IS NOT NULL
[BLOQUANT] tas.gps_lng IS NOT NULL
→ Si GPS non disponible : saisie manuelle autorisée
→ Champ tas.gps_source ENUM ('auto', 'manuel') tracé  [LOG]
```

---

## 4. RÈGLES — TAS

### RG-TAS-001 · Appartenance obligatoire
**Chaque tas appartient à un lot, une opération, un emplacement GPS.**

```sql
-- Contraintes FK non nullables
tas.lot_id      NOT NULL REFERENCES lots(id)
-- Contrainte GPS
CHECK (gps_lat IS NOT NULL AND gps_lng IS NOT NULL)
```

---

### RG-TAS-002 · Conditions de déchiquetabilité
**Un tas ne peut être déchiqueté si : volume vide, GPS absent, état non validé.**

```
[BLOQUANT] tas.volume_estime > 0
[BLOQUANT] tas.gps_lat IS NOT NULL AND tas.gps_lng IS NOT NULL
[BLOQUANT] tas.statut = 'pret'         -- operateur a coché "complet"
[BLOQUANT] tas.disponible = true

Erreurs métier :
  TAS_VOLUME_MANQUANT      → "Volume estimé requis avant déchiquetage"
  TAS_GPS_MANQUANT         → "GPS du tas requis avant déchiquetage"
  TAS_NON_VALIDE           → "Le tas doit être marqué complet par l'opérateur"
```

---

### RG-TAS-003 · Mise à jour automatique volume lot
**Le volume total des tas met à jour automatiquement le volume réel du lot.**

```sql
-- Trigger PostgreSQL (déjà dans schéma V2)
AFTER INSERT OR UPDATE OR DELETE ON releves_journaliers
→ UPDATE lots SET volume_reel = SUM(tonnage_t) WHERE lot_id = ?

-- Vue calculée temps réel
v_stock_bord_route :
  stock_disponible_t   = SUM(tas.volume_estime) WHERE statut = 'pret'
  stock_previsionnel_t = SUM(tas.volume_estime) WHERE statut IN ('en_cours','pret')
```

---

## 5. RÈGLES — DÉCHIQUETAGE

### RG-DECH-001 · Conditions préalables
**Le déchiquetage nécessite : lot validé, tas disponible, transport planifiable.**

```
[BLOQUANT] lot.statut IN ('BORD_ROUTE', 'A_DECHIQUETER')
[BLOQUANT] COUNT(tas WHERE statut='pret' AND lot_id=?) >= 1
[BLOQUANT] dechiquetage.immat_engin IS NOT NULL
           Format regex: /^[A-Z]{2}-\d{3}-[A-Z]{2}$/
```

---

### RG-DECH-002 · Champs obligatoires chargement
**Le chargement doit contenir : véhicule, chauffeur, CMR, heure départ.**

| Champ | Obligatoire | Validation |
|---|---|---|
| `immat_engin` | Oui | Format AA-000-AA |
| `immat_tracteur` | Oui | Format AA-000-AA |
| `chauffeur_nom` | Oui | min 2 chars |
| `cmr_numero` | Auto-généré | CMR-AAAA-XXXX |
| `heure_depart` | Oui | Avec GPS horodaté |
| `volume_charge_t` | Oui | > 0, ≤ stock_disponible + 10% |
| `granulometrie` | Oui | p45 \| p63 \| p100 |

---

### RG-DECH-003 · Automatismes validation départ
**La validation départ déclenche automatiquement :**

```
dechiquetage.valide = true  →  [AUTO]
  1. Transport créé avec cmr_reference pré-rempli
  2. Tas sélectionnés → statut = 'dechiquete'
  3. lot.statut → EN_TRANSPORT
  4. Notification chauffeur (SMS + app)         [ALERTE INFO]
  5. Notification donneur d'ordre               [ALERTE INFO]
  6. Entrée historique [LOG]
  7. PDF CMR généré et archivé automatiquement
```

---

## 6. RÈGLES — TRANSPORT

### RG-TRANS-001 · Composition obligatoire
**Chaque transport possède : chauffeur, véhicule, destination, CMR.**

```
[BLOQUANT] transport.chauffeur_nom IS NOT NULL
[BLOQUANT] transport.immat_tracteur IS NOT NULL  (format AA-000-AA)
[BLOQUANT] transport.destination_id IS NOT NULL
[BLOQUANT] transport.cmr_numero IS NOT NULL
[BLOQUANT] poids_brut_t >= poids_tare_t         (colonne GENERATED vérifie)
```

---

### RG-TRANS-002 · Confirmations chauffeur obligatoires
**Le chauffeur doit confirmer : prise de mission, départ, arrivée.**

```
Étape 1 — Prise de mission
  chauffeur ouvre l'app → confirme avoir reçu l'ordre
  → transport.statut = 'prepare' → 'confirme'  [LOG]

Étape 2 — Départ
  Signature + GPS horodaté obligatoires
  → transport.heure_depart + transport.gps_depart renseignés
  → transport.statut = 'en_route'               [LOG]

Étape 3 — Arrivée
  Chauffeur confirme arrivée physique
  → transport.heure_arrivee_reelle renseignée
  → transport.statut = 'arrive'                 [LOG]
  → Déclenchement automatique écran livraison
```

**Alerte retard `[ALERTE WARNING]` si :**
```
heure_arrivee_reelle > heure_arrivee_prevue + 2h
```

---

### RG-TRANS-003 · Contrôle GPS trajet
**Le GPS chauffeur peut être comparé au lieu prévu et au trajet attendu.**

```
À l'arrivée :
  distance(gps_livraison, destination.gps) > 5 km
  → [ALERTE CRITIQUE] GPS_NON_CONFORME
  → Notification : donneur d'ordre + transporteur + déchiqueteur

Calcul distance : formule Haversine côté API
  MAX_ECART_KM = 5  (configurable par admin)
```

---

## 7. RÈGLES — LIVRAISON

### RG-LIV-001 · Champs obligatoires
**Une livraison doit contenir : heure, lieu GPS, poids, réceptionnaire.**

| Champ | Obligatoire | Validation |
|---|---|---|
| `date_livraison` | Oui | ≤ NOW() + 1h |
| `gps_livraison_lat/lng` | Oui | Capturé auto à la saisie |
| `poids_entree` | Oui | > 0 |
| `poids_sortie` | Oui | > 0, < poids_entree |
| `receptionnaire` | Oui | min 2 chars |
| `ticket_bascule` | Oui | Unique par journée |
| `humidite` | Oui | ∈ [0, 100] |

---

### RG-LIV-002 · Alerte GPS hors zone
**Si GPS livraison hors zone → alerte critique.**

```
[AUTO][ALERTE CRITIQUE]
  distance(livraison.gps, destination.gps) > MAX_ECART_KM (défaut: 5)
  → alerte type = 'erreur_gps'
  → niveau = 'critique'
  → destinataires = ['exploitant', 'transporteur', 'admin']
  → message = "GPS livraison LOT-AAAA-XXX à Xkm de la destination prévue"
  → lot.statut NE CHANGE PAS (livraison bloquée en statut 'en_attente')
```

---

### RG-LIV-003 · Mises à jour automatiques post-pesée
**La pesée met automatiquement à jour stock, tonnage livré, tonnage restant.**

```sql
-- Trigger après INSERT livraison validée
UPDATE lots SET
  volume_total_livre = (
    SELECT COALESCE(SUM(poids_net), 0)
    FROM livraisons
    WHERE lot_id = ? AND statut = 'valide'
  )
WHERE id = ?;

-- Champs dérivés calculés (pas stockés) :
tonnage_restant   = lot.volume_estime - lot.volume_total_livre
avancement_pct    = (lot.volume_reel / lot.volume_estime) * 100
```

---

### RG-LIV-004 · Livraison partielle ou complète
**Une livraison peut être partielle ou complète.**

```
Livraison partielle :
  livraison.poids_net < transport.poids_net_t * 0.95
  → [ALERTE WARNING] ECART_POIDS_LIVRAISON
  → message = "Écart poids > 5% entre chargement et réception"

Livraison complète :
  livraison.statut = 'valide'
  → trigger auto_statut_lot évalue si lot → PARTIELLEMENT_LIVRE ou LIVRE
```

---

## 8. RÈGLES — HUMIDITÉ

### RG-HUM-001 · Sources de mesure
**Le taux d'humidité peut être estimé, mesuré, ou importé.**

| Source | Champ | Fiabilité | Modifiable |
|---|---|---|---|
| Estimation terrain | `humidite_estimee` | Faible | Oui |
| Hygromètre sonde | `humidite_reelle` | Élevée | Non après validation |
| Infrarouge | `humidite_reelle` | Élevée | Non après validation |
| Analyse laboratoire | via `documents` type `analyse_humidite` | Haute | Non |

Chaîne de mesure tracée :
```
humidite_terrain (clôture) → humidite_broyage (déchiq.) → humidite (livraison)
```

---

### RG-HUM-002 · Alerte dépassement seuil
**Si humidité > seuil contrat → alerte qualité.**

```
seuil = client.humidite_max_pct  (défaut: 35%)

livraison.humidite > seuil
→ [AUTO][ALERTE WARNING] HUMIDITE_HORS_SEUIL
→ destinataires = ['exploitant', 'chaufferie']
→ message = "Humidité X% dépasse le seuil contractuel Y%"
→ Proposition automatique d'ouverture d'un litige [ALERTE]
→ lot.statut reste 'LIVRE' — ne passe pas en CLOTURE automatiquement
```

---

## 9. RÈGLES — DOCUMENTS

### RG-DOC-001 · Horodatage automatique
**Tous les documents sont horodatés automatiquement.**

```sql
documents.created_at  DEFAULT NOW()  -- immuable
documents.uploaded_by                -- utilisateur connecté, auto
documents.fichier_url                -- URL S3 générée après upload
```
Aucun document ne peut être antidaté. `created_at` est une colonne `NOT NULL DEFAULT NOW()` sans possibilité de surcharge via l'API.

---

### RG-DOC-002 · Documents obligatoires par statut
**Certains documents deviennent obligatoires selon le statut du lot.**

| Statut du lot | Document obligatoire | Type | Bloquant pour |
|---|---|---|---|
| `VISITE_REALISEE` | ≥ 1 photo de visite | `photo` | Passage à `VALIDE_EXPLOITATION` |
| `VALIDE_EXPLOITATION` | Ordre d'exploitation signé | `ordre_exploitation` | Démarrage chantier |
| `DECHIQUETAGE_EN_COURS` | Photo du CMR | `cmr` | Validation départ |
| `EN_TRANSPORT` | CMR signé | `cmr` | Création livraison |
| `LIVRE` | Ticket bascule | `photo` ou champ texte | Validation réception |
| `CLOTURE` | BL signé | `bl` + `signature` | Clôture définitive |

```typescript
// Service de vérification (NestJS)
async checkDocumentsObligatoires(lotId: string, targetStatut: LotStatut) {
  const missing = await this.documentsService.getMissingRequired(lotId, targetStatut);
  if (missing.length > 0) {
    throw new UnprocessableEntityException({
      code: 'DOCUMENTS_OBLIGATOIRES_MANQUANTS',
      missing,
    });
  }
}
```

---

## 10. RÈGLES — ALERTES

### Types d'alertes et niveaux

| Code alerte | Type | Niveau | Déclencheur | Destinataires |
|---|---|---|---|---|
| `GPS_NON_CONFORME` | GPS | CRITIQUE | Distance > 5km destination | exploitant, transporteur, admin |
| `HUMIDITE_HORS_SEUIL` | Humidité | WARNING | humidite > seuil_contrat | exploitant, chaufferie |
| `RETARD_LIVRAISON` | Retard | WARNING | arrivée > prévue + 2h | exploitant, transporteur |
| `DOCUMENT_MANQUANT` | Document | WARNING | Document requis absent | exploitant, admin |
| `SAISIE_OPERATEUR_MANQUANTE` | Exploitation | WARNING | Pas de relevé à H+12 | opérateur, puis ETF |
| `ECART_VOLUME` | Volume | WARNING | \|réel - estimé\| > 15% | exploitant, DO |
| `ECART_POIDS_LIVRAISON` | Poids | WARNING | Écart pesée > 5% | exploitant, chaufferie |
| `TAS_PRET_NON_DECHIQUETE` | Déchiquetage | INFO | Tas prêt depuis > 5 jours | exploitant |
| `LOT_BROUILLON_INACTIF` | Lot | INFO | Brouillon > 7 jours sans action | exploitant, admin |
| `BL_NON_SIGNE` | Livraison | WARNING | BL non signé > 48h | exploitant, chaufferie |
| `LITIGE_OUVERT` | Litige | CRITIQUE | Litige créé | exploitant, admin |

### Règles de gestion des alertes

```
Alerte résolue automatiquement si :
  - GPS_NON_CONFORME → livraison validée manuellement par admin
  - SAISIE_OPERATEUR_MANQUANTE → relevé saisi avec retard
  - TAS_PRET_NON_DECHIQUETE → déchiquetage déclenché

Alerte ne peut pas être ignorée si niveau = CRITIQUE
  → obligation de traiter ou de documenter le refus (motif obligatoire)

Alerte CRITIQUE non résolue → escalade automatique vers admin à H+24
```

---

## 11. RÈGLES — HISTORIQUE

### RG-HIST-001 · Actions historisées

| Action | `action` (texte) | Données loguées |
|---|---|---|
| Changement statut lot | `STATUT_CHANGE` | `{ancien, nouveau, motif}` |
| Validation visite | `VISITE_VALIDEE` | `{visite_id, verdict}` |
| Ajout opérateur | `OPERATEUR_AFFECTE` | `{operateur_id, role}` |
| Création tas | `TAS_CREE` | `{numero_tas, gps, volume}` |
| Tas marqué complet | `TAS_COMPLETE` | `{tas_id, volume_final}` |
| Validation départ déchiquetage | `DECHIQUETAGE_VALIDE` | `{cmr, volume, immat}` |
| Signature CMR | `CMR_SIGNE` | `{cmr_numero, chauffeur, gps}` |
| Pesée réception | `PESEE_SAISIE` | `{poids_entree, poids_net, humidite}` |
| Signature BL | `BL_SIGNE` | `{bl_numero, receptionnaire}` |
| Ouverture litige | `LITIGE_OUVERT` | `{cause, valeurs}` |
| Résolution litige | `LITIGE_RESOLU` | `{resolution, accord}` |
| Clôture lot | `LOT_CLOTURE` | `{volumes_final, nb_livraisons}` |
| Annulation lot | `LOT_ANNULE` | `{motif, statut_avant}` |

**Champs systématiques sur chaque entrée :**
```typescript
{
  id, lot_id, utilisateur_id,
  action,           // code action ci-dessus
  ancienne_valeur,  // JSONB
  nouvelle_valeur,  // JSONB
  ref_type,         // objet concerné
  ref_id,           // UUID objet
  ip_adresse,       // pour audit sécurité
  created_at        // immuable
}
```

---

## 12. RÈGLES — DROITS UTILISATEURS

### Matrice complète des autorisations

| Action | Admin | Exploitant | ETF / Opérateur | Déchiqueteur | Transporteur | Chauffeur | Chaufferie |
|---|---|---|---|---|---|---|---|
| **LOTS** | | | | | | | |
| Créer un lot | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Modifier lot (données) | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Changer statut lot | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Annuler un lot | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Clôturer un lot | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **VISITES** | | | | | | | |
| Créer une visite | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Valider une visite | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Modifier visite validée | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **EXPLOITATION** | | | | | | | |
| Affecter opérateurs | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Saisir relevé journalier | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Ajouter tas | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Modifier tas | ✅ | ✅ | ✅ (propres) | ❌ | ❌ | ❌ | ❌ |
| Marquer tas complet | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **DÉCHIQUETAGE** | | | | | | | |
| Créer déchiquetage | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ |
| Valider départ chargement | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ |
| **TRANSPORT** | | | | | | | |
| Créer transport | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ❌ |
| Confirmer prise mission | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ❌ |
| Valider départ transport | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ❌ |
| Valider arrivée | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ❌ |
| **LIVRAISON** | | | | | | | |
| Saisir pesée | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ (limité) | ✅ |
| Valider réception (signer BL) | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Modifier livraison | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ (limité) | ✅ |
| Ouvrir un litige | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Résoudre un litige | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **DOCUMENTS** | | | | | | | |
| Uploader document | ✅ | ✅ | ✅ (photos) | ✅ (CMR) | ✅ (CMR) | ✅ (BL) | ✅ (BL) |
| Supprimer document | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **ALERTES** | | | | | | | |
| Voir alertes lot | ✅ | ✅ | ✅ (propres) | ✅ (propres) | ✅ (propres) | ✅ (propres) | ✅ (propres) |
| Résoudre alerte | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Ignorer alerte CRITIQUE | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **UTILISATEURS** | | | | | | | |
| Créer compte | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Modifier rôle | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Désactiver compte | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |

### Notes sur les accès "limités"

**Chauffeur — Pesée (limitée) :** peut saisir `heure_arrivee` et `gps_livraison` uniquement. Ne peut pas modifier `poids_entree`, `humidite`, `receptionnaire`.

**Chauffeur — Livraison (limitée) :** peut confirmer son arrivée et uploader la photo du ticket bascule. Ne peut pas valider la réception ni signer le BL.

**ETF / Opérateur — Tas (propres) :** peut modifier uniquement les tas qu'il a créés, et uniquement si `statut = 'en_cours'`. Un tas en statut `pret` est gelé pour l'opérateur.

---

## ANNEXE — Codes d'erreur métier

| Code | HTTP | Description |
|---|---|---|
| `LOT_STATUT_TRANSITION_INVALIDE` | 422 | Transition de statut non autorisée |
| `LOT_SUPPRESSION_INTERDITE` | 422 | Lot non supprimable (enfants présents) |
| `VISITE_GPS_MANQUANT` | 422 | GPS obligatoire sur visite |
| `VISITE_PHOTO_MANQUANTE` | 422 | ≥ 1 photo requise |
| `VISITE_POURCENTAGES_INVALIDES` | 422 | Somme essences ≠ 100% |
| `TAS_VOLUME_MANQUANT` | 422 | Volume > 0 requis pour déchiquetage |
| `TAS_GPS_MANQUANT` | 422 | GPS obligatoire sur tas |
| `TAS_NON_VALIDE` | 422 | Tas doit être marqué complet |
| `CMR_IMMAT_FORMAT_INVALIDE` | 422 | Format AA-000-AA requis |
| `GPS_NON_CONFORME` | 422 | GPS livraison hors zone autorisée |
| `CLOTURE_CONDITIONS_NON_REMPLIES` | 422 | Liste des conditions manquantes |
| `DOCUMENTS_OBLIGATOIRES_MANQUANTS` | 422 | Liste des documents requis |
| `ACCES_NON_AUTORISE` | 403 | Rôle insuffisant pour cette action |
| `VISITE_VALIDEE_NON_MODIFIABLE` | 403 | Modification par rôle non autorisé |

---

## ANNEXE — Ordre de développement (Sprints)

| Sprint | Règles prioritaires |
|---|---|
| **Sprint 1** — Création lot, dashboard, fiche lot | RG-LOT-001, RG-LOT-002, RG-LOT-003, RG-HIST-001 |
| **Sprint 2** — Visite terrain, parcelles, propriétaires | RG-VISITE-001, RG-VISITE-002, RG-VISITE-003, RG-DOC-002 |
| **Sprint 3** — Suivi chantier, tas, clôture | RG-EXP-001, RG-EXP-002, RG-EXP-003, RG-EXP-004, RG-TAS-001, RG-TAS-002, RG-TAS-003 |
| **Sprint 4** — Déchiquetage, transport, livraison | RG-DECH-001, RG-DECH-002, RG-DECH-003, RG-TRANS-001, RG-TRANS-002, RG-TRANS-003, RG-LIV-001, RG-LIV-002, RG-LIV-003, RG-LIV-004 |
| **Sprint 5** — Alertes, documents, carte GPS | RG-HUM-001, RG-HUM-002, RG-DOC-001, RG-DOC-002, Toutes alertes |

