-- ============================================================
-- BoisEnergie MVP V1 — Logique Notifications & Alertes
-- Implémentation : PostgreSQL triggers + Worker Node.js
-- Version 1.0 — Juin 2025
-- ============================================================

-- ============================================================
-- PARTIE 1 : TRIGGERS POSTGRESQL (détection des événements)
-- ============================================================

-- ------------------------------------------------------------
-- ALERTE : Humidité hors seuil au contrôle qualité
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION alerte_humidite_hors_seuil()
RETURNS TRIGGER AS $$
DECLARE
    v_livraison livraisons%ROWTYPE;
    v_chantier  chantiers%ROWTYPE;
    v_alerte_id UUID;
BEGIN
    IF NOT NEW.conforme THEN
        SELECT * INTO v_livraison FROM livraisons WHERE id = NEW.livraison_id;
        SELECT * INTO v_chantier  FROM chantiers  WHERE id = v_livraison.chantier_id;

        INSERT INTO alertes (
            type, severite, ref_table, ref_id, message, details, destinataires
        ) VALUES (
            'humidite_hors_seuil',
            CASE WHEN NEW.humidite_pct > NEW.seuil_contractuel_pct + 10
                 THEN 'critical' ELSE 'warning' END,
            'controles_qualite',
            NEW.id,
            format('Humidité %s%% dépasse le seuil contractuel %s%% — %s',
                   NEW.humidite_pct, NEW.seuil_contractuel_pct, v_livraison.numero_bl),
            jsonb_build_object(
                'livraison_id',      v_livraison.id,
                'numero_bl',         v_livraison.numero_bl,
                'humidite_mesuree',  NEW.humidite_pct,
                'seuil_contractuel', NEW.seuil_contractuel_pct,
                'ecart_pct',         ROUND((NEW.humidite_pct - NEW.seuil_contractuel_pct)::NUMERIC, 2),
                'chantier_ref',      v_chantier.reference,
                'pci_kwh_t',         NEW.pci_estime_kwh_t
            ),
            ARRAY(
                SELECT u.id FROM utilisateurs u
                WHERE u.role IN ('donneur_ordre', 'admin')
                LIMIT 10
            )
        ) RETURNING id INTO v_alerte_id;

        -- Calcul pénalité automatique (exemple : 0.50€/t par % d'écart)
        UPDATE controles_qualite
        SET penalite_eur_t = ROUND(
            (NEW.humidite_pct - NEW.seuil_contractuel_pct) * 0.5, 2
        )
        WHERE id = NEW.id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_alerte_humidite
    AFTER INSERT OR UPDATE ON controles_qualite
    FOR EACH ROW EXECUTE FUNCTION alerte_humidite_hors_seuil();

-- ------------------------------------------------------------
-- ALERTE : Écart de poids à la livraison (> 3%)
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION alerte_ecart_poids()
RETURNS TRIGGER AS $$
DECLARE
    v_ecart DECIMAL;
BEGIN
    IF NEW.poids_net_depart_t IS NOT NULL AND NEW.poids_net_arrivee_t IS NOT NULL THEN
        v_ecart := ABS(NEW.poids_net_arrivee_t - NEW.poids_net_depart_t)
                   / NULLIF(NEW.poids_net_depart_t, 0) * 100;

        IF v_ecart > 3.0 THEN
            INSERT INTO alertes (
                type, severite, ref_table, ref_id, message, details, destinataires
            ) VALUES (
                'ecart_poids',
                CASE WHEN v_ecart > 8 THEN 'critical' ELSE 'warning' END,
                'livraisons',
                NEW.id,
                format('Écart de poids de %s%% détecté — %s (départ: %st / arrivée: %st)',
                       ROUND(v_ecart::NUMERIC, 1),
                       NEW.numero_bl,
                       NEW.poids_net_depart_t,
                       NEW.poids_net_arrivee_t),
                jsonb_build_object(
                    'numero_bl',          NEW.numero_bl,
                    'poids_net_depart_t', NEW.poids_net_depart_t,
                    'poids_net_arrivee_t',NEW.poids_net_arrivee_t,
                    'ecart_pct',          ROUND(v_ecart::NUMERIC, 2)
                ),
                ARRAY(
                    SELECT u.id FROM utilisateurs u
                    WHERE u.role IN ('donneur_ordre', 'transporteur', 'admin')
                    LIMIT 10
                )
            );
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_alerte_ecart_poids
    AFTER UPDATE OF poids_brut_arrivee_t ON livraisons
    FOR EACH ROW EXECUTE FUNCTION alerte_ecart_poids();

-- ------------------------------------------------------------
-- ALERTE : Incident chantier signalé
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION alerte_incident_chantier()
RETURNS TRIGGER AS $$
DECLARE v_chantier chantiers%ROWTYPE;
BEGIN
    IF NEW.incident IS NOT NULL AND (OLD.incident IS NULL OR OLD.incident != NEW.incident) THEN
        SELECT * INTO v_chantier FROM chantiers WHERE id = NEW.chantier_id;
        INSERT INTO alertes (
            type, severite, ref_table, ref_id, message, details, destinataires
        ) VALUES (
            'incident_chantier',
            CASE WHEN NEW.type_incident IN ('accident', 'arret_meteo') THEN 'critical'
                 ELSE 'warning' END,
            'journaux_chantier',
            NEW.id,
            format('Incident "%s" signalé sur chantier %s — %s',
                   NEW.type_incident, v_chantier.reference, NEW.date_journee),
            jsonb_build_object(
                'chantier_id',    NEW.chantier_id,
                'chantier_ref',   v_chantier.reference,
                'date',           NEW.date_journee,
                'type_incident',  NEW.type_incident,
                'description',    NEW.incident
            ),
            ARRAY(
                SELECT u.id FROM utilisateurs u
                WHERE u.role IN ('donneur_ordre', 'exploitant', 'admin')
                LIMIT 10
            )
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_alerte_incident
    AFTER INSERT OR UPDATE ON journaux_chantier
    FOR EACH ROW EXECUTE FUNCTION alerte_incident_chantier();

-- ------------------------------------------------------------
-- ALERTE : Volume chantier dépassé (> 105% du commandé)
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION alerte_volume_depasse()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.volume_reel_t > NEW.volume_commande_t * 1.05 THEN
        -- Éviter les doublons : vérifier si alerte déjà ouverte
        IF NOT EXISTS (
            SELECT 1 FROM alertes
            WHERE type = 'volume_depasse'
              AND ref_table = 'chantiers'
              AND ref_id = NEW.id
              AND NOT traitee
        ) THEN
            INSERT INTO alertes (
                type, severite, ref_table, ref_id, message, details, destinataires
            ) VALUES (
                'volume_depasse',
                'info',
                'chantiers',
                NEW.id,
                format('Volume réel %st dépasse le volume commandé %st (+%s%%) — %s',
                       NEW.volume_reel_t, NEW.volume_commande_t,
                       ROUND(((NEW.volume_reel_t - NEW.volume_commande_t) / NEW.volume_commande_t * 100)::NUMERIC, 1),
                       NEW.reference),
                jsonb_build_object(
                    'chantier_ref',      NEW.reference,
                    'volume_commande_t', NEW.volume_commande_t,
                    'volume_reel_t',     NEW.volume_reel_t
                ),
                ARRAY(
                    SELECT u.id FROM utilisateurs u
                    WHERE u.role IN ('donneur_ordre', 'admin')
                    LIMIT 10
                )
            );
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_alerte_volume
    AFTER UPDATE OF volume_reel_t ON chantiers
    FOR EACH ROW EXECUTE FUNCTION alerte_volume_depasse();

-- ------------------------------------------------------------
-- ALERTE : Signature client manquante après 24h
-- (Requête cron, pas un trigger)
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION alertes_signatures_manquantes()
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER := 0;
    r RECORD;
BEGIN
    FOR r IN
        SELECT id, numero_bl, heure_arrivee
        FROM livraisons
        WHERE statut = 'livree'
          AND signature_client_url IS NULL
          AND heure_arrivee < NOW() - INTERVAL '24 hours'
          AND NOT EXISTS (
              SELECT 1 FROM alertes a
              WHERE a.type = 'signature_manquante'
                AND a.ref_id = livraisons.id
                AND NOT a.traitee
          )
    LOOP
        INSERT INTO alertes (
            type, severite, ref_table, ref_id, message, details, destinataires
        ) VALUES (
            'signature_manquante',
            'warning',
            'livraisons',
            r.id,
            format('Signature client manquante depuis %s heures — %s',
                   EXTRACT(HOUR FROM NOW() - r.heure_arrivee)::INTEGER,
                   r.numero_bl),
            jsonb_build_object(
                'numero_bl',     r.numero_bl,
                'heure_arrivee', r.heure_arrivee
            ),
            ARRAY(SELECT u.id FROM utilisateurs u WHERE u.role IN ('donneur_ordre','admin') LIMIT 5)
        );
        v_count := v_count + 1;
    END LOOP;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- ------------------------------------------------------------
-- ALERTE : Retard de livraison (cron toutes les heures)
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION alertes_retards_livraison()
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER := 0;
    r RECORD;
BEGIN
    FOR r IN
        SELECT l.id, l.numero_bl, c.date_fin_prevue, c.reference AS chantier_ref
        FROM livraisons l
        JOIN chantiers c ON c.id = l.chantier_id
        WHERE l.statut IN ('planifiee', 'en_transit')
          AND c.date_fin_prevue < CURRENT_DATE - INTERVAL '3 days'
          AND NOT EXISTS (
              SELECT 1 FROM alertes a
              WHERE a.type = 'retard_livraison'
                AND a.ref_id = l.id
                AND a.created_at > NOW() - INTERVAL '24 hours'
          )
    LOOP
        INSERT INTO alertes (
            type, severite, ref_table, ref_id, message, details, destinataires
        ) VALUES (
            'retard_livraison',
            'warning',
            'livraisons',
            r.id,
            format('Livraison %s en retard — délai prévu dépassé de %s jours (chantier %s)',
                   r.numero_bl,
                   (CURRENT_DATE - r.date_fin_prevue),
                   r.chantier_ref),
            jsonb_build_object(
                'numero_bl',      r.numero_bl,
                'chantier_ref',   r.chantier_ref,
                'date_fin_prevue',r.date_fin_prevue,
                'retard_jours',   (CURRENT_DATE - r.date_fin_prevue)
            ),
            ARRAY(SELECT u.id FROM utilisateurs u WHERE u.role IN ('donneur_ordre','exploitant','admin') LIMIT 8)
        );
        v_count := v_count + 1;
    END LOOP;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- PARTIE 2 : WORKER NODE.JS (dispatch des notifications)
-- Fichier : workers/notification-worker.js
-- ============================================================

/*
import pg from 'pg';
import nodemailer from 'nodemailer';
import webpush from 'web-push';

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

// Écouter les nouvelles alertes via NOTIFY/LISTEN PostgreSQL
const client = await pool.connect();
await client.query('LISTEN nouvelle_alerte');

client.on('notification', async (msg) => {
  const alerte = JSON.parse(msg.payload);
  await dispatchNotifications(alerte);
});

// Trigger NOTIFY dans PostgreSQL :
// CREATE OR REPLACE FUNCTION notify_nouvelle_alerte() RETURNS TRIGGER AS $$
// BEGIN
//   PERFORM pg_notify('nouvelle_alerte', row_to_json(NEW)::text);
//   RETURN NEW;
// END;
// $$ LANGUAGE plpgsql;
// CREATE TRIGGER trg_notify_alerte
//     AFTER INSERT ON alertes
//     FOR EACH ROW EXECUTE FUNCTION notify_nouvelle_alerte();

async function dispatchNotifications(alerte) {
  const { rows: destinataires } = await pool.query(
    `SELECT u.id, u.email, u.prenom, u.nom, u.role
     FROM utilisateurs u
     WHERE u.id = ANY($1::uuid[])`,
    [alerte.destinataires]
  );

  for (const user of destinataires) {
    // 1. Notification in-app
    await pool.query(
      `INSERT INTO notifications (alerte_id, utilisateur_id, canal, titre, corps)
       VALUES ($1, $2, 'app', $3, $4)`,
      [alerte.id, user.id, getTitre(alerte), getCorps(alerte, user)]
    );

    // 2. Email si sévérité warning ou critical
    if (['warning', 'critical'].includes(alerte.severite)) {
      await sendEmail(user.email, user.prenom, alerte);
    }

    // 3. SMS si critical (via Twilio / OVH SMS)
    if (alerte.severite === 'critical') {
      await sendSMS(user, alerte);
    }
  }
}

function getTitre(alerte) {
  const titres = {
    humidite_hors_seuil:   'Alerte qualité — humidité hors seuil',
    ecart_poids:           'Écart de poids détecté',
    retard_livraison:      'Retard de livraison',
    incident_chantier:     'Incident chantier',
    non_conformite_qualite:'Non-conformité qualité',
    hors_zone_gps:         'Véhicule hors zone autorisée',
    volume_depasse:        'Volume commandé dépassé',
    signature_manquante:   'Signature client manquante',
  };
  return titres[alerte.type] || 'Nouvelle alerte BoisEnergie';
}

function getCorps(alerte, user) {
  return `Bonjour ${user.prenom},\n\n${alerte.message}\n\nConnectez-vous à l'application pour traiter cette alerte.\n\nBoisEnergie`;
}

async function sendEmail(email, prenom, alerte) {
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: 587,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  await transporter.sendMail({
    from: '"BoisEnergie" <alertes@bois-energie.app>',
    to: email,
    subject: `[${alerte.severite.toUpperCase()}] ${getTitre(alerte)}`,
    text: getCorps(alerte, { prenom }),
    html: `<p><b>${alerte.message}</b></p><p><a href="https://app.bois-energie.app/alertes/${alerte.id}">Voir dans l'application →</a></p>`
  });
}
*/

-- ============================================================
-- PARTIE 3 : CRON JOBS (pg_cron ou worker externe)
-- ============================================================

-- Installer pg_cron : CREATE EXTENSION pg_cron;

-- Vérification signatures manquantes — toutes les heures
SELECT cron.schedule(
    'alertes-signatures-manquantes',
    '0 * * * *',
    $$SELECT alertes_signatures_manquantes()$$
);

-- Vérification retards livraison — toutes les 6 heures
SELECT cron.schedule(
    'alertes-retards-livraison',
    '0 */6 * * *',
    $$SELECT alertes_retards_livraison()$$
);

-- ============================================================
-- PARTIE 4 : MATRICE DES NOTIFICATIONS
-- ============================================================

/*
┌─────────────────────────────┬────────────────┬──────────────┬────────────────┬──────────────┬───────────────┐
│ Événement                   │ Donneur d'ordre│ Exploitant   │ Opérateur      │ Transporteur │ Client chauff.│
├─────────────────────────────┼────────────────┼──────────────┼────────────────┼──────────────┼───────────────┤
│ Chantier créé (OE émis)     │ App            │ App + Email  │ App + Email    │ —            │ —             │
│ Incident chantier           │ App + Email    │ App + Email  │ —              │ —            │ —             │
│ Accident / Arrêt critique   │ App+Email+SMS  │ App+Email+SMS│ —              │ —            │ —             │
│ Volume commandé dépassé     │ App + Email    │ App          │ —              │ —            │ —             │
│ Chantier clôturé            │ App + Email    │ App          │ App            │ —            │ —             │
│ BL créé / en transit        │ —              │ App          │ —              │ App + Email  │ App           │
│ Livraison arrivée           │ App            │ App          │ —              │ App          │ App + Email   │
│ Signature client manquante  │ App + Email    │ App          │ —              │ App          │ Email         │
│ Écart poids > 3%            │ App + Email    │ App + Email  │ —              │ App + Email  │ App           │
│ Humidité hors seuil         │ App + Email    │ App          │ —              │ —            │ App + Email   │
│ Non-conformité critique     │ App+Email+SMS  │ App + Email  │ —              │ —            │ App+Email+SMS │
│ Retard > 3 jours            │ App + Email    │ App + Email  │ —              │ App          │ App           │
└─────────────────────────────┴────────────────┴──────────────┴────────────────┴──────────────┴───────────────┘
*/

-- ============================================================
-- PARTIE 5 : ENDPOINT WEBHOOKS (intégrations tierces)
-- ============================================================

CREATE TABLE webhooks (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    url         TEXT NOT NULL,
    secret      TEXT NOT NULL,
    events      TEXT[] NOT NULL,
    -- ex: ['humidite_hors_seuil', 'livraison_signee', 'chantier_cloture']
    actif       BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Payload webhook (envoyé en POST vers l'URL configurée) :
/*
{
  "event": "humidite_hors_seuil",
  "timestamp": "2025-08-17T09:15:42Z",
  "alerte": {
    "id": "uuid",
    "severite": "warning",
    "message": "Humidité 38% dépasse le seuil 35% — BL-2025-0042",
    "details": { ... }
  }
}
Signature HMAC-SHA256 dans header : X-BoisEnergie-Signature: sha256=...
*/
