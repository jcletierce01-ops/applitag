# BoisEnergie MVP V1 — Dossier technique complet
## Version 1.0 — Juin 2025

---

## Contenu du dossier

| Fichier | Description | Lignes |
|---------|-------------|--------|
| `01_schema_postgresql.sql` | Schéma complet PostgreSQL | ~500 |
| `02_api_rest_specs.md` | Specs API REST (endpoints + payloads JSON) | ~400 |
| `03_notifications_alertes.sql` | Triggers, alertes, cron jobs, matrice de notification | ~350 |
| `04_modeles_cmr_bl_pdf.sql` | Modèles données CMR + BL + template HTML + service Node.js | ~450 |

---

## Architecture technique recommandée

```
Frontend (mobile + web)
  React Native (iOS/Android) + Next.js (web admin)
         │
         ▼
API REST  ──  Node.js / Fastify
  Authentication JWT
  Validation Zod
  Upload S3 (photos, PDFs, signatures)
         │
         ▼
PostgreSQL 15
  PostGIS (GPS)
  pg_cron (jobs planifiés)
  LISTEN/NOTIFY (alertes temps réel)
         │
    ┌────┴────┐
    ▼         ▼
Worker       Storage
Node.js      S3 / Cloudflare R2
(emails,     (photos, PDFs, signatures)
 SMS, push)
```

---

## Tables principales (01_schema_postgresql.sql)

| Table | Rôle |
|-------|------|
| `acteurs` | Toutes les organisations (clients, transporteurs, exploitants…) |
| `utilisateurs` | Comptes applicatifs avec rôles |
| `lots` | Parcelles forestières avec GPS PostGIS |
| `visites_terrain` | Rapports de visite + essences |
| `chantiers` | Ordres d'exploitation (avec transitions de statut contrôlées) |
| `journaux_chantier` | Saisie quotidienne terrain (tonnage, météo, incidents) |
| `tas` | Stocks sur parcelle géolocalisés |
| `dechiquetages` | Sessions de broyage |
| `livraisons` | Bons de livraison (BL) avec pesées et signatures |
| `controles_qualite` | Mesures humidité, PCI calculé, conformité |
| `cmr` | Lettres de voiture |
| `couts_chantier` | Structure de coûts pour rentabilité |
| `alertes` | Alertes métier avec destinataires |
| `notifications` | Canal de diffusion (app / email / SMS) |
| `documents` | Fichiers attachés (photos, PDFs, signatures) |

### Contraintes de transition de statut

```
lots :     prospection → disponible → ordre_emis → en_exploitation → cloture
chantiers: planifie → en_cours → suspendu ↔ en_cours → cloture
                                                      ↘ annule
livraisons: planifiee → en_transit → livree → signee
```

---

## Endpoints API (02_api_rest_specs.md)

| Module | Endpoints |
|--------|-----------|
| Auth | POST /auth/login, GET /auth/me |
| Lots | GET/POST /lots, GET/PATCH /lots/:id, POST /lots/:id/photos |
| Visites | GET/POST /lots/:id/visites |
| Chantiers | GET/POST /chantiers, PATCH statut, POST journal, POST tas, POST cloture |
| Déchiquetage | POST /chantiers/:id/dechiquetages |
| Livraisons | GET/POST /livraisons, PATCH départ/arrivée/signature, GET PDF |
| Qualité | POST/GET /livraisons/:id/controle-qualite |
| Stock | GET /stock, GET /stock/mouvements |
| Alertes | GET /alertes, PATCH /alertes/:id/traiter |
| Reporting | GET dashboard, rentabilité, export Excel |

---

## Alertes automatiques (03_notifications_alertes.sql)

| Alerte | Déclencheur | Sévérité |
|--------|------------|---------|
| `humidite_hors_seuil` | Trigger INSERT controles_qualite | warning/critical |
| `ecart_poids` | Trigger UPDATE livraisons (arrivée) | warning/critical |
| `incident_chantier` | Trigger INSERT/UPDATE journaux_chantier | warning/critical |
| `volume_depasse` | Trigger UPDATE chantiers (volume_reel_t) | info |
| `signature_manquante` | Cron toutes les heures | warning |
| `retard_livraison` | Cron toutes les 6 heures | warning |

**Canaux** : in-app, email (Nodemailer/SMTP), SMS (Twilio), webhooks HMAC.

---

## Documents PDF (04_modeles_cmr_bl_pdf.sql)

### Bon de Livraison (BL)
- Fonction SQL `get_bl_payload(uuid)` → JSON complet
- Template HTML Handlebars (A4, sections : émetteur, produit, transport, pesées, qualité, signatures, traçabilité)
- Génération via Puppeteer → upload S3

### CMR
- Fonction SQL `get_cmr_payload(uuid)` → JSON au format Convention CMR (Genève 1956)
- Cases 1-24 de la CMR internationale renseignées
- Signatures électroniques (expéditeur, chauffeur, destinataire)

### Stack PDF recommandée
```
Puppeteer + Handlebars → S3/Cloudflare R2
Alternatives : html-pdf, @react-pdf/renderer, WeasyPrint (Python)
```

---

## Variables d'environnement requises

```env
DATABASE_URL=postgresql://user:pass@host:5432/bois_energie
JWT_SECRET=...
JWT_EXPIRES_IN=30d

S3_BUCKET=bois-energie-docs
AWS_REGION=eu-west-3
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...

SMTP_HOST=smtp.mailgun.org
SMTP_USER=...
SMTP_PASS=...

TWILIO_ACCOUNT_SID=...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM=+33...
```

---

## Ordre d'installation PostgreSQL

```sql
1. CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
2. CREATE EXTENSION IF NOT EXISTS postgis;
3. CREATE EXTENSION IF NOT EXISTS pg_trgm;
4. CREATE EXTENSION IF NOT EXISTS pg_cron;   -- si disponible
5. Exécuter 01_schema_postgresql.sql
6. Exécuter 03_notifications_alertes.sql (triggers + crons)
```
