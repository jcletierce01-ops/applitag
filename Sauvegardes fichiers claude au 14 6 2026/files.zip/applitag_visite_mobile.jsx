// ============================================================
// APPLITAG MOBILE — Visite terrain
// 6 étapes · GPS · Photos · Essences · Contraintes · Accès
// Boutons 56px · Scroll natif · API Railway
// ============================================================

import { useState, useCallback } from "react";

const API = "https://applitag-api-production.up.railway.app";

const C = {
  green:"#1D9E75", greenL:"#E1F5EE", greenD:"#085041",
  blue:"#185FA5",  blueL:"#E6F1FB",  blueD:"#042C53",
  amber:"#BA7517", amberL:"#FAEEDA", amberD:"#412402",
  red:"#A32D2D",   redL:"#FCEBEB",
  purple:"#534AB7",purpleL:"#EEEDFE",
  brown:"#8B6914", brownL:"#F1EFE8",
  bg:"#F5F4F1", bg2:"#ECEAE6",
  bd:"#DDDBD5", bd2:"#C8C5BE",
  tx:"#1A1A18", tx2:"#5A5955", tx3:"#9A9892",
  sb:"#111",
};

const BTN_H = 56;
const INPUT_H = 52;
const FONT_INPUT = 16;
const PADDING = 16;

const uid = () => Math.random().toString(36).slice(2,9);
const nowISO = () => new Date().toISOString();
const todayS = () => new Date().toISOString().slice(0,10);

// ── ATOMS ─────────────────────────────────────────────────────

const BigBtn = ({onClick,bg=C.green,color="#fff",children,disabled,icon,style={}}) => (
  <button onClick={disabled?undefined:onClick} style={{
    width:"100%",height:BTN_H,borderRadius:14,
    background:disabled?C.bg2:bg,color:disabled?C.tx3:color,
    border:"none",fontFamily:"inherit",fontSize:16,fontWeight:600,
    display:"flex",alignItems:"center",justifyContent:"center",gap:10,
    cursor:disabled?"not-allowed":"pointer",opacity:disabled?.5:1,
    WebkitTapHighlightColor:"transparent",...style,
  }}>
    {icon&&<span style={{fontSize:22}}>{icon}</span>}
    {children}
  </button>
);

const MInput = ({label,value,onChange,placeholder,type="text",required,error,hint,big}) => (
  <div style={{marginBottom:14}}>
    <div style={{fontSize:13,fontWeight:600,color:error?C.red:C.tx2,marginBottom:5,
      display:"flex",justifyContent:"space-between"}}>
      <span>{label}{required&&<span style={{color:"#E24B4A"}}> *</span>}</span>
      {hint&&<span style={{fontWeight:400,color:C.tx3,fontSize:12}}>{hint}</span>}
    </div>
    {big ? (
      <textarea value={value} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder} rows={3}
        style={{width:"100%",padding:"14px",borderRadius:12,resize:"none",
          border:`1.5px solid ${error?C.red:C.bd}`,
          fontSize:FONT_INPUT,fontFamily:"inherit",lineHeight:1.5,
          background:"#fff",color:C.tx,outline:"none"}}/>
    ) : (
      <input value={value} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder} type={type}
        style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
          border:`1.5px solid ${error?C.red:C.bd}`,
          fontSize:FONT_INPUT,fontFamily:"inherit",
          background:"#fff",color:C.tx,outline:"none"}}/>
    )}
    {error&&<div style={{fontSize:12,color:C.red,marginTop:4}}>⚠ {error}</div>}
  </div>
);

const MSelect = ({label,value,onChange,options,required,error}) => (
  <div style={{marginBottom:14}}>
    <div style={{fontSize:13,fontWeight:600,color:error?C.red:C.tx2,marginBottom:5}}>
      {label}{required&&<span style={{color:"#E24B4A"}}> *</span>}
    </div>
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
        border:`1.5px solid ${error?C.red:C.bd}`,fontSize:FONT_INPUT,
        fontFamily:"inherit",background:"#fff",color:C.tx,outline:"none",
        appearance:"none",paddingRight:40,
        backgroundImage:"url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%239A9892' d='M6 8L1 3h10z'/%3E%3C/svg%3E\")",
        backgroundRepeat:"no-repeat",backgroundPosition:"right 14px center",
      }}>
      {options.map(([v,l])=><option key={v} value={v}>{l}</option>)}
    </select>
    {error&&<div style={{fontSize:12,color:C.red,marginTop:4}}>⚠ {error}</div>}
  </div>
);

const MSlider = ({label,value,onChange,min,max,step=1,unit,color=C.green}) => (
  <div style={{marginBottom:14}}>
    <div style={{display:"flex",justifyContent:"space-between",
      fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
      <span>{label}</span>
      <span style={{color,fontSize:16,fontWeight:700}}>{value}{unit}</span>
    </div>
    <input type="range" min={min} max={max} step={step} value={value}
      onChange={e=>onChange(parseFloat(e.target.value))}
      style={{width:"100%",height:8,accentColor:color}}/>
    <div style={{display:"flex",justifyContent:"space-between",
      fontSize:11,color:C.tx3,marginTop:4}}>
      <span>{min}{unit}</span><span>{max}{unit}</span>
    </div>
  </div>
);

// GPS
const GpsWidget = ({value,onChange,required}) => {
  const [loading,setLoading] = useState(false);
  const capture = () => {
    setLoading(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => {
          onChange({lat:pos.coords.latitude,lng:pos.coords.longitude,
            accuracy:pos.coords.accuracy,source:"gps"});
          setLoading(false);
        },
        () => {
          onChange({lat:47.98+(Math.random()-.5)*.02,
            lng:3.09+(Math.random()-.5)*.02,source:"sim"});
          setLoading(false);
        },
        {enableHighAccuracy:true,timeout:10000}
      );
    } else {
      onChange({lat:47.98,lng:3.09,source:"sim"});
      setLoading(false);
    }
  };
  if (value) return (
    <div style={{background:C.greenL,borderRadius:12,padding:"14px",
      marginBottom:14,border:`1.5px solid ${C.green}`}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:13,color:C.greenD,fontWeight:600,marginBottom:3}}>
            📍 {value.source==="gps"?"GPS précis capturé":"Position approximative"}
          </div>
          <div style={{fontFamily:"monospace",fontSize:13,color:C.greenD}}>
            {value.lat.toFixed(5)}°N<br/>{value.lng.toFixed(5)}°E
          </div>
          {value.accuracy&&(
            <div style={{fontSize:11,color:C.tx3,marginTop:3}}>
              Précision : ±{Math.round(value.accuracy)}m
            </div>
          )}
        </div>
        <button onClick={()=>onChange(null)} style={{
          background:"rgba(8,80,65,.15)",border:"none",color:C.greenD,
          cursor:"pointer",fontSize:20,padding:8,borderRadius:8,
          WebkitTapHighlightColor:"transparent",
        }}>✕</button>
      </div>
    </div>
  );
  return (
    <div style={{marginBottom:14}}>
      <BigBtn onClick={capture} bg={loading?C.bg2:C.greenL}
        color={loading?C.tx3:C.greenD} icon={loading?"":"📍"}>
        {loading?"Localisation en cours…":"Capturer GPS de la parcelle"}
      </BigBtn>
      {required&&<div style={{fontSize:12,color:C.amber,marginTop:4,textAlign:"center"}}>
        ⚠ GPS obligatoire pour valider la visite
      </div>}
    </div>
  );
};

// Toggle check item
const CheckItem = ({checked,onChange,label,sub,warn}) => (
  <div onClick={()=>onChange(!checked)} style={{
    display:"flex",alignItems:"flex-start",gap:12,
    padding:"12px 0",borderBottom:`0.5px solid ${C.bd}`,
    cursor:"pointer",WebkitTapHighlightColor:"transparent",
  }}>
    <div style={{
      width:28,height:28,borderRadius:8,flexShrink:0,marginTop:1,
      border:`2px solid ${checked?(warn?C.amber:C.green):C.bd2}`,
      background:checked?(warn?C.amber:C.green):"#fff",
      display:"flex",alignItems:"center",justifyContent:"center",
      transition:"all .15s",
    }}>
      {checked&&<span style={{color:"#fff",fontSize:16,lineHeight:1}}>✓</span>}
    </div>
    <div style={{flex:1}}>
      <div style={{fontSize:15,fontWeight:checked?400:500,
        color:checked?C.tx2:C.tx}}>{label}</div>
      {sub&&<div style={{fontSize:12,color:C.tx3,marginTop:2}}>{sub}</div>}
    </div>
  </div>
);

// Photos
const PhotosWidget = ({photos,onChange,required=2}) => {
  const addPhoto = (type) => {
    const emojis = {face:"📷",profil:"📸",zone:"🌳",acces:"🛤️",autre:"🖼️"};
    onChange([...photos,{
      id:uid(),type,
      emoji:emojis[type]||"📷",
      capturedAt:nowISO(),
    }]);
  };
  return (
    <div>
      <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:10}}>
        {photos.map(p=>(
          <div key={p.id} style={{position:"relative"}}>
            <div style={{width:72,height:72,borderRadius:12,
              background:C.greenL,border:`1.5px solid ${C.green}`,
              display:"flex",flexDirection:"column",alignItems:"center",
              justifyContent:"center",fontSize:26}}>
              {p.emoji}
              <div style={{fontSize:9,color:C.greenD,marginTop:3}}>{p.type}</div>
            </div>
            <button onClick={()=>onChange(photos.filter(x=>x.id!==p.id))}
              style={{position:"absolute",top:-6,right:-6,
                width:20,height:20,borderRadius:"50%",
                background:C.red,color:"#fff",border:"2px solid #fff",
                cursor:"pointer",fontSize:10,fontFamily:"inherit",
                display:"flex",alignItems:"center",justifyContent:"center",
                WebkitTapHighlightColor:"transparent",
              }}>✕</button>
          </div>
        ))}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:8}}>
        {[["face","📷 Face"],["profil","📸 Profil"],["zone","🌳 Zone"],
          ["acces","🛤️ Accès"],["autre","🖼️ Autre"]].map(([type,label])=>(
          <button key={type} onClick={()=>addPhoto(type)} style={{
            height:44,borderRadius:10,border:`1px solid ${C.bd}`,
            background:"#fff",cursor:"pointer",fontFamily:"inherit",
            fontSize:11,color:C.tx2,display:"flex",alignItems:"center",
            justifyContent:"center",gap:4,
            WebkitTapHighlightColor:"transparent",
          }}>{label}</button>
        ))}
      </div>
      <BigBtn onClick={()=>addPhoto("face")}
        bg="#111" color="#fff" icon="📷">
        Prendre une photo
      </BigBtn>
      <div style={{fontSize:12,color:photos.length>=required?C.greenD:C.amber,
        textAlign:"center",marginTop:6}}>
        {photos.length}/{required} photos minimum
        {photos.length>=required?" ✓":""}
      </div>
    </div>
  );
};

// Essence editor
const EssenceEditor = ({essences,onChange}) => {
  const LISTE = [
    ["peuplier","🌾","Peuplier"],["chene","🌳","Chêne"],
    ["hetre","🌲","Hêtre"],["charme","🌿","Charme"],
    ["frene","🍃","Frêne"],["bouleau","🪵","Bouleau"],
    ["resineux","🎄","Résineux"],["melange","🌳","Mélange"],
  ];
  const total = essences.reduce((s,e)=>s+e.pct,0);
  const addEssence = () => {
    const used = new Set(essences.map(e=>e.id));
    const next = LISTE.find(([v])=>!used.has(v));
    if (!next) return;
    const remaining = Math.max(0,100-total);
    onChange([...essences,{id:next[0],emoji:next[1],label:next[2],pct:remaining}]);
  };
  return (
    <div>
      {essences.map((e,i)=>(
        <div key={e.id} style={{background:C.bg2,borderRadius:12,
          padding:"12px 14px",marginBottom:8}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
            <span style={{fontSize:22}}>{e.emoji}</span>
            <select value={e.id} onChange={ev=>{
              const found = LISTE.find(([v])=>v===ev.target.value);
              onChange(essences.map((x,j)=>j===i?{...x,id:ev.target.value,
                emoji:found?.[1]||"🌳",label:found?.[2]||""}:x));
            }} style={{flex:1,height:44,padding:"0 10px",borderRadius:9,
              border:`1px solid ${C.bd}`,fontSize:14,fontFamily:"inherit",
              background:"#fff",outline:"none"}}>
              {LISTE.map(([v,em,l])=><option key={v} value={v}>{em} {l}</option>)}
            </select>
            <button onClick={()=>onChange(essences.filter((_,j)=>j!==i))}
              style={{width:36,height:36,borderRadius:8,background:C.redL,
                color:C.red,border:"none",cursor:"pointer",fontSize:18,
                WebkitTapHighlightColor:"transparent",}}>✕</button>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <input type="range" min={1} max={100} value={e.pct}
              onChange={ev=>onChange(essences.map((x,j)=>j===i?{...x,pct:parseInt(ev.target.value)}:x))}
              style={{flex:1,accentColor:C.green}}/>
            <div style={{width:48,textAlign:"center",fontWeight:700,
              fontSize:16,color:C.green}}>{e.pct}%</div>
          </div>
        </div>
      ))}
      <div style={{display:"flex",justifyContent:"space-between",
        alignItems:"center",marginTop:4}}>
        <button onClick={addEssence} style={{
          height:44,padding:"0 16px",borderRadius:10,
          background:C.greenL,color:C.greenD,border:"none",
          cursor:"pointer",fontFamily:"inherit",fontSize:14,fontWeight:500,
          WebkitTapHighlightColor:"transparent",
        }}>+ Ajouter une essence</button>
        <div style={{fontSize:13,fontWeight:600,
          color:Math.abs(total-100)<=1?C.greenD:C.red}}>
          Σ {total}% {Math.abs(total-100)>1&&"⚠ ≠ 100%"}
        </div>
      </div>
    </div>
  );
};

// ── STEPS ─────────────────────────────────────────────────────
const STEPS = [
  {id:"gps",     label:"GPS",        icon:"📍", color:C.green},
  {id:"photos",  label:"Photos",     icon:"📷", color:C.blue},
  {id:"essences",label:"Essences",   icon:"🌿", color:C.green},
  {id:"volumes", label:"Volumes",    icon:"📏", color:C.amber},
  {id:"contraintes",label:"Terrain", icon:"⚠️", color:C.red},
  {id:"acces",   label:"Accès",      icon:"🚛", color:C.brown},
];

// ── FORMULAIRE VISITE ─────────────────────────────────────────
const FormulaireVisite = ({lot,onBack,onSaved,toast}) => {
  const [step,    setStep]    = useState(0);
  const [gps,     setGps]     = useState(null);
  const [photos,  setPhotos]  = useState([]);
  const [essences,setEssences]= useState([
    {id:"peuplier",emoji:"🌾",label:"Peuplier",pct:100}
  ]);
  const [volumeT, setVolumeT] = useState(100);
  const [surfaceHa,setSurface]= useState(5);
  const [dateLimite,setDateL] = useState("");
  const [observations,setObs] = useState("");
  const [contraintes,setCont] = useState({
    ligneEDF:false, telecom:false, penteForte:false,
    zoneHumide:false, voisinage:false, accesDifficile:false,
    routeLimitee:false, natura2000:false, remanents:false,
  });
  const [accesCamion,setAcces] = useState("praticable");
  const [largeurAcces,setLarg] = useState(4);
  const [distancePlateforme,setDist] = useState(500);
  const [saving, setSaving]   = useState(false);

  // Validation par étape
  const stepValid = {
    0: !!gps,
    1: photos.length >= 2,
    2: essences.length>0 && Math.abs(essences.reduce((s,e)=>s+e.pct,0)-100)<=1,
    3: volumeT>0,
    4: true,
    5: true,
  };

  const allValid = Object.values(stepValid).every(Boolean);

  const handleSave = async () => {
    if (!allValid) { toast("Compléter toutes les étapes","warn"); return; }
    setSaving(true);
    const visite = {
      id:uid(), lotId:lot.id, lotNumero:lot.numero,
      date:todayS(),
      gps, photos,
      essences, volumeEstimeT:volumeT,
      surfaceHa, dateLimite,
      observations,
      contraintes,
      accesCamion, largeurAcces, distancePlateforme,
      statut:"validee",
      createdAt:nowISO(),
    };
    try {
      // API — endpoint visite (à créer)
      toast("Visite validée ✓ — lot prêt à exploiter");
      onSaved(visite);
    } catch(e) {
      toast("Visite sauvegardée en local","warn");
      onSaved(visite);
    }
    setSaving(false);
  };

  const currentStep = STEPS[step];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      {/* Header step */}
      <div style={{background:currentStep.color,color:"#fff",
        padding:"12px 16px 10px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.2)",
            border:"none",color:"#fff",width:36,height:36,borderRadius:9,
            cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",
            justifyContent:"center",WebkitTapHighlightColor:"transparent",}}>‹</button>
          <div style={{fontSize:16,fontWeight:600}}>
            {currentStep.icon} {currentStep.label}
          </div>
          <div style={{marginLeft:"auto",fontSize:12,opacity:.75}}>
            {step+1}/{STEPS.length}
          </div>
        </div>
        {/* Barre progression */}
        <div style={{display:"flex",gap:4}}>
          {STEPS.map((s,i)=>(
            <div key={s.id} onClick={()=>i<step&&setStep(i)} style={{
              flex:1,height:4,borderRadius:2,
              background:i<=step?"rgba(255,255,255,.9)":"rgba(255,255,255,.25)",
              cursor:i<step?"pointer":"default",transition:"background .2s",
            }}/>
          ))}
        </div>
      </div>

      {/* Contenu */}
      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:90}}>

        {/* ÉTAPE 1 — GPS */}
        {step===0&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Capturez la position GPS de la parcelle à visiter.
              Restez sur la parcelle pour une meilleure précision.
            </div>
            <GpsWidget value={gps} onChange={setGps} required/>
            {gps&&(
              <div style={{background:C.greenL,borderRadius:12,padding:14,
                marginTop:8,fontSize:13,color:C.greenD,lineHeight:1.7}}>
                ✅ Position enregistrée. Cette coordonnée sera attachée
                définitivement à la visite et au lot créé.
              </div>
            )}
            <div style={{marginTop:16}}>
              <MInput label="Lot / Chantier" value={lot.numero}
                onChange={()=>{}} hint="automatique"/>
              <MInput label="Date de visite" value={todayS()}
                onChange={()=>{}} hint="automatique"/>
            </div>
          </div>
        )}

        {/* ÉTAPE 2 — PHOTOS */}
        {step===1&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Minimum 2 photos obligatoires. Photographiez la parcelle,
              les accès et les zones sensibles.
            </div>
            <PhotosWidget photos={photos} onChange={setPhotos} required={2}/>
          </div>
        )}

        {/* ÉTAPE 3 — ESSENCES */}
        {step===2&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Indiquez la composition en essences de la parcelle.
              Total = 100%.
            </div>
            <EssenceEditor essences={essences} onChange={setEssences}/>
          </div>
        )}

        {/* ÉTAPE 4 — VOLUMES */}
        {step===3&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Estimez les volumes disponibles et la surface de la parcelle.
            </div>
            <MSlider label="Volume estimé" value={volumeT} onChange={setVolumeT}
              min={10} max={2000} step={10} unit=" t" color={C.amber}/>
            <MSlider label="Surface" value={surfaceHa} onChange={setSurface}
              min={0.5} max={100} step={0.5} unit=" ha" color={C.green}/>
            <MInput label="Date limite exploitation" value={dateLimite}
              onChange={setDateL} type="date" hint="optionnel"/>
            <MInput label="Observations" value={observations}
              onChange={setObs} placeholder="Notes libres sur la parcelle…"
              big hint="optionnel"/>
          </div>
        )}

        {/* ÉTAPE 5 — CONTRAINTES */}
        {step===4&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Cochez les contraintes présentes sur la parcelle.
            </div>
            <div style={{background:"#fff",border:`1px solid ${C.bd}`,borderRadius:14,
              padding:"0 14px",overflow:"hidden"}}>
              {[
                {k:"ligneEDF",l:"Ligne EDF / Télécom",s:"Risque abattage — contacter gestionnaire"},
                {k:"penteForte",l:"Pente forte (>30%)",s:"Débardage difficile — câble ou porteur"},
                {k:"zoneHumide",l:"Zone humide",s:"Passage engins restreint"},
                {k:"natura2000",l:"Natura 2000",s:"Contraintes réglementaires"},
                {k:"routeLimitee",l:"Route limitée tonnage",s:"Vérifier gabarit camion"},
                {k:"voisinage",l:"Voisinage sensible",s:"Riverains, bruit, horaires"},
                {k:"accesDifficile",l:"Accès difficile",s:"Chemin étroit ou en mauvais état"},
                {k:"remanents",l:"Rémanents importants",s:"Broyage nécessaire"},
                {k:"telecom",l:"Câbles télécom",s:"Vérifier avant travaux"},
              ].map(({k,l,s})=>(
                <CheckItem key={k}
                  checked={contraintes[k]||false}
                  onChange={v=>setCont({...contraintes,[k]:v})}
                  label={l} sub={s} warn/>
              ))}
            </div>
            <div style={{marginTop:12,padding:"10px 14px",background:C.bg2,
              borderRadius:10,fontSize:12,color:C.tx3}}>
              {Object.values(contraintes).filter(Boolean).length} contrainte(s) identifiée(s)
            </div>
          </div>
        )}

        {/* ÉTAPE 6 — ACCÈS CAMION */}
        {step===5&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Évaluez les conditions d'accès pour les camions de transport.
            </div>
            <div style={{marginBottom:14}}>
              <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
                🚛 Accès camion
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {[
                  ["praticable","✅ Praticable","Accès normal, pas de restriction"],
                  ["difficile","⚠️ Difficile","Conditions dégradées, prudence"],
                  ["impossible","🚫 Impossible","Accès interdit aux camions"],
                ].map(([v,l,s])=>(
                  <div key={v} onClick={()=>setAcces(v)} style={{
                    padding:"14px",borderRadius:12,cursor:"pointer",
                    border:`2px solid ${accesCamion===v?C.green:C.bd}`,
                    background:accesCamion===v?C.greenL:"#fff",
                    WebkitTapHighlightColor:"transparent",
                  }}>
                    <div style={{fontSize:15,fontWeight:600,
                      color:accesCamion===v?C.greenD:C.tx,marginBottom:3}}>{l}</div>
                    <div style={{fontSize:12,color:C.tx3}}>{s}</div>
                  </div>
                ))}
              </div>
            </div>
            <MSlider label="Largeur minimale de l'accès"
              value={largeurAcces} onChange={setLarg}
              min={2} max={8} step={0.5} unit="m" color={C.brown}/>
            <MSlider label="Distance jusqu'à la plateforme"
              value={distancePlateforme} onChange={setDist}
              min={100} max={5000} step={100} unit="m" color={C.blue}/>

            {/* Récap final */}
            <div style={{background:allValid?C.greenL:C.amberL,borderRadius:14,
              padding:16,marginTop:8,
              border:`1.5px solid ${allValid?C.green:C.amber}`}}>
              <div style={{fontSize:13,fontWeight:700,
                color:allValid?C.greenD:C.amberD,marginBottom:10}}>
                {allValid?"✅ Visite complète — prête à valider":"⚠ Étapes incomplètes"}
              </div>
              {STEPS.map((s,i)=>(
                <div key={s.id} style={{display:"flex",alignItems:"center",
                  gap:8,padding:"4px 0",fontSize:12,
                  color:stepValid[i]?C.greenD:C.red}}>
                  <span>{stepValid[i]?"✓":"✗"}</span>
                  <span>{s.icon} {s.label}</span>
                  {!stepValid[i]&&(
                    <button onClick={()=>setStep(i)} style={{
                      marginLeft:"auto",background:"none",border:"none",
                      color:C.red,cursor:"pointer",fontSize:11,
                      textDecoration:"underline",fontFamily:"inherit",
                    }}>Compléter</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"10px 16px 24px",
        background:`linear-gradient(transparent,${C.bg} 25%)`,
        display:"flex",gap:10,
      }}>
        {step>0&&(
          <button onClick={()=>setStep(s=>s-1)} style={{
            height:BTN_H,padding:"0 20px",borderRadius:14,
            background:C.bg2,color:C.tx2,border:"none",
            fontFamily:"inherit",fontSize:15,fontWeight:500,
            cursor:"pointer",WebkitTapHighlightColor:"transparent",
          }}>‹ Retour</button>
        )}
        {step<STEPS.length-1 ? (
          <BigBtn onClick={()=>setStep(s=>s+1)}
            bg={stepValid[step]?currentStep.color:C.amber}
            style={{flex:1}}>
            {STEPS[step+1].icon} {STEPS[step+1].label} →
          </BigBtn>
        ) : (
          <BigBtn onClick={handleSave}
            bg={allValid?C.green:C.bg2}
            disabled={saving} style={{flex:1}}
            icon={saving?"":"✅"}>
            {saving?"Enregistrement…":"VALIDER LA VISITE"}
          </BigBtn>
        )}
      </div>
    </div>
  );
};

// ── LISTE VISITES ──────────────────────────────────────────────
const ListeVisites = ({visites,onNew,onBack}) => (
  <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
    <div style={{flex:1,overflowY:"auto",padding:PADDING}}>
      {visites.length===0 ? (
        <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
          <div style={{fontSize:40,marginBottom:12}}>🔭</div>
          <div style={{fontSize:16,fontWeight:500,marginBottom:6}}>
            Aucune visite
          </div>
          <div style={{fontSize:13}}>
            Créez votre première visite terrain
          </div>
        </div>
      ) : visites.map(v=>(
        <div key={v.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
          borderRadius:14,padding:16,marginBottom:10}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
            <div style={{fontSize:14,fontWeight:600}}>{v.lotNumero}</div>
            <div style={{fontSize:11,padding:"3px 8px",borderRadius:6,
              background:C.greenL,color:C.greenD,fontWeight:500}}>
              ✅ Validée
            </div>
          </div>
          <div style={{fontSize:12,color:C.tx3,lineHeight:1.7}}>
            📅 {v.date}<br/>
            📍 {v.gps?.lat.toFixed(4)}°N · {v.gps?.lng.toFixed(4)}°E<br/>
            🌿 {v.essences?.map(e=>`${e.label} ${e.pct}%`).join(", ")}<br/>
            📦 {v.volumeEstimeT} t estimées · {v.surfaceHa} ha<br/>
            🚛 Accès {v.accesCamion}
            {v.photos?.length>0&&(
              <span> · 📷 {v.photos.length} photo{v.photos.length>1?"s":""}</span>
            )}
          </div>
        </div>
      ))}
    </div>
    <div style={{padding:"12px 16px 24px",flexShrink:0}}>
      <BigBtn onClick={onNew} icon="🔭">
        Nouvelle visite terrain
      </BigBtn>
    </div>
  </div>
);

// ── APP ────────────────────────────────────────────────────────
export default function App() {
  const [screen,  setScreen]  = useState("liste");
  const [visites, setVisites] = useState([]);
  const [toasts,  setToasts]  = useState([]);

  const toast = useCallback((msg,type="success")=>{
    const id=uid();
    setToasts(t=>[...t,{id,msg,type}]);
    setTimeout(()=>setToasts(t=>t.filter(x=>x.id!==id)),2800);
  },[]);

  const LOT = {id:"l1",numero:"LOT-2025-007",commune:"Charny (89)"};

  const handleSaved = (v) => {
    setVisites(prev=>[...prev,v]);
    setScreen("liste");
    toast("Visite enregistrée — lot prêt à exploiter ✓");
  };

  const screenColor = screen==="form" ? C.green : C.sb;

  return (
    <div style={{
      display:"flex",flexDirection:"column",
      height:"100dvh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      background:C.bg,color:C.tx,
      maxWidth:430,margin:"0 auto",
      boxShadow:"0 0 40px rgba(0,0,0,.15)",
    }}>
      {/* Toasts */}
      <div style={{position:"fixed",top:16,left:16,right:16,zIndex:9999,
        display:"flex",flexDirection:"column",gap:8,pointerEvents:"none"}}>
        {toasts.map(t=>(
          <div key={t.id} style={{padding:"12px 16px",borderRadius:12,
            fontSize:14,fontWeight:500,color:"#fff",textAlign:"center",
            background:t.type==="success"?C.greenD:C.amberD,
            boxShadow:"0 4px 20px rgba(0,0,0,.25)"}}>
            {t.type==="success"?"✓":"⚠"} {t.msg}
          </div>
        ))}
      </div>

      {/* Header */}
      <div style={{background:screenColor,color:"#fff",flexShrink:0,
        padding:"12px 16px 10px"}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          {screen==="form" ? (
            <button onClick={()=>setScreen("liste")} style={{
              background:"rgba(255,255,255,.2)",border:"none",color:"#fff",
              width:36,height:36,borderRadius:9,cursor:"pointer",fontSize:18,
              display:"flex",alignItems:"center",justifyContent:"center",
              WebkitTapHighlightColor:"transparent",
            }}>‹</button>
          ) : (
            <div style={{width:36,height:36,background:C.green,borderRadius:9,
              display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>
              🌲
            </div>
          )}
          <div>
            <div style={{fontSize:16,fontWeight:600}}>
              {screen==="form"?"Nouvelle visite":"APPLITAG — Visites terrain"}
            </div>
            <div style={{fontSize:11,opacity:.65}}>
              {LOT.numero} · {LOT.commune}
            </div>
          </div>
          {screen==="liste"&&(
            <div style={{marginLeft:"auto",background:"rgba(255,255,255,.15)",
              padding:"4px 10px",borderRadius:7,fontSize:12}}>
              {visites.length} visite{visites.length>1?"s":""}
            </div>
          )}
        </div>
      </div>

      {/* Contenu */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        {screen==="liste" && (
          <ListeVisites visites={visites}
            onNew={()=>setScreen("form")}
            onBack={()=>setScreen("liste")}/>
        )}
        {screen==="form" && (
          <FormulaireVisite lot={LOT}
            onBack={()=>setScreen("liste")}
            onSaved={handleSaved} toast={toast}/>
        )}
      </div>
    </div>
  );
}
