-- ============================================================
-- BoisÉnergie — Schéma PostgreSQL V1
-- 10 entités · UUID · Soft delete · Audit trail
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE proprietaire_type AS ENUM (
  'particulier', 'societe', 'cooperative', 'commune', 'onf', 'sci', 'gaec'
);

CREATE TYPE certification_type AS ENUM (
  'aucune', 'pefc', 'fsc', 'pefc_fsc'
);

CREATE TYPE lot_statut AS ENUM (
  'brouillon',
  'parcelle_renseignee',
  'visite_realisee',
  'lot_valide',
  'en_exploitation',
  'disponible_bord_route',
  'dechiquetage_programme',
  'en_transport',
  'livre',
  'en_litige',
  'cloture',
  'annule'
);

CREATE TYPE lot_type AS ENUM (
  'taillis', 'futaie', 'haie', 'bord_route', 'autre'
);

CREATE TYPE essence AS ENUM (
  'peuplier', 'frene', 'chene', 'acacia', 'saule',
  'bouleau', 'charme', 'aulne', 'orme', 'autre'
);

CREATE TYPE visite_verdict AS ENUM (
  'en_attente', 'valide', 'refuse', 'sous_reserve'
);

CREATE TYPE chantier_statut AS ENUM (
  'planifie', 'en_cours', 'termine', 'cloture', 'annule'
);

CREATE TYPE chantier_type_operation AS ENUM (
  'abattage', 'debardage', 'abattage_debardage'
);

CREATE TYPE meteo AS ENUM (
  'beau', 'nuageux', 'pluie_legere', 'pluie_forte', 'gel', 'vent', 'arret'
);

CREATE TYPE incident_type AS ENUM (
  'aucun', 'panne_machine', 'accident', 'arret_meteo',
  'probleme_acces', 'autre'
);

CREATE TYPE tas_statut AS ENUM (
  'en_cours', 'pret', 'dechiquete', 'annule'
);

CREATE TYPE granulometrie AS ENUM (
  'p45', 'p63', 'p100'
);

CREATE TYPE transport_statut AS ENUM (
  'prepare', 'en_route', 'arrive', 'annule'
);

CREATE TYPE transport_type AS ENUM (
  'routier', 'ferroviaire', 'fluvial'
);

CREATE TYPE livraison_statut AS ENUM (
  'en_attente', 'livre', 'valide', 'litigieux', 'annule'
);

CREATE TYPE document_type AS ENUM (
  'photo', 'cmr', 'bl', 'rapport_visite',
  'ordre_exploitation', 'rapport_cloture',
  'contrat', 'signature', 'analyse_humidite'
);

CREATE TYPE user_role AS ENUM (
  'admin', 'exploitant', 'operateur', 'dechiqueteur',
  'transporteur', 'chauffeur', 'chaufferie'
);

-- ============================================================
-- UTILISATEURS
-- ============================================================

CREATE TABLE utilisateurs (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  nom           TEXT        NOT NULL,
  email         TEXT        NOT NULL UNIQUE,
  password_hash TEXT        NOT NULL,
  role          user_role   NOT NULL,
  actif         BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at    TIMESTAMPTZ
);

CREATE INDEX idx_utilisateurs_email  ON utilisateurs (email);
CREATE INDEX idx_utilisateurs_role   ON utilisateurs (role);
CREATE INDEX idx_utilisateurs_actif  ON utilisateurs (actif) WHERE actif = TRUE;

-- ============================================================
-- PROPRIETAIRES
-- ============================================================

CREATE TABLE proprietaires (
  id         UUID               PRIMARY KEY DEFAULT gen_random_uuid(),
  type       proprietaire_type  NOT NULL,
  nom        TEXT               NOT NULL,
  contact    TEXT,
  telephone  TEXT,
  email      TEXT,
  adresse    TEXT,
  created_at TIMESTAMPTZ        NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ        NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_proprietaires_nom ON proprietaires (nom);

-- ============================================================
-- ENTREPRISES ETF
-- ============================================================

CREATE TABLE entreprises_etf (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  raison_sociale  TEXT        NOT NULL,
  siret           TEXT        UNIQUE,
  telephone       TEXT,
  email           TEXT,
  adresse         TEXT,
  responsable     TEXT,
  agrement        TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ
);

CREATE INDEX idx_etf_raison_sociale ON entreprises_etf (raison_sociale);

-- ============================================================
-- LOTS
-- ============================================================

CREATE TABLE lots (
  id                  UUID                 PRIMARY KEY DEFAULT gen_random_uuid(),
  numero_lot          TEXT                 NOT NULL UNIQUE,
  statut              lot_statut           NOT NULL DEFAULT 'brouillon',
  type_lot            lot_type,
  date_creation       DATE                 NOT NULL DEFAULT CURRENT_DATE,
  createur_id         UUID                 NOT NULL REFERENCES utilisateurs(id),
  proprietaire_id     UUID                 NOT NULL REFERENCES proprietaires(id),
  certification       BOOLEAN              NOT NULL DEFAULT FALSE,
  certification_ref   TEXT,
  certification_type  certification_type   NOT NULL DEFAULT 'aucune',
  essence_principale  essence,
  volume_estime       NUMERIC(10,2),
  humidite_estimee    NUMERIC(5,2),
  gps_lat             DOUBLE PRECISION,
  gps_lng             DOUBLE PRECISION,
  commentaire         TEXT,
  created_at          TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
  deleted_at          TIMESTAMPTZ,
  CONSTRAINT chk_humidite_lot CHECK (humidite_estimee IS NULL OR humidite_estimee BETWEEN 0 AND 100),
  CONSTRAINT chk_volume_lot   CHECK (volume_estime IS NULL OR volume_estime >= 0)
);

CREATE INDEX idx_lots_statut        ON lots (statut);
CREATE INDEX idx_lots_proprietaire  ON lots (proprietaire_id);
CREATE INDEX idx_lots_createur      ON lots (createur_id);
CREATE INDEX idx_lots_numero        ON lots (numero_lot);

-- Séquence pour la génération du numéro de lot LOT-AAAA-XXX
CREATE SEQUENCE lot_seq START 1;

CREATE OR REPLACE FUNCTION generate_numero_lot()
RETURNS TEXT AS $$
BEGIN
  RETURN 'LOT-' || TO_CHAR(NOW(), 'YYYY') || '-' ||
         LPAD(NEXTVAL('lot_seq')::TEXT, 3, '0');
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- PARCELLES
-- ============================================================

CREATE TABLE parcelles (
  id                   UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id               UUID        NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  reference_cadastrale TEXT,
  surface_ha           NUMERIC(10,4) NOT NULL,
  commune              TEXT        NOT NULL,
  gps_lat              DOUBLE PRECISION,
  gps_lng              DOUBLE PRECISION,
  acces_description    TEXT,
  contraintes          TEXT,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at           TIMESTAMPTZ,
  CONSTRAINT chk_surface CHECK (surface_ha > 0)
);

CREATE INDEX idx_parcelles_lot     ON parcelles (lot_id);
CREATE INDEX idx_parcelles_commune ON parcelles (commune);

-- ============================================================
-- VISITES TERRAIN
-- ============================================================

CREATE TABLE visites_terrain (
  id            UUID             PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id        UUID             NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  agent_id      UUID             NOT NULL REFERENCES utilisateurs(id),
  date_visite   DATE             NOT NULL,
  essences      JSONB            NOT NULL DEFAULT '[]',
  -- Format essences : [{"essence":"peuplier","pct":65,"volume_t":200,"granulometrie":"p45"}]
  volume_estime NUMERIC(10,2),
  observations  TEXT,
  verdict       visite_verdict   NOT NULL DEFAULT 'en_attente',
  gps_lat       DOUBLE PRECISION,
  gps_lng       DOUBLE PRECISION,
  created_at    TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  deleted_at    TIMESTAMPTZ
);

CREATE INDEX idx_visites_lot     ON visites_terrain (lot_id);
CREATE INDEX idx_visites_agent   ON visites_terrain (agent_id);
CREATE INDEX idx_visites_verdict ON visites_terrain (verdict);

-- ============================================================
-- CHANTIERS
-- ============================================================

CREATE TABLE chantiers (
  id               UUID                   PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id           UUID                   NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  etf_id           UUID                   REFERENCES entreprises_etf(id),
  responsable_id   UUID                   REFERENCES utilisateurs(id),
  type_operation   chantier_type_operation NOT NULL DEFAULT 'abattage_debardage',
  date_debut       DATE,
  date_fin_prevue  DATE,
  date_fin_reelle  DATE,
  machine          TEXT,
  statut           chantier_statut         NOT NULL DEFAULT 'planifie',
  volume_reel      NUMERIC(10,2)           GENERATED ALWAYS AS STORED
                   -- calculé via trigger ou vue matérialisée, pas inline
                   DEFAULT NULL,
  created_at       TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
  deleted_at       TIMESTAMPTZ
);

-- volume_reel est calculé par trigger depuis les relevés journaliers
ALTER TABLE chantiers DROP COLUMN IF EXISTS volume_reel;
ALTER TABLE chantiers ADD COLUMN volume_reel NUMERIC(10,2) NOT NULL DEFAULT 0;

CREATE INDEX idx_chantiers_lot      ON chantiers (lot_id);
CREATE INDEX idx_chantiers_etf      ON chantiers (etf_id);
CREATE INDEX idx_chantiers_statut   ON chantiers (statut);

-- Trigger : recalcule volume_reel à chaque insert/update/delete sur releves_journaliers
CREATE OR REPLACE FUNCTION update_chantier_volume_reel()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE chantiers
  SET volume_reel = (
    SELECT COALESCE(SUM(tonnage_t), 0)
    FROM releves_journaliers
    WHERE chantier_id = COALESCE(NEW.chantier_id, OLD.chantier_id)
      AND deleted_at IS NULL
  ),
  updated_at = NOW()
  WHERE id = COALESCE(NEW.chantier_id, OLD.chantier_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- RELEVÉS JOURNALIERS
-- ============================================================

CREATE TABLE releves_journaliers (
  id           UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  chantier_id  UUID          NOT NULL REFERENCES chantiers(id) ON DELETE RESTRICT,
  operateur_id UUID          NOT NULL REFERENCES utilisateurs(id),
  date         DATE          NOT NULL,
  tonnage_t    NUMERIC(10,2) NOT NULL,
  humidite_pct NUMERIC(5,2),
  meteo        meteo         NOT NULL DEFAULT 'beau',
  incident     incident_type NOT NULL DEFAULT 'aucun',
  notes        TEXT,
  created_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at   TIMESTAMPTZ,
  CONSTRAINT chk_tonnage    CHECK (tonnage_t >= 0),
  CONSTRAINT chk_humidite_r CHECK (humidite_pct IS NULL OR humidite_pct BETWEEN 0 AND 100),
  CONSTRAINT uq_releve_jour UNIQUE (chantier_id, operateur_id, date)
);

CREATE INDEX idx_releves_chantier  ON releves_journaliers (chantier_id);
CREATE INDEX idx_releves_operateur ON releves_journaliers (operateur_id);
CREATE INDEX idx_releves_date      ON releves_journaliers (date);

-- Attacher le trigger après création de la table
CREATE TRIGGER trg_update_volume_reel
AFTER INSERT OR UPDATE OR DELETE ON releves_journaliers
FOR EACH ROW EXECUTE FUNCTION update_chantier_volume_reel();

-- ============================================================
-- TAS
-- ============================================================

CREATE TABLE tas (
  id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  chantier_id      UUID        NOT NULL REFERENCES chantiers(id) ON DELETE RESTRICT,
  numero_tas       TEXT        NOT NULL,
  gps_lat          DOUBLE PRECISION,
  gps_lng          DOUBLE PRECISION,
  volume_estime    NUMERIC(10,2),
  poids_estime     NUMERIC(10,2),
  essence          essence,
  humidite_estimee NUMERIC(5,2),
  complet          BOOLEAN     NOT NULL DEFAULT FALSE,
  statut           tas_statut  NOT NULL DEFAULT 'en_cours',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at       TIMESTAMPTZ,
  CONSTRAINT chk_humidite_tas CHECK (humidite_estimee IS NULL OR humidite_estimee BETWEEN 0 AND 100),
  CONSTRAINT uq_tas_numero    UNIQUE (chantier_id, numero_tas)
);

CREATE INDEX idx_tas_chantier ON tas (chantier_id);
CREATE INDEX idx_tas_statut   ON tas (statut);

-- Vue : stock bord de route par lot (tas prêts non déchiquetés)
CREATE VIEW v_stock_bord_route AS
SELECT
  c.lot_id,
  COALESCE(SUM(t.volume_estime), 0) AS stock_disponible_t,
  COALESCE(SUM(CASE WHEN t.statut IN ('en_cours','pret') THEN t.volume_estime ELSE 0 END), 0) AS stock_previsionnel_t,
  COUNT(*) FILTER (WHERE t.statut = 'pret') AS nb_tas_prets,
  COUNT(*) FILTER (WHERE t.statut = 'en_cours') AS nb_tas_en_cours
FROM tas t
JOIN chantiers c ON c.id = t.chantier_id
WHERE t.statut = 'pret'
  AND t.deleted_at IS NULL
GROUP BY c.lot_id;

-- ============================================================
-- TRANSPORTS
-- ============================================================

CREATE TABLE transports (
  id               UUID              PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id           UUID              NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  etf_transport_id UUID              REFERENCES entreprises_etf(id),
  chauffeur        TEXT,
  immat_camion     TEXT,
  immat_remorque   TEXT,
  type_transport   transport_type    NOT NULL DEFAULT 'routier',
  cmr_reference    TEXT              UNIQUE,
  poids_brut_t     NUMERIC(10,3),
  poids_tare_t     NUMERIC(10,3),
  poids_net_t      NUMERIC(10,3)     GENERATED ALWAYS AS (poids_brut_t - poids_tare_t) STORED,
  gps_depart_lat   DOUBLE PRECISION,
  gps_depart_lng   DOUBLE PRECISION,
  heure_depart     TIMESTAMPTZ,
  heure_arrivee    TIMESTAMPTZ,
  statut           transport_statut  NOT NULL DEFAULT 'prepare',
  created_at       TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  deleted_at       TIMESTAMPTZ,
  CONSTRAINT chk_poids_transport CHECK (
    poids_brut_t IS NULL OR poids_tare_t IS NULL OR poids_brut_t >= poids_tare_t
  )
);

CREATE INDEX idx_transports_lot    ON transports (lot_id);
CREATE INDEX idx_transports_statut ON transports (statut);
CREATE INDEX idx_transports_cmr    ON transports (cmr_reference);

-- ============================================================
-- LIVRAISONS
-- ============================================================

CREATE TABLE livraisons (
  id              UUID              PRIMARY KEY DEFAULT gen_random_uuid(),
  transport_id    UUID              NOT NULL REFERENCES transports(id) ON DELETE RESTRICT,
  numero_bl       TEXT              NOT NULL UNIQUE,
  lot_reference   TEXT              NOT NULL,
  destination     TEXT,
  gps_lat         DOUBLE PRECISION,
  gps_lng         DOUBLE PRECISION,
  poids_entree    NUMERIC(10,3),
  poids_tare      NUMERIC(10,3),
  poids_net       NUMERIC(10,3)     GENERATED ALWAYS AS (poids_entree - poids_tare) STORED,
  humidite        NUMERIC(5,2),
  date_livraison  TIMESTAMPTZ,
  receptionnaire  TEXT,
  signature_url   TEXT,
  statut          livraison_statut  NOT NULL DEFAULT 'en_attente',
  created_at      TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ,
  CONSTRAINT chk_humidite_liv CHECK (humidite IS NULL OR humidite BETWEEN 0 AND 100),
  CONSTRAINT chk_poids_liv    CHECK (
    poids_entree IS NULL OR poids_tare IS NULL OR poids_entree >= poids_tare
  )
);

CREATE INDEX idx_livraisons_transport    ON livraisons (transport_id);
CREATE INDEX idx_livraisons_lot_ref      ON livraisons (lot_reference);
CREATE INDEX idx_livraisons_statut       ON livraisons (statut);
CREATE INDEX idx_livraisons_numero_bl    ON livraisons (numero_bl);

-- Séquence pour numéro BL
CREATE SEQUENCE bl_seq START 1;

CREATE OR REPLACE FUNCTION generate_numero_bl()
RETURNS TEXT AS $$
BEGIN
  RETURN 'BL-' || TO_CHAR(NOW(), 'YYYY') || '-' ||
         LPAD(NEXTVAL('bl_seq')::TEXT, 4, '0');
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- DOCUMENTS
-- ============================================================

CREATE TABLE documents (
  id          UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  type        document_type NOT NULL,
  ref_type    TEXT          NOT NULL,
  -- valeurs : lot / parcelle / visite_terrain / chantier / releve_journalier
  --           / tas / transport / livraison
  ref_id      UUID          NOT NULL,
  url         TEXT          NOT NULL,
  created_by  UUID          NOT NULL REFERENCES utilisateurs(id),
  created_at  TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at  TIMESTAMPTZ,
  CONSTRAINT chk_ref_type CHECK (ref_type IN (
    'lot', 'parcelle', 'visite_terrain', 'chantier',
    'releve_journalier', 'tas', 'transport', 'livraison'
  ))
);

CREATE INDEX idx_documents_ref    ON documents (ref_type, ref_id);
CREATE INDEX idx_documents_type   ON documents (type);
CREATE INDEX idx_documents_auteur ON documents (created_by);

-- ============================================================
-- TRIGGER updated_at automatique (toutes les tables)
-- ============================================================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY[
    'utilisateurs','proprietaires','entreprises_etf','lots','parcelles',
    'visites_terrain','chantiers','releves_journaliers','tas',
    'transports','livraisons'
  ] LOOP
    EXECUTE FORMAT(
      'CREATE TRIGGER trg_%s_updated_at
       BEFORE UPDATE ON %s
       FOR EACH ROW EXECUTE FUNCTION set_updated_at()',
      tbl, tbl
    );
  END LOOP;
END $$;

-- ============================================================
-- CONTRAINTES DE TRANSITION DE STATUT (lot)
-- ============================================================

CREATE OR REPLACE FUNCTION check_lot_statut_transition()
RETURNS TRIGGER AS $$
DECLARE
  valid_transitions JSONB := '{
    "brouillon":               ["parcelle_renseignee","annule"],
    "parcelle_renseignee":     ["visite_realisee","brouillon","annule"],
    "visite_realisee":         ["lot_valide","parcelle_renseignee","annule"],
    "lot_valide":              ["en_exploitation","annule"],
    "en_exploitation":         ["disponible_bord_route","annule"],
    "disponible_bord_route":   ["dechiquetage_programme","en_exploitation","annule"],
    "dechiquetage_programme":  ["en_transport","annule"],
    "en_transport":            ["livre","annule"],
    "livre":                   ["cloture","en_litige"],
    "en_litige":               ["cloture","annule"],
    "cloture":                 [],
    "annule":                  []
  }';
BEGIN
  IF NEW.statut = OLD.statut THEN
    RETURN NEW;
  END IF;
  IF NOT (valid_transitions->OLD.statut::TEXT @> TO_JSONB(NEW.statut::TEXT)) THEN
    RAISE EXCEPTION 'Transition de statut invalide : % → %', OLD.statut, NEW.statut;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_lot_statut_transition
BEFORE UPDATE OF statut ON lots
FOR EACH ROW EXECUTE FUNCTION check_lot_statut_transition();

-- ============================================================
-- INDEX COMPOSITES pour les requêtes fréquentes
-- ============================================================

CREATE INDEX idx_lots_statut_date     ON lots (statut, date_creation DESC);
CREATE INDEX idx_tas_chantier_statut  ON tas (chantier_id, statut);
CREATE INDEX idx_releves_chantier_date ON releves_journaliers (chantier_id, date DESC);

-- ============================================================
-- FIN DU SCHÉMA
-- ============================================================
