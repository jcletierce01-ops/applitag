// ============================================================
// APPLITAG — Sprint 2 : Carte Métier Temps Réel
// Zoom France → Région → Département → Commune → Lot → Tas
// JSDoc TypeScript-style · SVG interactif · Filières complètes
// ============================================================

import { useState, useCallback, useMemo, useRef } from "react";

// ── TYPES ──────────────────────────────────────────────────────────────────────
/**
 * @typedef {'opportunite'|'visite'|'lot'|'tas'|'transport'|'chaufferie'|'plateforme'|'proprietaire'} MarkerType
 * @typedef {'BROUILLON'|'A_VISITER'|'VISITE_REALISEE'|'VALIDE_EXPLOITATION'|'EN_EXPLOITATION'|'BORD_ROUTE'|'A_DECHIQUETER'|'EN_TRANSPORT'|'PARTIELLEMENT_LIVRE'|'LIVRE'|'CLOTURE'} LotStatut
 * @typedef {Object} GeoPoint
 * @property {number} lat
 * @property {number} lng
 */

/**
 * @typedef {Object} MapMarker
 * @property {string} id
 * @property {MarkerType} type
 * @property {number} lat
 * @property {number} lng
 * @property {string} label
 * @property {string} sublabel
 * @property {string} icon
 * @property {string} color
 * @property {string} bg
 * @property {number} [priority]
 * @property {any} data
 */

/**
 * @typedef {Object} ZoomLevel
 * @property {'france'|'region'|'departement'|'commune'|'lot'|'tas'} level
 * @property {string} label
 * @property {GeoPoint} center
 * @property {number} zoom
 */

// ── DESIGN TOKENS ──────────────────────────────────────────────────────────────
const T = {
  green:"#1D9E75", greenL:"#E1F5EE", greenD:"#085041",
  purple:"#534AB7", purpleL:"#EEEDFE", purpleD:"#26215C",
  coral:"#D85A30", coralL:"#FAECE7", coralD:"#4A1B0C",
  blue:"#185FA5", blueL:"#E6F1FB", blueD:"#042C53",
  amber:"#BA7517", amberL:"#FAEEDA", amberD:"#412402",
  red:"#A32D2D", redL:"#FCEBEB",
  bg:"#F5F4F1", bg2:"#ECEAE6",
  bd:"#DDDBD5", bd2:"#C8C5BE",
  tx:"#1A1A18", tx2:"#5A5955", tx3:"#9A9892",
};

// ── RICH MOCK DATA (géolocalisé précisément) ────────────────────────────────────
const DEMO = {
  proprietaires: [
    {id:"pr1",nom:"Vasseur Alain",commune:"Charny",lat:47.984,lng:3.089,ha:22,tel:"06 12 34 56 78"},
    {id:"pr2",nom:"Lemaire Patrick",commune:"Tonnerre",lat:47.858,lng:3.978,ha:15,tel:"06 88 77 66 55"},
    {id:"pr3",nom:"Martin Sophie",commune:"Migennes",lat:47.970,lng:3.516,ha:8,tel:"06 44 55 66 77"},
    {id:"pr4",nom:"Girard Benoît",commune:"Joigny",lat:47.982,lng:2.981,ha:31,tel:"06 22 11 33 44"},
  ],
  opportunites: [
    {id:"o1",commune:"Charny (89)",contact:"Vasseur A.",volumeT:500,statut:"a_visiter",urgence:"haute",lat:47.983,lng:3.090,typeBois:"bois_sur_pied"},
    {id:"o2",commune:"Tonnerre (89)",contact:"Lemaire P.",volumeT:200,statut:"visite_programmee",urgence:"basse",lat:47.857,lng:3.979,typeBois:"bois_sur_pied"},
    {id:"o3",commune:"Migennes (89)",contact:"Martin S.",volumeT:180,statut:"visite_faite",urgence:"normale",lat:47.971,lng:3.517,typeBois:"bord_de_route"},
  ],
  visites: [
    {id:"v1",commune:"Tonnerre (89)",date:"2025-05-28",agent:"J. Moreau",volumeT:190,lat:47.856,lng:3.977,statut:"validee"},
    {id:"v2",commune:"Migennes (89)",date:"2025-06-02",agent:"J. Moreau",volumeT:175,lat:47.972,lng:3.518,statut:"en_cours"},
  ],
  lots: [
    {id:"l1",numero:"LOT-2025-007",commune:"Charny (89)",statut:"EN_EXPLOITATION",essence:"Peuplier",volumeEstT:350,volumeReelT:238,humidite:38,lat:47.9812,lng:3.0891,etf:"ETF Duclos"},
    {id:"l2",numero:"LOT-2025-006",commune:"Joigny (89)",statut:"EN_TRANSPORT",essence:"Peuplier",volumeEstT:320,volumeReelT:318,humidite:32,lat:47.9826,lng:2.9816,etf:"ETF Duclos"},
    {id:"l3",numero:"LOT-2025-005",commune:"Sens (89)",statut:"LIVRE",essence:"Chêne",volumeEstT:145,volumeReelT:142,humidite:31,lat:48.1967,lng:3.2875,etf:"Coop Bourgogne"},
    {id:"l4",numero:"LOT-2025-004",commune:"Auxerre (89)",statut:"VALIDE_EXPLOITATION",essence:"Frêne",volumeEstT:220,volumeReelT:0,humidite:null,lat:47.7979,lng:3.5714,etf:"ETF Duclos"},
  ],
  tas: [
    {id:"t1",lotId:"l1",lotNum:"LOT-2025-007",num:"A",volumeT:85,essence:"Peuplier",statut:"pret",lat:47.9817,lng:3.0895},
    {id:"t2",lotId:"l1",lotNum:"LOT-2025-007",num:"B",volumeT:35,essence:"Frêne",statut:"pret",lat:47.9808,lng:3.0900},
    {id:"t3",lotId:"l1",lotNum:"LOT-2025-007",num:"C",volumeT:35,essence:"Peuplier",statut:"en_cours",lat:47.9820,lng:3.0885},
    {id:"t4",lotId:"l2",lotNum:"LOT-2025-006",num:"A",volumeT:160,essence:"Peuplier",statut:"dechiquete",lat:47.9830,lng:2.9820},
    {id:"t5",lotId:"l2",lotNum:"LOT-2025-006",num:"B",volumeT:158,essence:"Peuplier",statut:"dechiquete",lat:47.9822,lng:2.9812},
  ],
  transports: [
    {id:"tr1",lotNum:"LOT-2025-006",chauffeur:"D. Martel",camion:"EF-456-GH",destination:"Chaufferie Troyes",statut:"en_route",poidsT:42,lat:48.051,lng:3.324,heure:"07:45"},
    {id:"tr2",lotNum:"LOT-2025-006",chauffeur:"M. Simon",camion:"AB-789-CD",destination:"Chaufferie Troyes",statut:"en_route",poidsT:42,lat:48.127,lng:3.453,heure:"09:15"},
    {id:"tr3",lotNum:"LOT-2025-005",chauffeur:"P. Leroy",camion:"GH-321-IJ",destination:"Plateforme Sens",statut:"arrive",poidsT:38.5,lat:48.197,lng:3.288,heure:"14:00"},
  ],
  chaufferies: [
    {id:"ch1",nom:"Chaufferie Troyes Est",commune:"Troyes (10)",cap:5000,stock:320,humMax:35,lat:48.290,lng:4.073},
    {id:"ch2",nom:"Chaufferie Auxerre Centre",commune:"Auxerre (89)",cap:3000,stock:180,humMax:35,lat:47.798,lng:3.571},
    {id:"ch3",nom:"Chaufferie Sens Nord",commune:"Sens (89)",cap:2000,stock:95,humMax:35,lat:48.201,lng:3.283},
  ],
  plateformes: [
    {id:"pl1",nom:"Plateforme Sens Biomasse",commune:"Sens (89)",cap:8000,stock:2480,humMoy:34,lat:48.194,lng:3.280},
    {id:"pl2",nom:"Plateforme Auxerre Nord",commune:"Auxerre (89)",cap:5000,stock:1100,humMoy:33,lat:47.811,lng:3.557},
  ],
};

// Zoom levels hierarchy
/** @type {ZoomLevel[]} */
const ZOOM_LEVELS = [
  {level:"france",    label:"France",       center:{lat:46.8,lng:2.4},  zoom:1},
  {level:"region",    label:"Bourgogne-FC", center:{lat:47.3,lng:3.8},  zoom:2.2},
  {level:"departement",label:"Yonne (89)",  center:{lat:47.9,lng:3.3},  zoom:4},
  {level:"commune",   label:"Charny",       center:{lat:47.98,lng:3.09},zoom:8},
  {level:"lot",       label:"LOT-2025-007", center:{lat:47.981,lng:3.089},zoom:14},
  {level:"tas",       label:"Tas A/B/C",    center:{lat:47.982,lng:3.089},zoom:20},
];

// ── HELPERS ─────────────────────────────────────────────────────────────────────
/** @param {LotStatut} s */
const lotColor = (s) => ({
  BROUILLON:"#888", A_VISITER:T.amber, VISITE_REALISEE:T.amber,
  VALIDE_EXPLOITATION:T.green, EN_EXPLOITATION:T.blue, BORD_ROUTE:"#8B6914",
  A_DECHIQUETER:T.purple, DECHIQUETAGE_EN_COURS:T.purple, EN_TRANSPORT:T.purple,
  PARTIELLEMENT_LIVRE:T.amber, LIVRE:T.green, CLOTURE:T.greenD, ANNULE:T.red,
}[s]??T.tx2);

/** @param {LotStatut} s */
const lotBadge = (s) => ({
  EN_EXPLOITATION:"En exploitation", A_DECHIQUETER:"À déchiqueter",
  EN_TRANSPORT:"En transport", LIVRE:"Livré ✓", VALIDE_EXPLOITATION:"Validé",
  VISITE_REALISEE:"Visité", A_VISITER:"À visiter", CLOTURE:"Clôturé ✓",
  BORD_ROUTE:"Bord de route", PARTIELLEMENT_LIVRE:"Part. livré",
}[s]??s);

const typeConfig = {
  proprietaire: {icon:"👤", color:T.coral, bg:T.coralL, label:"Propriétaire"},
  opportunite:  {icon:"💡", color:T.amber, bg:T.amberL, label:"Opportunité"},
  visite:       {icon:"🔭", color:T.blue,  bg:T.blueL,  label:"Visite"},
  lot:          {icon:"🌲", color:T.green, bg:T.greenL, label:"Lot"},
  tas:          {icon:"📦", color:"#8B6914", bg:"#F1EFE8", label:"Tas"},
  transport:    {icon:"🚛", color:T.purple,bg:T.purpleL,label:"Transport"},
  chaufferie:   {icon:"🏭", color:T.blue,  bg:T.blueL,  label:"Chaufferie"},
  plateforme:   {icon:"🏗️", color:T.purple,bg:T.purpleL,label:"Plateforme"},
};

// ── PROJECTION (lat/lng → SVG x/y) ─────────────────────────────────────────────
/**
 * @param {number} lat @param {number} lng @param {GeoPoint} center @param {number} zoom
 * @param {number} W @param {number} H
 * @returns {{x:number,y:number}}
 */
const project = (lat, lng, center, zoom, W=660, H=420) => {
  const scale = zoom * 80;
  const x = (lng - center.lng) * scale + W / 2;
  const y = (center.lat - lat) * scale * 1.3 + H / 2;
  return {
    x: Math.max(16, Math.min(W - 16, x)),
    y: Math.max(16, Math.min(H - 16, y)),
  };
};

// ── SVG MAP COMPONENT ───────────────────────────────────────────────────────────
const MetierMap = ({zoomLevel, activeFilters, onMarkerClick, selectedId}) => {
  const [hov, setHov] = useState(null);
  const svgRef = useRef(null);
  const W = 660, H = 420;
  const {center, zoom, level} = zoomLevel;

  /** @type {MapMarker[]} */
  const markers = useMemo(() => {
    const list = [];
    const p = (lat,lng) => project(lat,lng,center,zoom,W,H);

    if (activeFilters.includes("proprietaires") && zoom >= 3) {
      DEMO.proprietaires.forEach(pr => {
        const {x,y} = p(pr.lat,pr.lng);
        list.push({id:pr.id,type:"proprietaire",lat:pr.lat,lng:pr.lng,x,y,
          label:pr.nom.split(" ")[1]||pr.nom, sublabel:`${pr.ha} ha · ${pr.commune}`,
          icon:"👤",color:T.coral,bg:T.coralL,priority:1,data:pr});
      });
    }
    if (activeFilters.includes("opportunites")) {
      DEMO.opportunites.forEach(o => {
        const {x,y} = p(o.lat,o.lng);
        list.push({id:o.id,type:"opportunite",lat:o.lat,lng:o.lng,x,y,
          label:o.commune.split(" ")[0], sublabel:`~${o.volumeT} t · ${o.statut}`,
          icon:"💡",color:T.amber,bg:T.amberL,priority:2,data:o});
      });
    }
    if (activeFilters.includes("visites") && zoom >= 2) {
      DEMO.visites.forEach(v => {
        const {x,y} = p(v.lat,v.lng);
        list.push({id:v.id,type:"visite",lat:v.lat,lng:v.lng,x,y,
          label:v.commune.split(" ")[0], sublabel:`${v.volumeT} t · ${v.date}`,
          icon:"🔭",color:T.blue,bg:T.blueL,priority:3,data:v});
      });
    }
    if (activeFilters.includes("lots")) {
      DEMO.lots.forEach(l => {
        const {x,y} = p(l.lat,l.lng);
        list.push({id:l.id,type:"lot",lat:l.lat,lng:l.lng,x,y,
          label:l.numero, sublabel:`${l.essence} · ${lotBadge(l.statut)}`,
          icon:l.statut==="EN_EXPLOITATION"?"⛏":l.statut==="EN_TRANSPORT"?"🚛":l.statut==="LIVRE"?"✓":"🌲",
          color:lotColor(l.statut),bg:T.greenL,priority:4,data:l});
      });
    }
    if (activeFilters.includes("tas") && zoom >= 6) {
      DEMO.tas.forEach(t => {
        const {x,y} = p(t.lat,t.lng);
        list.push({id:t.id,type:"tas",lat:t.lat,lng:t.lng,x,y,
          label:`Tas ${t.num}`, sublabel:`${t.volumeT} t · ${t.statut}`,
          icon:"📦",color:"#8B6914",bg:"#F1EFE8",priority:5,data:t});
      });
    }
    if (activeFilters.includes("transports")) {
      DEMO.transports.forEach(tr => {
        const {x,y} = p(tr.lat,tr.lng);
        list.push({id:tr.id,type:"transport",lat:tr.lat,lng:tr.lng,x,y,
          label:tr.camion, sublabel:`${tr.chauffeur} · ${tr.poidsT}t`,
          icon:"🚛",color:T.purple,bg:T.purpleL,priority:6,data:tr});
      });
    }
    if (activeFilters.includes("chaufferies")) {
      DEMO.chaufferies.forEach(c => {
        const {x,y} = p(c.lat,c.lng);
        list.push({id:c.id,type:"chaufferie",lat:c.lat,lng:c.lng,x,y,
          label:c.nom.split(" ")[1]||c.nom, sublabel:`Stock ${c.stock} t`,
          icon:"🏭",color:T.blue,bg:T.blueL,priority:7,data:c});
      });
    }
    if (activeFilters.includes("plateformes")) {
      DEMO.plateformes.forEach(pl => {
        const {x,y} = p(pl.lat,pl.lng);
        list.push({id:pl.id,type:"plateforme",lat:pl.lat,lng:pl.lng,x,y,
          label:pl.nom.split(" ")[1]||pl.nom, sublabel:`Stock ${pl.stock} t`,
          icon:"🏗️",color:T.purple,bg:T.purpleL,priority:8,data:pl});
      });
    }
    return list.sort((a,b)=>(a.priority??9)-(b.priority??9));
  }, [zoomLevel, activeFilters]);

  // Route lines: transport → destination
  const routes = useMemo(() => {
    if (!activeFilters.includes("transports")) return [];
    return DEMO.transports.filter(t=>t.statut==="en_route").map(t => {
      const dest = DEMO.chaufferies.find(c=>t.destination.includes(c.nom.split(" ")[1]||"__"))
        || DEMO.plateformes.find(pl=>t.destination.includes(pl.nom.split(" ")[1]||"__"));
      if (!dest) return null;
      const from = project(t.lat,t.lng,center,zoom,W,H);
      const to = project(dest.lat,dest.lng,center,zoom,W,H);
      return {id:t.id,from,to};
    }).filter(Boolean);
  }, [markers, zoomLevel, activeFilters]);

  // Background grid style based on zoom
  const mapBg = zoom <= 1.5
    ? "linear-gradient(160deg,#D6E8F0 0%,#C5D9E5 100%)"  // France - ocean blue
    : zoom <= 3
    ? "linear-gradient(155deg,#E0ECDB 0%,#C8DFCA 60%,#B8D4BB 100%)"  // Region
    : "linear-gradient(155deg,#E8F4EC 0%,#D4EAD9 55%,#C6E2CF 100%)"; // Local

  return (
    <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`}
      style={{width:"100%",height:"100%",cursor:"crosshair"}}>
      <rect width={W} height={H} fill={`url(#mapBg)`} rx={4}/>
      <defs>
        <linearGradient id="mapBg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stopColor={zoom<=1.5?"#D6E8F0":zoom<=3?"#E0ECDB":"#E8F4EC"}/>
          <stop offset="60%"  stopColor={zoom<=1.5?"#C5D9E5":zoom<=3?"#C8DFCA":"#D4EAD9"}/>
          <stop offset="100%" stopColor={zoom<=1.5?"#B8CEE0":zoom<=3?"#B8D4BB":"#C6E2CF"}/>
        </linearGradient>
        <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.15"/>
        </filter>
        <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="3" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>

      {/* Grid */}
      {[1,2,3,4].map(i => (
        <g key={i} opacity="0.2">
          <line x1={i*W/5} y1={0} x2={i*W/5} y2={H} stroke="#fff" strokeWidth="1" strokeDasharray="5,5"/>
          <line x1={0} y1={i*H/5} x2={W} y2={i*H/5} stroke="#fff" strokeWidth="1" strokeDasharray="5,5"/>
        </g>
      ))}

      {/* Dept boundary hint at zoom 4+ */}
      {zoom >= 4 && (
        <ellipse cx={W/2} cy={H/2} rx={W*0.45} ry={H*0.42}
          fill="none" stroke="rgba(255,255,255,.25)" strokeWidth="1" strokeDasharray="8,4"/>
      )}

      {/* Transport routes */}
      {routes.map(r => (
        <g key={r.id}>
          <line x1={r.from.x} y1={r.from.y} x2={r.to.x} y2={r.to.y}
            stroke={T.purple} strokeWidth="1.5" strokeDasharray="7,4" opacity=".55"/>
          <circle cx={(r.from.x+r.to.x)/2} cy={(r.from.y+r.to.y)/2} r={3}
            fill={T.purple} opacity=".7"/>
        </g>
      ))}

      {/* Cluster rings for same location when zoomed out */}
      {zoom < 3 && (
        <>
          <circle cx={project(47.98,3.09,center,zoom,W,H).x}
            cy={project(47.98,3.09,center,zoom,W,H).y}
            r={20} fill={T.greenL} opacity=".3" stroke={T.green} strokeWidth="1"/>
        </>
      )}

      {/* Markers */}
      {markers.map(m => {
        const isHov = hov === m.id;
        const isSel = selectedId === m.id;
        const r = isSel ? 16 : isHov ? 15 : zoom >= 8 ? 13 : 11;
        return (
          <g key={m.id} style={{cursor:"pointer"}}
            onMouseEnter={()=>setHov(m.id)} onMouseLeave={()=>setHov(null)}
            onClick={()=>onMarkerClick(m.type, m.data)}
            filter={isSel?"url(#glow)":undefined}>
            {/* Selection ring */}
            {isSel && <circle cx={m.x} cy={m.y} r={r+7}
              fill="none" stroke={m.color} strokeWidth="2" opacity=".5"/>}
            {/* Pulse for en-route transports */}
            {m.type==="transport" && m.data.statut==="en_route" && (
              <circle cx={m.x} cy={m.y} r={r+4}
                fill={m.color} opacity=".2"/>
            )}
            {/* Shadow */}
            <circle cx={m.x} cy={m.y+2} r={r} fill="rgba(0,0,0,.12)"/>
            {/* Main circle */}
            <circle cx={m.x} cy={m.y} r={r}
              fill={m.bg} stroke={m.color}
              strokeWidth={isSel||isHov?2.5:1.5}/>
            {/* Icon */}
            <text x={m.x} y={m.y+(r>12?5:4)} textAnchor="middle"
              fontSize={r>12?r-2:r-1}>{m.icon}</text>
            {/* Label when zoomed or hovered */}
            {(isHov || isSel || zoom >= 6) && (
              <g>
                <rect x={m.x-40} y={m.y-r-20} width={80} height={18} rx={4}
                  fill="rgba(0,0,0,.8)"/>
                <text x={m.x} y={m.y-r-8} textAnchor="middle"
                  fontSize={9} fill="#fff" fontWeight="600">{m.label}</text>
              </g>
            )}
            {/* Sublabel on hover */}
            {isHov && (
              <g>
                <rect x={m.x-48} y={m.y+r+4} width={96} height={16} rx={3}
                  fill="rgba(0,0,0,.7)"/>
                <text x={m.x} y={m.y+r+14} textAnchor="middle"
                  fontSize={8} fill="rgba(255,255,255,.9)">{m.sublabel}</text>
              </g>
            )}
          </g>
        );
      })}

      {/* Zoom level indicator */}
      <g>
        <rect x={W-90} y={H-24} width={86} height={20} rx={4} fill="rgba(0,0,0,.6)"/>
        <text x={W-47} y={H-11} textAnchor="middle" fontSize={10} fill="#fff" fontWeight="500">
          {zoomLevel.label} · {markers.length} objets
        </text>
      </g>

      {/* Scale line */}
      <g opacity=".7">
        <line x1={12} y1={H-10} x2={60} y2={H-10} stroke="#fff" strokeWidth="2"/>
        <text x={36} y={H-14} textAnchor="middle" fontSize={8} fill="#fff">
          {zoom<=1?"200km":zoom<=2?"100km":zoom<=4?"20km":zoom<=8?"5km":"500m"}
        </text>
      </g>
    </svg>
  );
};

// ── FILTER PANEL ────────────────────────────────────────────────────────────────
const FILTERS = [
  {id:"proprietaires", icon:"👤", label:"Propriétaires", color:T.coral},
  {id:"opportunites",  icon:"💡", label:"Opportunités",  color:T.amber},
  {id:"visites",       icon:"🔭", label:"Visites",       color:T.blue},
  {id:"lots",          icon:"🌲", label:"Lots",          color:T.green},
  {id:"tas",           icon:"📦", label:"Tas",           color:"#8B6914"},
  {id:"transports",    icon:"🚛", label:"Transports",    color:T.purple},
  {id:"chaufferies",   icon:"🏭", label:"Chaufferies",   color:T.blue},
  {id:"plateformes",   icon:"🏗️", label:"Plateformes",   color:T.purple},
];

// ── DETAIL PANEL ────────────────────────────────────────────────────────────────
const DetailPanel = ({selected, onClose}) => {
  if (!selected) return (
    <div style={{padding:"20px 16px",textAlign:"center",color:T.tx3}}>
      <div style={{fontSize:32,marginBottom:8}}>📍</div>
      <div style={{fontSize:13,fontWeight:500,color:T.tx2}}>Cliquer un marqueur</div>
      <div style={{fontSize:11,marginTop:4}}>pour ouvrir la fiche</div>
    </div>
  );

  const {type, data} = selected;
  const cfg = typeConfig[type];

  const rows = {
    proprietaire: [["Commune",data.commune],["Surface",`${data.ha} ha`],["Téléphone",data.tel]],
    opportunite:  [["Volume estimé",`~${data.volumeT} t`],["Type",data.typeBois?.replace(/_/g," ")],["Statut",data.statut],["Urgence",data.urgence]],
    visite:       [["Date",data.date],["Agent",data.agent],["Volume",`${data.volumeT} t`],["Statut",data.statut]],
    lot:          [["Statut",lotBadge(data.statut)],["Essence",data.essence],["Volume estimé",`${data.volumeEstT} t`],["Volume réel",`${data.volumeReelT} t`],["Humidité",data.humidite?`${data.humidite} %`:"—"],["ETF",data.etf]],
    tas:          [["Lot",data.lotNum],["Volume",`${data.volumeT} t`],["Essence",data.essence],["Statut",data.statut]],
    transport:    [["Lot",data.lotNum],["Chauffeur",data.chauffeur],["Camion",data.camion],["Destination",data.destination],["Poids",`${data.poidsT} t`],["Départ",data.heure]],
    chaufferie:   [["Commune",data.commune],["Stock actuel",`${data.stock} t`],["Capacité/an",`${data.cap?.toLocaleString()} t`],["Hum. max",`${data.humMax} %`]],
    plateforme:   [["Commune",data.commune],["Stock actuel",`${data.stock} t`],["Capacité",`${data.cap?.toLocaleString()} t`],["Hum. moy.",`${data.humMoy} %`]],
  }[type] ?? [];

  const av = type==="lot" && data.volumeEstT
    ? Math.min(100,Math.round((data.volumeReelT/data.volumeEstT)*100)) : null;

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      <div style={{background:cfg.color,color:"#fff",padding:"12px 14px",flexShrink:0}}>
        <button onClick={onClose} style={{background:"none",border:"none",
          color:"rgba(255,255,255,.75)",fontSize:15,cursor:"pointer",
          padding:"2px 7px 2px 0",marginBottom:4}}>‹</button>
        <div style={{display:"flex",alignItems:"center",gap:9}}>
          <span style={{fontSize:22}}>{cfg.icon}</span>
          <div>
            <div style={{fontSize:14,fontWeight:600}}>
              {data.nom||data.numero||data.commune||data.camion||data.label||"—"}
            </div>
            <div style={{fontSize:10,opacity:.8}}>{cfg.label}</div>
          </div>
        </div>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"12px 14px"}}>
        {av !== null && (
          <div style={{marginBottom:12}}>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:4}}>
              <span style={{color:T.tx2}}>Avancement chantier</span>
              <span style={{fontWeight:600,color:T.green}}>{av} %</span>
            </div>
            <div style={{height:6,background:T.bg2,borderRadius:3,overflow:"hidden"}}>
              <div style={{height:"100%",width:`${av}%`,background:T.green,borderRadius:3}}/>
            </div>
          </div>
        )}
        {rows.map(([k,v],i) => (
          <div key={k} style={{display:"flex",justifyContent:"space-between",
            padding:"6px 0",borderBottom:i<rows.length-1?`0.5px solid ${T.bd}`:"none",
            fontSize:12}}>
            <span style={{color:T.tx2}}>{k}</span>
            <span style={{fontWeight:600}}>{v??"—"}</span>
          </div>
        ))}
        {/* GPS */}
        <div style={{marginTop:10,padding:"8px 10px",background:T.greenL,
          borderRadius:8,fontFamily:"monospace",fontSize:11,color:T.greenD}}>
          📍 {data.lat?.toFixed(5)}°N · {data.lng?.toFixed(5)}°E
        </div>
        {/* Mini workflow for lots */}
        {type==="lot" && (
          <div style={{marginTop:10}}>
            <div style={{fontSize:10,fontWeight:600,color:T.tx3,textTransform:"uppercase",
              letterSpacing:".05em",marginBottom:6}}>Statut filière</div>
            <div style={{display:"flex",alignItems:"center",gap:0,overflowX:"auto"}}>
              {["À visiter","Validé","Exploit.","Bord route","Transport","Livré"].map((s,i) => {
                const statuts=["A_VISITER","VALIDE_EXPLOITATION","EN_EXPLOITATION","BORD_ROUTE","EN_TRANSPORT","LIVRE"];
                const ci=statuts.indexOf(data.statut);
                const done=i<ci, active=i===ci;
                return (
                  <div key={s} style={{display:"flex",alignItems:"center",flexShrink:0}}>
                    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
                      <div style={{width:14,height:14,borderRadius:"50%",
                        background:done?T.green:active?T.amber:T.bg2,
                        border:`1.5px solid ${done?T.green:active?T.amber:T.bd2}`,
                        display:"flex",alignItems:"center",justifyContent:"center",
                        fontSize:7,color:done?"#fff":active?T.amberD:T.tx3}}>
                        {done?"✓":i+1}
                      </div>
                      <span style={{fontSize:7,color:done?T.greenD:active?T.amberD:T.tx3,
                        fontWeight:active?700:400,whiteSpace:"nowrap"}}>{s}</span>
                    </div>
                    {i<5&&<div style={{width:12,height:1.5,background:done?T.green:T.bg2,
                      margin:"0 1px",marginBottom:12}}/>}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ── STATS SIDEBAR ───────────────────────────────────────────────────────────────
const StatsBar = ({activeFilters}) => {
  const stats = [
    {label:"Propriétaires",n:DEMO.proprietaires.length,icon:"👤",color:T.coral,f:"proprietaires"},
    {label:"Opportunités",n:DEMO.opportunites.length,icon:"💡",color:T.amber,f:"opportunites"},
    {label:"Visites",n:DEMO.visites.length,icon:"🔭",color:T.blue,f:"visites"},
    {label:"Lots actifs",n:DEMO.lots.filter(l=>l.statut!=="CLOTURE").length,icon:"🌲",color:T.green,f:"lots"},
    {label:"Tas dispo.",n:DEMO.tas.filter(t=>t.statut==="pret").length,icon:"📦",color:"#8B6914",f:"tas"},
    {label:"Transports",n:DEMO.transports.filter(t=>t.statut==="en_route").length,icon:"🚛",color:T.purple,f:"transports"},
    {label:"Chaufferies",n:DEMO.chaufferies.length,icon:"🏭",color:T.blue,f:"chaufferies"},
    {label:"Plateformes",n:DEMO.plateformes.length,icon:"🏗️",color:T.purple,f:"plateformes"},
  ];
  return (
    <div style={{display:"flex",flexWrap:"wrap",gap:6,padding:"10px 14px",
      background:T.bg2,borderBottom:`1px solid ${T.bd}`}}>
      {stats.map(s => (
        <div key={s.label} style={{
          display:"flex",alignItems:"center",gap:5,padding:"4px 10px",
          borderRadius:8,background:activeFilters.includes(s.f)?"#fff":T.bg2,
          border:`1px solid ${activeFilters.includes(s.f)?s.color:T.bd}`,
          opacity:activeFilters.includes(s.f)?1:0.5,
        }}>
          <span style={{fontSize:13}}>{s.icon}</span>
          <span style={{fontSize:12,fontWeight:600,color:s.color}}>{s.n}</span>
          <span style={{fontSize:10,color:T.tx3}}>{s.label}</span>
        </div>
      ))}
    </div>
  );
};

// ── MAIN APP ────────────────────────────────────────────────────────────────────
export default function App() {
  const [zoomIdx, setZoomIdx] = useState(2); // Start at departement
  const [activeFilters, setActiveFilters] = useState([
    "lots","transports","chaufferies","plateformes","opportunites"
  ]);
  const [selected, setSelected] = useState(null);

  const zoomLevel = ZOOM_LEVELS[zoomIdx];

  const toggleFilter = (f) => setActiveFilters(prev =>
    prev.includes(f) ? prev.filter(x=>x!==f) : [...prev,f]
  );

  const handleMarkerClick = useCallback((type, data) => {
    setSelected({type,data});
  }, []);

  const zoomIn  = () => setZoomIdx(i => Math.min(i+1, ZOOM_LEVELS.length-1));
  const zoomOut = () => setZoomIdx(i => Math.max(i-1, 0));

  // Stats
  const transportEnRoute = DEMO.transports.filter(t=>t.statut==="en_route").length;
  const stockTotal = DEMO.chaufferies.reduce((s,c)=>s+c.stock,0) + DEMO.plateformes.reduce((s,p)=>s+p.stock,0);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      background:T.bg,color:T.tx}}>

      {/* Topbar */}
      <div style={{background:T.sb,color:"#fff",padding:"10px 16px",
        display:"flex",alignItems:"center",gap:12,flexShrink:0}}>
        <div style={{width:28,height:28,background:T.green,borderRadius:7,
          display:"flex",alignItems:"center",justifyContent:"center",
          fontSize:14,flexShrink:0}}>🌲</div>
        <div>
          <div style={{fontSize:14,fontWeight:700,letterSpacing:".02em"}}>APPLITAG</div>
          <div style={{fontSize:9,color:"#666",textTransform:"uppercase",letterSpacing:".04em"}}>Carte Métier</div>
        </div>
        <div style={{flex:1}}/>
        <div style={{display:"flex",gap:16,fontSize:12}}>
          {[
            [`${DEMO.lots.filter(l=>l.statut==="EN_EXPLOITATION").length} en exploit.`,T.blue],
            [`${transportEnRoute} transports`,T.purple],
            [`${stockTotal.toLocaleString()} t stock`,T.green],
          ].map(([l,c])=>(
            <div key={l} style={{display:"flex",alignItems:"center",gap:5}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:c}}/>
              <span style={{color:"#ccc"}}>{l}</span>
            </div>
          ))}
        </div>
      </div>

      <StatsBar activeFilters={activeFilters}/>

      {/* Main layout */}
      <div style={{flex:1,display:"flex",overflow:"hidden"}}>

        {/* Filter sidebar */}
        <div style={{width:160,background:"#fff",borderRight:`1px solid ${T.bd}`,
          display:"flex",flexDirection:"column",padding:"10px 8px",gap:4,flexShrink:0}}>
          <div style={{fontSize:10,fontWeight:700,color:T.tx3,textTransform:"uppercase",
            letterSpacing:".06em",padding:"4px 4px 6px"}}>Couches</div>
          {FILTERS.map(f => {
            const active = activeFilters.includes(f.id);
            return (
              <button key={f.id} onClick={()=>toggleFilter(f.id)} style={{
                display:"flex",alignItems:"center",gap:8,padding:"8px 9px",
                borderRadius:8,border:`1px solid ${active?f.color:T.bd}`,
                background:active?"#fff":T.bg2,cursor:"pointer",fontFamily:"inherit",
                transition:"all .1s",
              }}>
                <span style={{fontSize:14}}>{f.icon}</span>
                <span style={{fontSize:11,fontWeight:active?600:400,
                  color:active?f.color:T.tx3}}>{f.label}</span>
                {active && <div style={{marginLeft:"auto",width:6,height:6,
                  borderRadius:"50%",background:f.color}}/>}
              </button>
            );
          })}

          <div style={{height:1,background:T.bd,margin:"8px 0"}}/>

          {/* Zoom hierarchy */}
          <div style={{fontSize:10,fontWeight:700,color:T.tx3,textTransform:"uppercase",
            letterSpacing:".06em",padding:"2px 4px 6px"}}>Niveau</div>
          {ZOOM_LEVELS.map((z,i) => (
            <button key={z.level} onClick={()=>setZoomIdx(i)} style={{
              display:"flex",alignItems:"center",gap:7,padding:"7px 9px",
              borderRadius:7,border:`1px solid ${i===zoomIdx?T.green:T.bd}`,
              background:i===zoomIdx?T.greenL:T.bg2,cursor:"pointer",fontFamily:"inherit",
            }}>
              <span style={{fontSize:10,color:T.tx3,minWidth:14}}>{i+1}</span>
              <span style={{fontSize:11,fontWeight:i===zoomIdx?600:400,
                color:i===zoomIdx?T.greenD:T.tx2}}>{z.label}</span>
            </button>
          ))}
        </div>

        {/* Map area */}
        <div style={{flex:1,display:"flex",flexDirection:"column",position:"relative",
          minWidth:0}}>

          {/* Zoom breadcrumb */}
          <div style={{padding:"8px 14px",background:T.bg,borderBottom:`1px solid ${T.bd}`,
            display:"flex",alignItems:"center",gap:6,fontSize:11,flexShrink:0}}>
            {ZOOM_LEVELS.slice(0,zoomIdx+1).map((z,i) => (
              <span key={z.level} style={{display:"flex",alignItems:"center",gap:5}}>
                {i>0 && <span style={{color:T.tx3}}>›</span>}
                <button onClick={()=>setZoomIdx(i)} style={{
                  background:"none",border:"none",cursor:"pointer",
                  color:i===zoomIdx?T.green:T.tx2,
                  fontWeight:i===zoomIdx?600:400,
                  fontSize:11,fontFamily:"inherit",padding:"2px 4px",
                  borderRadius:4,
                }}>{z.label}</button>
              </span>
            ))}
            <span style={{marginLeft:"auto",display:"flex",gap:6}}>
              <button onClick={zoomOut} disabled={zoomIdx===0}
                style={{width:28,height:28,border:`1px solid ${T.bd}`,
                  borderRadius:7,background:"#fff",cursor:"pointer",
                  fontSize:14,display:"flex",alignItems:"center",justifyContent:"center",
                  opacity:zoomIdx===0?.4:1}}>−</button>
              <button onClick={zoomIn} disabled={zoomIdx===ZOOM_LEVELS.length-1}
                style={{width:28,height:28,border:`1px solid ${T.green}`,
                  borderRadius:7,background:T.greenL,cursor:"pointer",
                  fontSize:14,display:"flex",alignItems:"center",justifyContent:"center",
                  opacity:zoomIdx===ZOOM_LEVELS.length-1?.4:1,color:T.greenD}}>+</button>
            </span>
          </div>

          <div style={{flex:1,position:"relative",overflow:"hidden"}}>
            <MetierMap zoomLevel={zoomLevel} activeFilters={activeFilters}
              onMarkerClick={handleMarkerClick}
              selectedId={selected?.data?.id}/>

            {/* Legend overlay */}
            <div style={{position:"absolute",bottom:12,left:12,
              background:"rgba(255,255,255,.9)",borderRadius:10,
              padding:"8px 12px",fontSize:10,lineHeight:1.9,
              boxShadow:"0 2px 8px rgba(0,0,0,.12)"}}>
              {FILTERS.filter(f=>activeFilters.includes(f.id)).map(f=>(
                <div key={f.id} style={{display:"flex",alignItems:"center",gap:7}}>
                  <div style={{width:8,height:8,borderRadius:"50%",background:f.color}}/>
                  <span style={{color:T.tx2}}>{f.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Detail panel */}
        <div style={{width:260,minWidth:260,background:"#fff",
          borderLeft:`1px solid ${T.bd}`,overflowY:"auto",flexShrink:0}}>
          <DetailPanel selected={selected} onClose={()=>setSelected(null)}/>
        </div>
      </div>
    </div>
  );
}
