-- ============================================================
-- BoisEnergie MVP V1 — Schéma PostgreSQL complet
-- Version : 1.0 — Juin 2025
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS postgis;       -- coordonnées GPS
CREATE EXTENSION IF NOT EXISTS pg_trgm;       -- recherche texte

-- ============================================================
-- TYPES ÉNUMÉRÉS
-- ============================================================

CREATE TYPE statut_lot AS ENUM (
    'prospection',
    'disponible',
    'ordre_emis',
    'en_exploitation',
    'cloture'
);

CREATE TYPE statut_chantier AS ENUM (
    'planifie',
    'en_cours',
    'suspendu',
    'cloture',
    'annule'
);

CREATE TYPE statut_livraison AS ENUM (
    'planifiee',
    'en_transit',
    'livree',
    'signee',
    'litige'
);

CREATE TYPE type_acteur AS ENUM (
    'donneur_ordre',
    'exploitant',
    'operateur',
    'transporteur',
    'responsable_plateforme',
    'client_chaufferie',
    'admin'
);

CREATE TYPE type_certification AS ENUM (
    'aucune',
    'pefc',
    'fsc',
    'pefc_fsc'
);

CREATE TYPE granulometrie AS ENUM ('P45', 'P63', 'P100', 'P16');

CREATE TYPE type_mouvement AS ENUM ('entree', 'sortie', 'transfert');

CREATE TYPE severite_alerte AS ENUM ('info', 'warning', 'critical');

CREATE TYPE type_alerte AS ENUM (
    'humidite_hors_seuil',
    'ecart_poids',
    'retard_livraison',
    'incident_chantier',
    'non_conformite_qualite',
    'hors_zone_gps',
    'volume_depasse',
    'signature_manquante'
);

CREATE TYPE verdict_visite AS ENUM (
    'valide',
    'sous_reserve',
    'refuse'
);

CREATE TYPE meteo AS ENUM (
    'beau',
    'nuageux',
    'pluie_legere',
    'pluie_forte',
    'gel',
    'vent_fort'
);

-- ============================================================
-- TABLE : acteurs (tous les utilisateurs / organisations)
-- ============================================================

CREATE TABLE acteurs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type            type_acteur NOT NULL,
    raison_sociale  TEXT NOT NULL,
    siret           VARCHAR(14),
    email           TEXT UNIQUE,
    telephone       VARCHAR(20),
    adresse         TEXT,
    code_postal     VARCHAR(10),
    ville           TEXT,
    actif           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_acteurs_type ON acteurs(type);
CREATE INDEX idx_acteurs_email ON acteurs(email);

-- ============================================================
-- TABLE : utilisateurs (comptes applicatifs)
-- ============================================================

CREATE TABLE utilisateurs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    acteur_id       UUID NOT NULL REFERENCES acteurs(id) ON DELETE CASCADE,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    prenom          TEXT NOT NULL,
    nom             TEXT NOT NULL,
    role            type_acteur NOT NULL,
    actif           BOOLEAN NOT NULL DEFAULT TRUE,
    derniere_connexion TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_utilisateurs_acteur ON utilisateurs(acteur_id);

-- ============================================================
-- TABLE : lots (parcelles forestières)
-- ============================================================

CREATE TABLE lots (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference           TEXT NOT NULL UNIQUE,   -- PAR-YYYY-NNN auto
    commune             TEXT NOT NULL,
    departement         VARCHAR(3),
    surface_ha          DECIMAL(8,2),
    geom_point          GEOGRAPHY(POINT, 4326),   -- centroïde GPS
    geom_polygone       GEOGRAPHY(POLYGON, 4326), -- contour parcelle
    proprietaire_id     UUID NOT NULL REFERENCES acteurs(id),
    certification       type_certification NOT NULL DEFAULT 'aucune',
    numero_certificat   TEXT,
    validite_certificat DATE,
    statut              statut_lot NOT NULL DEFAULT 'prospection',
    notes               TEXT,
    created_by          UUID REFERENCES utilisateurs(id),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_surface_positive CHECK (surface_ha > 0)
);

CREATE INDEX idx_lots_statut ON lots(statut);
CREATE INDEX idx_lots_geom ON lots USING GIST(geom_point);
CREATE INDEX idx_lots_proprietaire ON lots(proprietaire_id);

-- Séquence pour la référence auto
CREATE SEQUENCE seq_lots_numero START 1;

CREATE OR REPLACE FUNCTION generer_reference_lot()
RETURNS TRIGGER AS $$
BEGIN
    NEW.reference := 'PAR-' || EXTRACT(YEAR FROM NOW()) || '-' ||
                     LPAD(nextval('seq_lots_numero')::TEXT, 3, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_reference_lot
    BEFORE INSERT ON lots
    FOR EACH ROW
    WHEN (NEW.reference IS NULL OR NEW.reference = '')
    EXECUTE FUNCTION generer_reference_lot();

-- ============================================================
-- TABLE : visites_terrain
-- ============================================================

CREATE TABLE visites_terrain (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lot_id              UUID NOT NULL REFERENCES lots(id) ON DELETE CASCADE,
    visiteur_id         UUID NOT NULL REFERENCES utilisateurs(id),
    date_visite         DATE NOT NULL,
    volume_estime_t     DECIMAL(10,2),
    type_acces          TEXT,
    portance_sol        TEXT,
    largeur_voie_m      DECIMAL(4,1),
    gps_acces           GEOGRAPHY(POINT, 4326),
    distance_plateforme_km DECIMAL(6,1),
    contrainte_zone_humide   BOOLEAN DEFAULT FALSE,
    contrainte_nidification  BOOLEAN DEFAULT FALSE,
    contrainte_natura2000    BOOLEAN DEFAULT FALSE,
    contrainte_reseaux       BOOLEAN DEFAULT FALSE,
    contrainte_autorisation  BOOLEAN DEFAULT FALSE,
    date_debut_souhaitee DATE,
    date_fin_souhaitee   DATE,
    remarques           TEXT,
    verdict             verdict_visite NOT NULL DEFAULT 'valide',
    motif_refus         TEXT,
    signature_url       TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_refus_motif CHECK (
        verdict != 'refuse' OR motif_refus IS NOT NULL
    )
);

CREATE INDEX idx_visites_lot ON visites_terrain(lot_id);

-- ============================================================
-- TABLE : essences_visite (détail par essence lors visite)
-- ============================================================

CREATE TABLE essences_visite (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visite_id       UUID NOT NULL REFERENCES visites_terrain(id) ON DELETE CASCADE,
    essence         TEXT NOT NULL,
    pourcentage     DECIMAL(5,2) NOT NULL,
    volume_estime_t DECIMAL(10,2),
    granulometrie_cible granulometrie DEFAULT 'P45',
    CONSTRAINT chk_pourcentage CHECK (pourcentage > 0 AND pourcentage <= 100)
);

-- ============================================================
-- TABLE : chantiers (ordres d'exploitation)
-- ============================================================

CREATE TABLE chantiers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference           TEXT NOT NULL UNIQUE,   -- OE-YYYY-NNN
    lot_id              UUID NOT NULL REFERENCES lots(id),
    visite_id           UUID REFERENCES visites_terrain(id),
    client_id           UUID NOT NULL REFERENCES acteurs(id),
    donneur_ordre_id    UUID NOT NULL REFERENCES utilisateurs(id),
    produit_cible       TEXT NOT NULL,
    granulometrie       granulometrie NOT NULL DEFAULT 'P45',
    volume_commande_t   DECIMAL(10,2) NOT NULL,
    volume_reel_t       DECIMAL(10,2) DEFAULT 0,
    humidite_cible_pct  DECIMAL(5,2) DEFAULT 35,
    prix_vente_eur_t    DECIMAL(8,2),
    statut              statut_chantier NOT NULL DEFAULT 'planifie',
    date_debut_prevue   DATE,
    date_fin_prevue     DATE,
    date_debut_reelle   DATE,
    date_fin_reelle     DATE,
    cahier_des_charges_url TEXT,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_volume_positif CHECK (volume_commande_t > 0),
    CONSTRAINT chk_visite_avant_chantier CHECK (visite_id IS NOT NULL)
);

CREATE INDEX idx_chantiers_lot ON chantiers(lot_id);
CREATE INDEX idx_chantiers_client ON chantiers(client_id);
CREATE INDEX idx_chantiers_statut ON chantiers(statut);

-- Transition de statut contrôlée
CREATE OR REPLACE FUNCTION valider_transition_chantier()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.statut = 'annule' OR OLD.statut = 'cloture' THEN
        RAISE EXCEPTION 'Chantier % ne peut plus changer de statut (état final)', OLD.reference;
    END IF;
    IF NEW.statut = 'en_cours' AND OLD.statut NOT IN ('planifie', 'suspendu') THEN
        RAISE EXCEPTION 'Transition invalide : % -> %', OLD.statut, NEW.statut;
    END IF;
    IF NEW.statut = 'cloture' AND OLD.statut != 'en_cours' THEN
        RAISE EXCEPTION 'Clôture impossible depuis l''état %', OLD.statut;
    END IF;
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_transition_chantier
    BEFORE UPDATE OF statut ON chantiers
    FOR EACH ROW EXECUTE FUNCTION valider_transition_chantier();

-- ============================================================
-- TABLE : equipe_chantier
-- ============================================================

CREATE TABLE equipe_chantier (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chantier_id     UUID NOT NULL REFERENCES chantiers(id) ON DELETE CASCADE,
    operateur_id    UUID NOT NULL REFERENCES utilisateurs(id),
    role            TEXT NOT NULL,  -- 'abatteur', 'debardeur', 'aide', 'conducteur_broyeur'
    machine         TEXT,
    immatriculation TEXT,
    date_debut      DATE,
    date_fin        DATE,
    UNIQUE(chantier_id, operateur_id)
);

-- ============================================================
-- TABLE : journaux_chantier (saisie quotidienne terrain)
-- ============================================================

CREATE TABLE journaux_chantier (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chantier_id     UUID NOT NULL REFERENCES chantiers(id) ON DELETE CASCADE,
    operateur_id    UUID NOT NULL REFERENCES utilisateurs(id),
    date_journee    DATE NOT NULL,
    tonnage_produit_t DECIMAL(8,2) NOT NULL DEFAULT 0,
    meteo           meteo,
    incident        TEXT,
    type_incident   TEXT,
    commentaire     TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(chantier_id, date_journee),
    CONSTRAINT chk_tonnage_positif CHECK (tonnage_produit_t >= 0)
);

CREATE INDEX idx_journaux_chantier ON journaux_chantier(chantier_id);

-- Mise à jour auto du volume réel
CREATE OR REPLACE FUNCTION maj_volume_reel_chantier()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE chantiers
    SET volume_reel_t = (
        SELECT COALESCE(SUM(tonnage_produit_t), 0)
        FROM journaux_chantier
        WHERE chantier_id = NEW.chantier_id
    )
    WHERE id = NEW.chantier_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_volume_reel
    AFTER INSERT OR UPDATE ON journaux_chantier
    FOR EACH ROW EXECUTE FUNCTION maj_volume_reel_chantier();

-- ============================================================
-- TABLE : tas (stocks sur parcelle / plateforme)
-- ============================================================

CREATE TABLE tas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chantier_id     UUID NOT NULL REFERENCES chantiers(id) ON DELETE CASCADE,
    reference       TEXT NOT NULL,  -- 'Tas A', 'Tas B'...
    essence         TEXT,
    volume_estime_t DECIMAL(8,2),
    gps_position    GEOGRAPHY(POINT, 4326),
    statut          TEXT NOT NULL DEFAULT 'en_constitution',
    -- 'en_constitution', 'pret', 'dechiquete', 'transporte'
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tas_chantier ON tas(chantier_id);
CREATE INDEX idx_tas_geom ON tas USING GIST(gps_position);

-- ============================================================
-- TABLE : clotures_chantier
-- ============================================================

CREATE TABLE clotures_chantier (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chantier_id             UUID NOT NULL UNIQUE REFERENCES chantiers(id),
    validateur_id           UUID NOT NULL REFERENCES utilisateurs(id),
    date_cloture            DATE NOT NULL DEFAULT CURRENT_DATE,
    tonnage_final_t         DECIMAL(10,2) NOT NULL,
    bilan_essences          JSONB,  -- {"peuplier": 200, "frene": 80}
    remanents_traites       BOOLEAN NOT NULL DEFAULT FALSE,
    remise_en_etat_ok       BOOLEAN NOT NULL DEFAULT FALSE,
    commentaire_chef        TEXT,
    rapport_url             TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABLE : dechiquetages
-- ============================================================

CREATE TABLE dechiquetages (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chantier_id         UUID NOT NULL REFERENCES chantiers(id),
    cloture_id          UUID NOT NULL REFERENCES clotures_chantier(id),
    operateur_id        UUID NOT NULL REFERENCES utilisateurs(id),
    date_dechiquetage   DATE NOT NULL,
    engin_broyeur       TEXT,
    immatriculation_engin TEXT,
    tas_ids             UUID[],  -- tableau des tas traités
    granulometrie       granulometrie NOT NULL,
    humidite_sortie_pct DECIMAL(5,2),
    volume_produit_t    DECIMAL(10,2) NOT NULL,
    plateforme_destination TEXT,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_humidite CHECK (humidite_sortie_pct BETWEEN 0 AND 100),
    CONSTRAINT chk_volume_dechiquetage CHECK (volume_produit_t > 0)
);

CREATE INDEX idx_dechiquetages_chantier ON dechiquetages(chantier_id);

-- ============================================================
-- TABLE : mouvements_stock
-- ============================================================

CREATE TABLE mouvements_stock (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type            type_mouvement NOT NULL,
    chantier_id     UUID REFERENCES chantiers(id),
    dechiquetage_id UUID REFERENCES dechiquetages(id),
    livraison_id    UUID,  -- FK livraisons (définie plus bas)
    plateforme      TEXT NOT NULL,
    essence         TEXT,
    granulometrie   granulometrie,
    tonnage_t       DECIMAL(10,2) NOT NULL,
    humidite_pct    DECIMAL(5,2),
    date_mouvement  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    operateur_id    UUID REFERENCES utilisateurs(id),
    notes           TEXT,
    CONSTRAINT chk_tonnage_mouvement CHECK (tonnage_t > 0)
);

CREATE INDEX idx_mouvements_type ON mouvements_stock(type);
CREATE INDEX idx_mouvements_plateforme ON mouvements_stock(plateforme);
CREATE INDEX idx_mouvements_date ON mouvements_stock(date_mouvement);

-- ============================================================
-- TABLE : transporteurs_vehicules
-- ============================================================

CREATE TABLE vehicules (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    transporteur_id     UUID NOT NULL REFERENCES acteurs(id),
    immatriculation     TEXT NOT NULL UNIQUE,
    type                TEXT NOT NULL DEFAULT 'tracteur',  -- 'tracteur', 'remorque', 'semi'
    ptac_t              DECIMAL(6,2),
    tare_t              DECIMAL(6,2),
    actif               BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABLE : livraisons (bons de livraison)
-- ============================================================

CREATE TABLE livraisons (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_bl               TEXT NOT NULL UNIQUE,   -- BL-YYYY-NNNN auto
    chantier_id             UUID NOT NULL REFERENCES chantiers(id),
    dechiquetage_id         UUID REFERENCES dechiquetages(id),
    client_id               UUID NOT NULL REFERENCES acteurs(id),
    transporteur_id         UUID NOT NULL REFERENCES acteurs(id),
    chauffeur_id            UUID REFERENCES utilisateurs(id),
    vehicule_camion_id      UUID REFERENCES vehicules(id),
    vehicule_remorque_id    UUID REFERENCES vehicules(id),
    produit                 TEXT NOT NULL,
    granulometrie           granulometrie NOT NULL,
    essence                 TEXT,
    -- Pesées
    poids_brut_depart_t     DECIMAL(8,3),
    tare_depart_t           DECIMAL(8,3),
    poids_net_depart_t      DECIMAL(8,3) GENERATED ALWAYS AS
                            (poids_brut_depart_t - tare_depart_t) STORED,
    poids_brut_arrivee_t    DECIMAL(8,3),
    tare_arrivee_t          DECIMAL(8,3),
    poids_net_arrivee_t     DECIMAL(8,3) GENERATED ALWAYS AS
                            (poids_brut_arrivee_t - tare_arrivee_t) STORED,
    ticket_bascule_ref      TEXT,
    -- GPS & horaires
    gps_depart              GEOGRAPHY(POINT, 4326),
    gps_arrivee             GEOGRAPHY(POINT, 4326),
    heure_depart            TIMESTAMPTZ,
    heure_arrivee           TIMESTAMPTZ,
    adresse_destination     TEXT,
    distance_km             DECIMAL(7,1),
    -- Signatures
    signature_chauffeur_url TEXT,
    signature_client_url    TEXT,
    date_signature_client   TIMESTAMPTZ,
    -- Statut
    statut                  statut_livraison NOT NULL DEFAULT 'planifiee',
    notes                   TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_livraisons_chantier ON livraisons(chantier_id);
CREATE INDEX idx_livraisons_client ON livraisons(client_id);
CREATE INDEX idx_livraisons_statut ON livraisons(statut);
CREATE INDEX idx_livraisons_date ON livraisons(heure_depart);

-- Ajout FK sur mouvements_stock
ALTER TABLE mouvements_stock
    ADD CONSTRAINT fk_mouvement_livraison
    FOREIGN KEY (livraison_id) REFERENCES livraisons(id);

-- Séquence BL
CREATE SEQUENCE seq_bl_numero START 1;
CREATE OR REPLACE FUNCTION generer_numero_bl()
RETURNS TRIGGER AS $$
BEGIN
    NEW.numero_bl := 'BL-' || EXTRACT(YEAR FROM NOW()) || '-' ||
                     LPAD(nextval('seq_bl_numero')::TEXT, 4, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_numero_bl
    BEFORE INSERT ON livraisons
    FOR EACH ROW
    WHEN (NEW.numero_bl IS NULL OR NEW.numero_bl = '')
    EXECUTE FUNCTION generer_numero_bl();

-- ============================================================
-- TABLE : controles_qualite
-- ============================================================

CREATE TABLE controles_qualite (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    livraison_id        UUID NOT NULL UNIQUE REFERENCES livraisons(id),
    controleur_id       UUID REFERENCES utilisateurs(id),
    date_controle       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    humidite_pct        DECIMAL(5,2) NOT NULL,
    methode_mesure      TEXT NOT NULL DEFAULT 'hygrometre_sonde',
    seuil_contractuel_pct DECIMAL(5,2) NOT NULL DEFAULT 35,
    granulometrie_constatee granulometrie,
    taux_fines_pct      DECIMAL(5,2),
    impuretes_pct       DECIMAL(5,2),
    pci_estime_kwh_t    DECIMAL(8,2) GENERATED ALWAYS AS
                        (CASE WHEN humidite_pct <= 60
                         THEN ROUND(CAST(3400 - humidite_pct * 17 AS NUMERIC), 2)
                         ELSE 0 END) STORED,
    conforme            BOOLEAN GENERATED ALWAYS AS
                        (humidite_pct <= seuil_contractuel_pct) STORED,
    observations        TEXT,
    penalite_eur_t      DECIMAL(8,2) DEFAULT 0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_humidite_qualite CHECK (humidite_pct BETWEEN 0 AND 100)
);

CREATE INDEX idx_qualite_livraison ON controles_qualite(livraison_id);
CREATE INDEX idx_qualite_conforme ON controles_qualite(conforme);

-- ============================================================
-- TABLE : couts_chantier (rentabilité)
-- ============================================================

CREATE TABLE couts_chantier (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chantier_id         UUID NOT NULL UNIQUE REFERENCES chantiers(id),
    abattage_eur_t      DECIMAL(8,2) DEFAULT 0,
    debardage_eur_t     DECIMAL(8,2) DEFAULT 0,
    broyage_eur_t       DECIMAL(8,2) DEFAULT 0,
    transport_eur_t     DECIMAL(8,2) DEFAULT 0,
    stockage_eur_t      DECIMAL(8,2) DEFAULT 0,
    frais_fixes_eur     DECIMAL(10,2) DEFAULT 0,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Vue rentabilité calculée
CREATE OR REPLACE VIEW v_rentabilite_chantier AS
SELECT
    c.id,
    c.reference,
    c.volume_commande_t,
    c.volume_reel_t,
    c.prix_vente_eur_t,
    cc.abattage_eur_t,
    cc.debardage_eur_t,
    cc.broyage_eur_t,
    cc.transport_eur_t,
    cc.stockage_eur_t,
    cc.frais_fixes_eur,
    (cc.abattage_eur_t + cc.debardage_eur_t + cc.broyage_eur_t +
     cc.transport_eur_t + cc.stockage_eur_t) AS cout_variable_eur_t,
    (c.prix_vente_eur_t - cc.abattage_eur_t - cc.debardage_eur_t -
     cc.broyage_eur_t - cc.transport_eur_t - cc.stockage_eur_t) AS marge_eur_t,
    ROUND(
        (c.prix_vente_eur_t - cc.abattage_eur_t - cc.debardage_eur_t -
         cc.broyage_eur_t - cc.transport_eur_t - cc.stockage_eur_t)
        * c.volume_reel_t - cc.frais_fixes_eur, 2
    ) AS marge_totale_eur,
    CASE WHEN c.prix_vente_eur_t > 0 THEN
        ROUND(
            ((c.prix_vente_eur_t - cc.abattage_eur_t - cc.debardage_eur_t -
              cc.broyage_eur_t - cc.transport_eur_t - cc.stockage_eur_t)
             / c.prix_vente_eur_t) * 100, 1
        )
    ELSE 0 END AS taux_marge_pct
FROM chantiers c
LEFT JOIN couts_chantier cc ON cc.chantier_id = c.id;

-- ============================================================
-- TABLE : documents (photos, PDFs, signatures)
-- ============================================================

CREATE TABLE documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type            TEXT NOT NULL,
    -- 'photo_lot', 'photo_visite', 'photo_chantier', 'photo_livraison',
    -- 'bon_achat', 'cmr', 'bl_pdf', 'rapport_cloture', 'certificat'
    ref_table       TEXT NOT NULL,  -- nom de la table parent
    ref_id          UUID NOT NULL,  -- id dans la table parent
    nom_fichier     TEXT NOT NULL,
    url_stockage    TEXT NOT NULL,
    taille_octets   INTEGER,
    mime_type       TEXT,
    uploaded_by     UUID REFERENCES utilisateurs(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_documents_ref ON documents(ref_table, ref_id);
CREATE INDEX idx_documents_type ON documents(type);

-- ============================================================
-- TABLE : alertes
-- ============================================================

CREATE TABLE alertes (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type            type_alerte NOT NULL,
    severite        severite_alerte NOT NULL DEFAULT 'warning',
    ref_table       TEXT,
    ref_id          UUID,
    message         TEXT NOT NULL,
    details         JSONB,
    destinataires   UUID[],  -- utilisateur_ids à notifier
    traitee         BOOLEAN NOT NULL DEFAULT FALSE,
    traitee_par     UUID REFERENCES utilisateurs(id),
    traitee_le      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_alertes_type ON alertes(type);
CREATE INDEX idx_alertes_traitee ON alertes(traitee);
CREATE INDEX idx_alertes_ref ON alertes(ref_table, ref_id);
CREATE INDEX idx_alertes_created ON alertes(created_at DESC);

-- ============================================================
-- TABLE : notifications (push / email)
-- ============================================================

CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alerte_id       UUID REFERENCES alertes(id),
    utilisateur_id  UUID NOT NULL REFERENCES utilisateurs(id),
    canal           TEXT NOT NULL DEFAULT 'app',  -- 'app', 'email', 'sms'
    titre           TEXT NOT NULL,
    corps           TEXT NOT NULL,
    lue             BOOLEAN NOT NULL DEFAULT FALSE,
    lue_le          TIMESTAMPTZ,
    envoyee         BOOLEAN NOT NULL DEFAULT FALSE,
    envoyee_le      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(utilisateur_id, lue);

-- ============================================================
-- TABLE : cmr (lettres de voiture)
-- ============================================================

CREATE TABLE cmr (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_cmr          TEXT NOT NULL UNIQUE,   -- CMR-YYYY-NNNN
    livraison_id        UUID NOT NULL UNIQUE REFERENCES livraisons(id),
    expediteur_id       UUID NOT NULL REFERENCES acteurs(id),
    destinataire_id     UUID NOT NULL REFERENCES acteurs(id),
    transporteur_id     UUID NOT NULL REFERENCES acteurs(id),
    adresse_chargement  TEXT NOT NULL,
    date_chargement     DATE NOT NULL,
    adresse_livraison   TEXT NOT NULL,
    marchandise         TEXT NOT NULL,
    nb_colis            INTEGER DEFAULT 1,
    poids_brut_kg       DECIMAL(10,2),
    instructions        TEXT,
    remarques_expediteur TEXT,
    remarques_chauffeur  TEXT,
    signature_expediteur_url TEXT,
    signature_chauffeur_url  TEXT,
    signature_destinataire_url TEXT,
    date_signature_dest  TIMESTAMPTZ,
    pdf_url             TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE SEQUENCE seq_cmr_numero START 1;
CREATE OR REPLACE FUNCTION generer_numero_cmr()
RETURNS TRIGGER AS $$
BEGIN
    NEW.numero_cmr := 'CMR-' || EXTRACT(YEAR FROM NOW()) || '-' ||
                      LPAD(nextval('seq_cmr_numero')::TEXT, 4, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_numero_cmr
    BEFORE INSERT ON cmr
    FOR EACH ROW
    WHEN (NEW.numero_cmr IS NULL OR NEW.numero_cmr = '')
    EXECUTE FUNCTION generer_numero_cmr();

-- ============================================================
-- VUES UTILITAIRES
-- ============================================================

-- Stock courant par plateforme
CREATE OR REPLACE VIEW v_stock_plateforme AS
SELECT
    plateforme,
    granulometrie,
    essence,
    SUM(CASE WHEN type = 'entree' THEN tonnage_t ELSE 0 END) AS entrees_t,
    SUM(CASE WHEN type = 'sortie' THEN tonnage_t ELSE 0 END) AS sorties_t,
    SUM(CASE WHEN type = 'entree' THEN tonnage_t
             WHEN type = 'sortie' THEN -tonnage_t ELSE 0 END) AS stock_t,
    AVG(CASE WHEN type = 'entree' THEN humidite_pct END) AS humidite_moy_pct
FROM mouvements_stock
GROUP BY plateforme, granulometrie, essence;

-- Tableau de bord donneur d'ordre
CREATE OR REPLACE VIEW v_dashboard_donneur_ordre AS
SELECT
    c.id,
    c.reference,
    l.commune AS localite,
    a.raison_sociale AS client,
    c.statut,
    c.volume_commande_t,
    c.volume_reel_t,
    ROUND((c.volume_reel_t / NULLIF(c.volume_commande_t, 0) * 100)::NUMERIC, 1) AS avancement_pct,
    c.prix_vente_eur_t,
    r.marge_eur_t,
    r.marge_totale_eur,
    (SELECT COUNT(*) FROM alertes al
     WHERE al.ref_table = 'chantiers' AND al.ref_id = c.id AND NOT al.traitee) AS alertes_ouvertes
FROM chantiers c
JOIN lots l ON l.id = c.lot_id
JOIN acteurs a ON a.id = c.client_id
LEFT JOIN v_rentabilite_chantier r ON r.id = c.id;

-- ============================================================
-- ROW LEVEL SECURITY (multi-tenant)
-- ============================================================

ALTER TABLE lots ENABLE ROW LEVEL SECURITY;
ALTER TABLE chantiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE livraisons ENABLE ROW LEVEL SECURITY;

-- Les donneurs d'ordre voient tout
CREATE POLICY pol_lots_donneur_ordre ON lots
    FOR ALL TO authenticated
    USING (
        current_setting('app.user_role') = 'donneur_ordre'
        OR
        current_setting('app.user_role') = 'admin'
    );

-- ============================================================
-- FONCTIONS UTILITAIRES
-- ============================================================

-- Calcul avancement chantier
CREATE OR REPLACE FUNCTION avancement_chantier(p_chantier_id UUID)
RETURNS DECIMAL AS $$
DECLARE v_pct DECIMAL;
BEGIN
    SELECT ROUND((volume_reel_t / NULLIF(volume_commande_t,0) * 100)::NUMERIC, 1)
    INTO v_pct FROM chantiers WHERE id = p_chantier_id;
    RETURN COALESCE(v_pct, 0);
END;
$$ LANGUAGE plpgsql STABLE;

-- Vérification écart de poids livraison
CREATE OR REPLACE FUNCTION ecart_poids_livraison(p_livraison_id UUID)
RETURNS DECIMAL AS $$
DECLARE
    v_depart DECIMAL; v_arrivee DECIMAL;
BEGIN
    SELECT poids_net_depart_t, poids_net_arrivee_t
    INTO v_depart, v_arrivee
    FROM livraisons WHERE id = p_livraison_id;
    IF v_depart IS NULL OR v_arrivee IS NULL THEN RETURN NULL; END IF;
    RETURN ROUND(ABS(v_arrivee - v_depart) / NULLIF(v_depart,0) * 100, 2);
END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================
-- FIN DU SCHÉMA
-- ============================================================
