# BoisEnergie MVP V1 — Specs API REST
# Version 1.0 — Juin 2025
# Base URL : https://api.bois-energie.app/v1

---

## Conventions générales

- Authentification : Bearer JWT (header `Authorization: Bearer <token>`)
- Format : JSON (Content-Type: application/json)
- Dates : ISO 8601 (2025-06-15T07:45:00Z)
- Coordonnées GPS : [longitude, latitude] (GeoJSON)
- Pagination : `?page=1&per_page=20` → retourne `{ data, meta: { total, page, per_page, last_page } }`
- Erreurs : `{ error: { code, message, details? } }`

---

## MODULE AUTH

### POST /auth/login
Connexion utilisateur.

Request:
```json
{
  "email": "jean.moreau@boisenergie.fr",
  "password": "motdepasse"
}
```
Response 200:
```json
{
  "token": "eyJhbGci...",
  "expires_at": "2025-07-15T00:00:00Z",
  "utilisateur": {
    "id": "uuid",
    "prenom": "Jean",
    "nom": "Moreau",
    "role": "exploitant",
    "acteur_id": "uuid"
  }
}
```

### POST /auth/logout
Response 204 (no content)

### GET /auth/me
Response 200: utilisateur courant (même structure que login)

---

## MODULE LOTS

### GET /lots
Liste des lots avec filtres.
Query params: `?statut=disponible&commune=Charny&page=1`

Response 200:
```json
{
  "data": [
    {
      "id": "uuid",
      "reference": "PAR-2025-007",
      "commune": "Charny",
      "departement": "89",
      "surface_ha": 12.5,
      "gps": { "type": "Point", "coordinates": [3.0891, 47.9812] },
      "proprietaire": { "id": "uuid", "raison_sociale": "M. Bernard" },
      "certification": "pefc",
      "statut": "disponible",
      "created_at": "2025-06-01T09:00:00Z"
    }
  ],
  "meta": { "total": 42, "page": 1, "per_page": 20, "last_page": 3 }
}
```

### POST /lots
Créer un lot.

Request:
```json
{
  "commune": "Charny",
  "departement": "89",
  "surface_ha": 12.5,
  "gps": { "type": "Point", "coordinates": [3.0891, 47.9812] },
  "gps_polygone": {
    "type": "Polygon",
    "coordinates": [[[3.088,47.980],[3.091,47.980],[3.091,47.983],[3.088,47.983],[3.088,47.980]]]
  },
  "proprietaire_id": "uuid",
  "certification": "pefc",
  "numero_certificat": "PEFC/10-31-1234",
  "validite_certificat": "2027-12-31",
  "notes": "Accès via chemin forestier km 3"
}
```
Response 201: lot créé complet

### GET /lots/:id
Response 200: lot complet avec visites et chantiers liés

### PATCH /lots/:id
Mise à jour partielle.

Request (exemple changement statut):
```json
{ "statut": "ordre_emis" }
```

### DELETE /lots/:id
Response 204 — uniquement si statut = 'prospection' ou 'disponible'

### POST /lots/:id/photos
Upload de photos (multipart/form-data).

Form fields:
- `file`: fichier image (JPEG/PNG, max 10 Mo)
- `type`: 'photo_lot' | 'photo_acces' | 'document_proprietaire'

Response 201:
```json
{
  "id": "uuid",
  "url": "https://storage.bois-energie.app/lots/uuid/photo.jpg",
  "type": "photo_lot",
  "created_at": "2025-06-01T09:30:00Z"
}
```

---

## MODULE VISITES TERRAIN

### GET /lots/:lot_id/visites
Liste des visites du lot.

### POST /lots/:lot_id/visites
Créer une visite terrain.

Request:
```json
{
  "visiteur_id": "uuid",
  "date_visite": "2025-06-10",
  "volume_estime_t": 350.0,
  "type_acces": "Chemin forestier praticable",
  "portance_sol": "Bonne",
  "largeur_voie_m": 4.5,
  "gps_acces": { "type": "Point", "coordinates": [3.0882, 47.9795] },
  "distance_plateforme_km": 12.0,
  "contraintes": {
    "zone_humide": false,
    "nidification": false,
    "natura2000": false,
    "reseaux": true,
    "autorisation": false
  },
  "date_debut_souhaitee": "2025-07-01",
  "date_fin_souhaitee": "2025-08-31",
  "remarques": "Réseaux souterrains côté nord — balisage requis",
  "essences": [
    { "essence": "Peuplier", "pourcentage": 65, "volume_estime_t": 227.5, "granulometrie_cible": "P45" },
    { "essence": "Frêne",    "pourcentage": 25, "volume_estime_t": 87.5,  "granulometrie_cible": "P45" },
    { "essence": "Saule",    "pourcentage": 10, "volume_estime_t": 35.0,  "granulometrie_cible": "P63" }
  ],
  "verdict": "valide"
}
```
Response 201: visite créée + lot.statut mis à jour si verdict = 'valide'

### PATCH /lots/:lot_id/visites/:id
Mise à jour (ex: ajout signature).
```json
{ "signature_url": "https://storage.../signature_visite.png" }
```

---

## MODULE CHANTIERS

### GET /chantiers
Filtres: `?statut=en_cours&client_id=uuid&lot_id=uuid`

Response 200:
```json
{
  "data": [
    {
      "id": "uuid",
      "reference": "OE-2025-042",
      "lot": { "id": "uuid", "reference": "PAR-2025-007", "commune": "Charny" },
      "client": { "id": "uuid", "raison_sociale": "Chaufferie Troyes" },
      "produit_cible": "Plaquette forestière",
      "granulometrie": "P45",
      "volume_commande_t": 350.0,
      "volume_reel_t": 182.0,
      "avancement_pct": 52.0,
      "prix_vente_eur_t": 62.0,
      "statut": "en_cours",
      "date_debut_reelle": "2025-06-03",
      "alertes_ouvertes": 1
    }
  ],
  "meta": { "total": 8, "page": 1, "per_page": 20, "last_page": 1 }
}
```

### POST /chantiers
Créer un ordre d'exploitation.

Request:
```json
{
  "lot_id": "uuid",
  "visite_id": "uuid",
  "client_id": "uuid",
  "produit_cible": "Plaquette forestière",
  "granulometrie": "P45",
  "volume_commande_t": 350.0,
  "humidite_cible_pct": 35.0,
  "prix_vente_eur_t": 62.0,
  "date_debut_prevue": "2025-07-01",
  "date_fin_prevue": "2025-08-15",
  "equipe": [
    { "operateur_id": "uuid", "role": "abatteur", "machine": "Tronçonneuse" },
    { "operateur_id": "uuid", "role": "debardeur", "machine": "Skidder", "immatriculation": "AB-234-CD" }
  ],
  "couts": {
    "abattage_eur_t": 5.0,
    "debardage_eur_t": 3.0,
    "broyage_eur_t": 8.0,
    "transport_eur_t": 14.0,
    "stockage_eur_t": 2.0,
    "frais_fixes_eur": 1200.0
  }
}
```
Response 201 + envoi notification équipe

### GET /chantiers/:id
Chantier complet avec journal, tas, coûts, alertes.

### PATCH /chantiers/:id/statut
Transition de statut contrôlée.
```json
{ "statut": "en_cours", "date_debut_reelle": "2025-07-01" }
```

### POST /chantiers/:id/journal
Saisie quotidienne terrain (mobile).

Request:
```json
{
  "operateur_id": "uuid",
  "date_journee": "2025-07-08",
  "tonnage_produit_t": 48.0,
  "meteo": "nuageux",
  "incident": null,
  "commentaire": "Bonne progression côté nord"
}
```
Response 201 + recalcul avancement automatique

### GET /chantiers/:id/journal
Historique journal avec avancement cumulé.

### POST /chantiers/:id/tas
Créer / mettre à jour un tas géolocalisé.

Request:
```json
{
  "reference": "Tas C",
  "essence": "Saule",
  "volume_estime_t": 35.0,
  "gps": { "type": "Point", "coordinates": [3.0895, 47.9808] },
  "statut": "en_constitution"
}
```

### POST /chantiers/:id/cloture
Clôturer un chantier.

Request:
```json
{
  "validateur_id": "uuid",
  "date_cloture": "2025-08-15",
  "tonnage_final_t": 342.0,
  "bilan_essences": { "Peuplier": 222, "Frêne": 85, "Saule": 35 },
  "remanents_traites": true,
  "remise_en_etat_ok": true,
  "commentaire_chef": "Chantier terminé dans les délais, légère dérive volume côté sud"
}
```
Response 200 + mise à jour lot.statut = 'cloture'

---

## MODULE DÉCHIQUETAGE

### POST /chantiers/:chantier_id/dechiquetages
Request:
```json
{
  "operateur_id": "uuid",
  "date_dechiquetage": "2025-08-16",
  "engin_broyeur": "Bandit 2590XP",
  "immatriculation_engin": "GH-789-IJ",
  "tas_ids": ["uuid-tas-a", "uuid-tas-b"],
  "granulometrie": "P45",
  "humidite_sortie_pct": 33.5,
  "volume_produit_t": 280.0,
  "plateforme_destination": "Plateforme Charny"
}
```
Response 201 + création mouvement_stock (entrée)

### GET /chantiers/:chantier_id/dechiquetages
Liste des sessions de déchiquetage.

---

## MODULE LIVRAISONS (BL)

### GET /livraisons
Filtres: `?statut=en_transit&client_id=uuid&date_from=2025-06-01`

### POST /livraisons
Créer un bon de livraison.

Request:
```json
{
  "chantier_id": "uuid",
  "dechiquetage_id": "uuid",
  "client_id": "uuid",
  "transporteur_id": "uuid",
  "chauffeur_id": "uuid",
  "vehicule_camion_id": "uuid",
  "vehicule_remorque_id": "uuid",
  "produit": "Plaquette forestière",
  "granulometrie": "P45",
  "essence": "Peuplier",
  "poids_brut_depart_t": 58.500,
  "tare_depart_t": 18.000,
  "adresse_destination": "Zone industrielle Est, 10000 Troyes",
  "distance_km": 87.0
}
```
Response 201: BL créé + CMR généré automatiquement

### GET /livraisons/:id
BL complet avec CMR, contrôle qualité, documents.

### PATCH /livraisons/:id/depart
Horodatage et GPS de départ.
```json
{
  "heure_depart": "2025-08-17T07:45:00Z",
  "gps_depart": { "type": "Point", "coordinates": [3.0891, 47.9812] },
  "signature_chauffeur_url": "https://storage.../sig_chauffeur.png"
}
```

### PATCH /livraisons/:id/arrivee
Horodatage, GPS et pesée à l'arrivée.
```json
{
  "heure_arrivee": "2025-08-17T09:10:00Z",
  "gps_arrivee": { "type": "Point", "coordinates": [4.0833, 48.2973] },
  "poids_brut_arrivee_t": 58.400,
  "tare_arrivee_t": 18.000,
  "ticket_bascule_ref": "TB-2025-04421"
}
```

### PATCH /livraisons/:id/signature-client
Enregistrer signature client.
```json
{
  "signature_client_url": "https://storage.../sig_client.png",
  "notes": "RAS"
}
```
Response 200 + statut → 'signee' + génération BL PDF + alerte si écart poids > 3%

### GET /livraisons/:id/pdf
Génère et retourne le PDF du BL signé.
Response: application/pdf

### GET /livraisons/:id/cmr
CMR associé complet.

---

## MODULE CONTRÔLE QUALITÉ

### POST /livraisons/:livraison_id/controle-qualite
Request:
```json
{
  "controleur_id": "uuid",
  "humidite_pct": 32.0,
  "methode_mesure": "hygrometre_sonde",
  "seuil_contractuel_pct": 35.0,
  "granulometrie_constatee": "P45",
  "taux_fines_pct": 3.8,
  "impuretes_pct": 0.2,
  "observations": "Lot conforme, aspect visuel satisfaisant"
}
```
Response 201: contrôle créé, `conforme` calculé automatiquement, alerte créée si non conforme.

### GET /livraisons/:livraison_id/controle-qualite
Résultat du contrôle qualité.

---

## MODULE STOCK

### GET /stock
Vue agrégée du stock par plateforme.
Query: `?plateforme=Charny&granulometrie=P45`

Response 200:
```json
{
  "data": [
    {
      "plateforme": "Plateforme Charny",
      "granulometrie": "P45",
      "essence": "Peuplier",
      "stock_t": 180.0,
      "entrees_t": 280.0,
      "sorties_t": 100.0,
      "humidite_moy_pct": 33.2
    }
  ]
}
```

### GET /stock/mouvements
Historique des mouvements.

---

## MODULE ALERTES

### GET /alertes
Filtres: `?traitee=false&severite=critical`

Response 200:
```json
{
  "data": [
    {
      "id": "uuid",
      "type": "humidite_hors_seuil",
      "severite": "warning",
      "message": "Humidité 38% dépasse le seuil 35% — Livraison BL-2025-0042",
      "ref_table": "livraisons",
      "ref_id": "uuid",
      "traitee": false,
      "created_at": "2025-08-17T09:15:00Z"
    }
  ],
  "meta": { "total": 3 }
}
```

### PATCH /alertes/:id/traiter
```json
{ "traitee_par": "uuid", "commentaire": "Pénalité appliquée selon contrat" }
```

---

## MODULE REPORTING

### GET /reporting/dashboard
Vue d'ensemble donneur d'ordre.

Response 200:
```json
{
  "periode": "2025",
  "chantiers": {
    "total": 8,
    "en_cours": 3,
    "planifies": 2,
    "clotures": 3
  },
  "volumes": {
    "commandes_t": 2850.0,
    "produits_t": 1420.0,
    "livres_t": 860.0,
    "avancement_pct": 49.8
  },
  "financier": {
    "ca_livre_eur": 53320.0,
    "marge_brute_eur": 32660.0,
    "marge_moy_eur_t": 37.98
  },
  "qualite": {
    "livraisons_conformes": 38,
    "livraisons_total": 41,
    "taux_conformite_pct": 92.7,
    "humidite_moy_pct": 32.4
  },
  "alertes_ouvertes": 3
}
```

### GET /reporting/chantiers
Tableau rentabilité par chantier.
Query: `?statut=cloture&date_from=2025-01-01`

### GET /reporting/export
Export Excel/CSV.
Query: `?format=xlsx&type=livraisons&date_from=2025-01-01&date_to=2025-12-31`
Response: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet

---

## MODULE DOCUMENTS & UPLOADS

### POST /upload
Upload générique de fichier (photos, PDFs).

Form fields:
- `file`: fichier
- `ref_table`: table de rattachement
- `ref_id`: id de l'enregistrement
- `type`: type de document

Response 201:
```json
{
  "id": "uuid",
  "url": "https://storage.bois-energie.app/...",
  "nom_fichier": "photo_chantier_001.jpg",
  "taille_octets": 2456789,
  "created_at": "..."
}
```

### GET /documents?ref_table=chantiers&ref_id=uuid
Liste des documents d'un enregistrement.

---

## Codes d'erreur métier

| Code          | HTTP | Description                                      |
|---------------|------|--------------------------------------------------|
| LOT_NO_GPS    | 422  | GPS requis pour créer un lot                     |
| LOT_NO_VISITE | 422  | Visite terrain requise avant ordre               |
| TRANSITION_INVALID | 422 | Transition de statut non autorisée            |
| POIDS_ECART   | 422  | Écart poids > 3% — vérification requise          |
| HUMIDITE_SEUIL| 200  | Livraison créée mais alerte qualité déclenchée   |
| CLOTURE_PHOTO | 422  | Photos fin de chantier requises pour clôture     |
| SIGNATURE_REQUISE | 422 | Signature manquante pour finaliser le BL       |
| CMR_INCOMPLET | 422  | Champs CMR obligatoires manquants                |
