-- ============================================================
-- BoisÉnergie — Schéma PostgreSQL V2
-- LOT = objet central (fusion LOT + CHANTIER)
-- 12 statuts + ANNULE · UUID · Soft delete · Audit trail
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE proprietaire_type AS ENUM (
  'particulier', 'societe', 'cooperative', 'commune', 'onf', 'sci', 'gaec'
);

CREATE TYPE certification_type AS ENUM (
  'aucune', 'pefc', 'fsc', 'pefc_fsc'
);

CREATE TYPE lot_statut AS ENUM (
  'BROUILLON',
  'A_VISITER',
  'VISITE_REALISEE',
  'VALIDE_EXPLOITATION',
  'EN_EXPLOITATION',
  'BORD_ROUTE',
  'A_DECHIQUETER',
  'DECHIQUETAGE_EN_COURS',
  'EN_TRANSPORT',
  'PARTIELLEMENT_LIVRE',
  'LIVRE',
  'CLOTURE',
  'ANNULE'
);

CREATE TYPE lot_type AS ENUM (
  'taillis', 'futaie', 'haie', 'bord_route', 'autre'
);

CREATE TYPE essence AS ENUM (
  'peuplier', 'frene', 'chene', 'acacia', 'saule',
  'bouleau', 'charme', 'aulne', 'orme', 'autre'
);

CREATE TYPE visite_verdict AS ENUM (
  'en_attente', 'valide', 'refuse', 'sous_reserve'
);

CREATE TYPE meteo AS ENUM (
  'beau', 'nuageux', 'pluie_legere', 'pluie_forte', 'gel', 'vent', 'arret'
);

CREATE TYPE incident_type AS ENUM (
  'aucun', 'panne_machine', 'accident', 'arret_meteo',
  'probleme_acces', 'autre'
);

CREATE TYPE tas_statut AS ENUM (
  'en_cours', 'pret', 'dechiquete', 'annule'
);

CREATE TYPE granulometrie AS ENUM (
  'p45', 'p63', 'p100'
);

CREATE TYPE transport_statut AS ENUM (
  'prepare', 'en_route', 'arrive', 'annule'
);

CREATE TYPE transport_type AS ENUM (
  'routier', 'ferroviaire', 'fluvial'
);

CREATE TYPE livraison_statut AS ENUM (
  'en_attente', 'livre', 'valide', 'litigieux', 'annule'
);

CREATE TYPE document_type AS ENUM (
  'photo', 'cmr', 'bl', 'rapport_visite',
  'ordre_exploitation', 'rapport_cloture',
  'contrat', 'signature', 'analyse_humidite'
);

CREATE TYPE user_role AS ENUM (
  'admin', 'exploitant', 'operateur', 'dechiqueteur',
  'transporteur', 'chauffeur', 'chaufferie'
);

CREATE TYPE litige_cause AS ENUM (
  'poids', 'humidite', 'granulometrie', 'autre'
);

CREATE TYPE litige_statut AS ENUM (
  'ouvert', 'en_resolution', 'resolu', 'abandonne'
);

-- ============================================================
-- UTILISATEURS
-- ============================================================

CREATE TABLE utilisateurs (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  nom           TEXT        NOT NULL,
  email         TEXT        NOT NULL UNIQUE,
  password_hash TEXT        NOT NULL,
  role          user_role   NOT NULL,
  actif         BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at    TIMESTAMPTZ
);

CREATE INDEX idx_utilisateurs_email ON utilisateurs (email);
CREATE INDEX idx_utilisateurs_role  ON utilisateurs (role);

-- ============================================================
-- PROPRIETAIRES
-- ============================================================

CREATE TABLE proprietaires (
  id         UUID              PRIMARY KEY DEFAULT gen_random_uuid(),
  type       proprietaire_type NOT NULL,
  nom        TEXT              NOT NULL,
  contact    TEXT,
  telephone  TEXT,
  email      TEXT,
  adresse    TEXT,
  created_at TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_proprietaires_nom ON proprietaires (nom);

-- ============================================================
-- ENTREPRISES ETF
-- ============================================================

CREATE TABLE entreprises_etf (
  id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  raison_sociale TEXT        NOT NULL,
  siret          TEXT        UNIQUE,
  telephone      TEXT,
  email          TEXT,
  adresse        TEXT,
  responsable    TEXT,
  agrement       TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at     TIMESTAMPTZ
);

-- ============================================================
-- SÉQUENCES POUR NUMÉROS MÉTIER
-- ============================================================

CREATE SEQUENCE lot_seq  START 1;
CREATE SEQUENCE bl_seq   START 1;
CREATE SEQUENCE cmr_seq  START 1;

CREATE OR REPLACE FUNCTION generate_numero_lot()
RETURNS TEXT LANGUAGE plpgsql AS $$
BEGIN
  RETURN 'LOT-' || TO_CHAR(NOW(), 'YYYY') || '-'
         || LPAD(NEXTVAL('lot_seq')::TEXT, 3, '0');
END;
$$;

CREATE OR REPLACE FUNCTION generate_numero_bl()
RETURNS TEXT LANGUAGE plpgsql AS $$
BEGIN
  RETURN 'BL-' || TO_CHAR(NOW(), 'YYYY') || '-'
         || LPAD(NEXTVAL('bl_seq')::TEXT, 4, '0');
END;
$$;

CREATE OR REPLACE FUNCTION generate_numero_cmr()
RETURNS TEXT LANGUAGE plpgsql AS $$
BEGIN
  RETURN 'CMR-' || TO_CHAR(NOW(), 'YYYY') || '-'
         || LPAD(NEXTVAL('cmr_seq')::TEXT, 4, '0');
END;
$$;

-- ============================================================
-- LOTS  (objet central = LOT + CHANTIER fusionnés)
-- ============================================================

CREATE TABLE lots (
  id                  UUID             PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Identité
  numero_lot          TEXT             NOT NULL UNIQUE DEFAULT generate_numero_lot(),
  statut              lot_statut       NOT NULL DEFAULT 'BROUILLON',
  type_lot            lot_type,
  date_creation       DATE             NOT NULL DEFAULT CURRENT_DATE,
  createur_id         UUID             NOT NULL REFERENCES utilisateurs(id),

  -- Gisement
  certification       BOOLEAN          NOT NULL DEFAULT FALSE,
  certification_type  certification_type NOT NULL DEFAULT 'aucune',
  certification_ref   TEXT,
  essence_principale  essence,
  volume_estime       NUMERIC(10,2),
  humidite_estimee    NUMERIC(5,2),
  gps_lat             DOUBLE PRECISION,
  gps_lng             DOUBLE PRECISION,
  commentaire         TEXT,

  -- Exploitation (ex-chantier)
  etf_id              UUID             REFERENCES entreprises_etf(id),
  responsable_id      UUID             REFERENCES utilisateurs(id),
  type_operation      TEXT,            -- abattage / débardage / abattage_debardage
  date_debut          DATE,
  date_fin_prevue     DATE,
  date_fin_reelle     DATE,
  machine             TEXT,

  -- Volumes calculés (mis à jour par triggers)
  volume_reel         NUMERIC(10,2)    NOT NULL DEFAULT 0,
  -- SUM(releves_journaliers.tonnage_t) WHERE lot_id = id
  volume_total_livre  NUMERIC(10,2)    NOT NULL DEFAULT 0,
  -- SUM(livraisons.poids_net) WHERE lot_id = id AND statut = 'valide'

  -- Annulation
  motif_annulation    TEXT,
  annule_par          UUID             REFERENCES utilisateurs(id),
  annule_le           TIMESTAMPTZ,

  -- Audit
  created_at          TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  deleted_at          TIMESTAMPTZ,

  CONSTRAINT chk_humidite_lot  CHECK (humidite_estimee  IS NULL OR humidite_estimee  BETWEEN 0 AND 100),
  CONSTRAINT chk_volume_lot    CHECK (volume_estime      IS NULL OR volume_estime     >= 0),
  CONSTRAINT chk_annule_motif  CHECK (
    statut != 'ANNULE' OR (motif_annulation IS NOT NULL AND LENGTH(motif_annulation) >= 10)
  )
);

CREATE INDEX idx_lots_statut       ON lots (statut);
CREATE INDEX idx_lots_createur     ON lots (createur_id);
CREATE INDEX idx_lots_etf          ON lots (etf_id);
CREATE INDEX idx_lots_statut_date  ON lots (statut, date_creation DESC);

-- ============================================================
-- LOT ↔ PROPRIÉTAIRES  (relation n:n)
-- ============================================================

CREATE TABLE lot_proprietaires (
  lot_id          UUID NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  proprietaire_id UUID NOT NULL REFERENCES proprietaires(id),
  role_sur_lot    TEXT,               -- ex. "propriétaire principal", "ayant droit"
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (lot_id, proprietaire_id)
);

CREATE INDEX idx_lot_prop_lot   ON lot_proprietaires (lot_id);
CREATE INDEX idx_lot_prop_prop  ON lot_proprietaires (proprietaire_id);

-- ============================================================
-- PARCELLES  (1 lot → n parcelles)
-- ============================================================

CREATE TABLE parcelles (
  id                   UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id               UUID          NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  reference_cadastrale TEXT,
  surface_ha           NUMERIC(10,4) NOT NULL,
  commune              TEXT          NOT NULL,
  gps_lat              DOUBLE PRECISION,
  gps_lng              DOUBLE PRECISION,
  acces_description    TEXT,
  contraintes          TEXT,
  created_at           TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at           TIMESTAMPTZ,
  CONSTRAINT chk_surface CHECK (surface_ha > 0)
);

CREATE INDEX idx_parcelles_lot     ON parcelles (lot_id);
CREATE INDEX idx_parcelles_commune ON parcelles (commune);

-- ============================================================
-- VISITES TERRAIN  (1 lot → n visites)
-- ============================================================

CREATE TABLE visites_terrain (
  id            UUID             PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id        UUID             NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  agent_id      UUID             NOT NULL REFERENCES utilisateurs(id),
  date_visite   DATE             NOT NULL,
  essences      JSONB            NOT NULL DEFAULT '[]',
  -- [{"essence":"peuplier","pct":65,"volume_t":200,"granulometrie":"p45"}]
  volume_estime NUMERIC(10,2),
  observations  TEXT,
  verdict       visite_verdict   NOT NULL DEFAULT 'en_attente',
  gps_lat       DOUBLE PRECISION,
  gps_lng       DOUBLE PRECISION,
  created_at    TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  deleted_at    TIMESTAMPTZ
);

CREATE INDEX idx_visites_lot     ON visites_terrain (lot_id);
CREATE INDEX idx_visites_verdict ON visites_terrain (verdict);

-- ============================================================
-- RELEVÉS JOURNALIERS  (lot_id direct, plus chantier_id)
-- ============================================================

CREATE TABLE releves_journaliers (
  id           UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id       UUID          NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  operateur_id UUID          NOT NULL REFERENCES utilisateurs(id),
  date         DATE          NOT NULL,
  tonnage_t    NUMERIC(10,2) NOT NULL,
  humidite_pct NUMERIC(5,2),
  meteo        meteo         NOT NULL DEFAULT 'beau',
  incident     incident_type NOT NULL DEFAULT 'aucun',
  notes        TEXT,
  created_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at   TIMESTAMPTZ,
  CONSTRAINT chk_tonnage     CHECK (tonnage_t    >= 0),
  CONSTRAINT chk_humidite_rj CHECK (humidite_pct IS NULL OR humidite_pct BETWEEN 0 AND 100),
  CONSTRAINT uq_releve_jour  UNIQUE (lot_id, operateur_id, date)
);

CREATE INDEX idx_releves_lot      ON releves_journaliers (lot_id);
CREATE INDEX idx_releves_date     ON releves_journaliers (date DESC);
CREATE INDEX idx_releves_lot_date ON releves_journaliers (lot_id, date DESC);

-- ============================================================
-- TAS  (lot_id direct, plus chantier_id)
-- ============================================================

CREATE TABLE tas (
  id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id           UUID        NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  numero_tas       TEXT        NOT NULL,
  gps_lat          DOUBLE PRECISION,
  gps_lng          DOUBLE PRECISION,
  volume_estime    NUMERIC(10,2),
  poids_estime     NUMERIC(10,2),
  essence          essence,
  humidite_estimee NUMERIC(5,2),
  complet          BOOLEAN     NOT NULL DEFAULT FALSE,
  statut           tas_statut  NOT NULL DEFAULT 'en_cours',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at       TIMESTAMPTZ,
  CONSTRAINT chk_humidite_tas CHECK (humidite_estimee IS NULL OR humidite_estimee BETWEEN 0 AND 100),
  CONSTRAINT uq_tas_numero    UNIQUE (lot_id, numero_tas)
);

CREATE INDEX idx_tas_lot    ON tas (lot_id);
CREATE INDEX idx_tas_statut ON tas (statut);
CREATE INDEX idx_tas_lot_statut ON tas (lot_id, statut);

-- ============================================================
-- DÉCHIQUETAGES  (lot_id direct)
-- ============================================================

CREATE TABLE dechiquetages (
  id                UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id            UUID          NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  etf_id            UUID          REFERENCES entreprises_etf(id),
  operateur_id      UUID          REFERENCES utilisateurs(id),
  immat_engin       TEXT          NOT NULL,
  engin_description TEXT,
  granulometrie     granulometrie NOT NULL,
  humidite_pct      NUMERIC(5,2),
  volume_charge_t   NUMERIC(10,2),
  date_operation    TIMESTAMPTZ,
  created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at        TIMESTAMPTZ,
  CONSTRAINT chk_humidite_d CHECK (humidite_pct IS NULL OR humidite_pct BETWEEN 0 AND 100),
  CONSTRAINT chk_volume_d   CHECK (volume_charge_t IS NULL OR volume_charge_t >= 0)
);

-- Liaison n:n entre déchiquetages et tas
CREATE TABLE dechiquetage_tas (
  dechiquetage_id UUID NOT NULL REFERENCES dechiquetages(id),
  tas_id          UUID NOT NULL REFERENCES tas(id),
  PRIMARY KEY (dechiquetage_id, tas_id)
);

CREATE INDEX idx_dechiquetages_lot ON dechiquetages (lot_id);
CREATE INDEX idx_dechiq_tas_d      ON dechiquetage_tas (dechiquetage_id);
CREATE INDEX idx_dechiq_tas_t      ON dechiquetage_tas (tas_id);

-- ============================================================
-- TRANSPORTS  (lot_id direct)
-- ============================================================

CREATE TABLE transports (
  id               UUID             PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id           UUID             NOT NULL REFERENCES lots(id) ON DELETE RESTRICT,
  etf_id           UUID             REFERENCES entreprises_etf(id),
  dechiquetage_id  UUID             REFERENCES dechiquetages(id),
  chauffeur        TEXT,
  immat_camion     TEXT,
  immat_remorque   TEXT,
  type_transport   transport_type   NOT NULL DEFAULT 'routier',
  cmr_reference    TEXT             UNIQUE DEFAULT generate_numero_cmr(),
  poids_brut_t     NUMERIC(10,3),
  poids_tare_t     NUMERIC(10,3),
  poids_net_t      NUMERIC(10,3)    GENERATED ALWAYS AS (poids_brut_t - poids_tare_t) STORED,
  gps_depart_lat   DOUBLE PRECISION,
  gps_depart_lng   DOUBLE PRECISION,
  heure_depart     TIMESTAMPTZ,
  heure_arrivee    TIMESTAMPTZ,
  statut           transport_statut NOT NULL DEFAULT 'prepare',
  created_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  deleted_at       TIMESTAMPTZ,
  CONSTRAINT chk_poids_t CHECK (poids_brut_t IS NULL OR poids_tare_t IS NULL
                                OR poids_brut_t >= poids_tare_t)
);

CREATE INDEX idx_transports_lot    ON transports (lot_id);
CREATE INDEX idx_transports_statut ON transports (statut);

-- ============================================================
-- LIVRAISONS
-- ============================================================

CREATE TABLE livraisons (
  id             UUID             PRIMARY KEY DEFAULT gen_random_uuid(),
  transport_id   UUID             NOT NULL REFERENCES transports(id) ON DELETE RESTRICT,
  lot_id         UUID             NOT NULL REFERENCES lots(id),
  numero_bl      TEXT             NOT NULL UNIQUE DEFAULT generate_numero_bl(),
  lot_reference  TEXT             NOT NULL,
  -- dénormalisé intentionnellement pour traçabilité permanente
  destination    TEXT,
  gps_lat        DOUBLE PRECISION,
  gps_lng        DOUBLE PRECISION,
  poids_entree   NUMERIC(10,3),
  poids_tare     NUMERIC(10,3),
  poids_net      NUMERIC(10,3)    GENERATED ALWAYS AS (poids_entree - poids_tare) STORED,
  humidite       NUMERIC(5,2),
  date_livraison TIMESTAMPTZ,
  receptionnaire TEXT,
  signature_url  TEXT,
  statut         livraison_statut NOT NULL DEFAULT 'en_attente',
  created_at     TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  deleted_at     TIMESTAMPTZ,
  CONSTRAINT chk_humidite_liv CHECK (humidite IS NULL OR humidite BETWEEN 0 AND 100),
  CONSTRAINT chk_poids_liv    CHECK (poids_entree IS NULL OR poids_tare IS NULL
                                    OR poids_entree >= poids_tare)
);

CREATE INDEX idx_livraisons_lot       ON livraisons (lot_id);
CREATE INDEX idx_livraisons_transport ON livraisons (transport_id);
CREATE INDEX idx_livraisons_statut    ON livraisons (statut);
CREATE INDEX idx_livraisons_bl        ON livraisons (numero_bl);

-- ============================================================
-- LITIGES
-- ============================================================

CREATE TABLE litiges (
  id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  livraison_id     UUID          NOT NULL REFERENCES livraisons(id),
  lot_id           UUID          NOT NULL REFERENCES lots(id),
  cause            litige_cause  NOT NULL,
  valeur_constatee NUMERIC(10,3),
  valeur_attendue  NUMERIC(10,3),
  description      TEXT,
  statut           litige_statut NOT NULL DEFAULT 'ouvert',
  resolution       TEXT,
  ouvert_par       UUID          NOT NULL REFERENCES utilisateurs(id),
  resolu_par       UUID          REFERENCES utilisateurs(id),
  opened_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  resolved_at      TIMESTAMPTZ,
  created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_litiges_lot      ON litiges (lot_id);
CREATE INDEX idx_litiges_statut   ON litiges (statut);
CREATE INDEX idx_litiges_livraison ON litiges (livraison_id);

-- ============================================================
-- DOCUMENTS
-- ============================================================

CREATE TABLE documents (
  id         UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  type       document_type NOT NULL,
  ref_type   TEXT          NOT NULL,
  ref_id     UUID          NOT NULL,
  url        TEXT          NOT NULL,
  created_by UUID          NOT NULL REFERENCES utilisateurs(id),
  created_at TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  CONSTRAINT chk_ref_type CHECK (ref_type IN (
    'lot','parcelle','visite_terrain','releve_journalier',
    'tas','dechiquetage','transport','livraison','litige'
  ))
);

CREATE INDEX idx_documents_ref  ON documents (ref_type, ref_id);
CREATE INDEX idx_documents_type ON documents (type);

-- ============================================================
-- TRIGGER : set_updated_at universel
-- ============================================================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$;

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'utilisateurs','proprietaires','entreprises_etf','lots','parcelles',
    'visites_terrain','releves_journaliers','tas','dechiquetages',
    'transports','livraisons'
  ] LOOP
    EXECUTE FORMAT(
      'CREATE TRIGGER trg_%s_updated_at
       BEFORE UPDATE ON %s
       FOR EACH ROW EXECUTE FUNCTION set_updated_at()', t, t);
  END LOOP;
END $$;

-- ============================================================
-- TRIGGER : volume_reel sur lots
-- Recalcule SUM(releves_journaliers.tonnage_t) WHERE lot_id
-- ============================================================

CREATE OR REPLACE FUNCTION sync_lot_volume_reel()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE lid UUID;
BEGIN
  lid := COALESCE(NEW.lot_id, OLD.lot_id);
  UPDATE lots SET
    volume_reel = (
      SELECT COALESCE(SUM(tonnage_t), 0)
      FROM releves_journaliers
      WHERE lot_id = lid AND deleted_at IS NULL
    ),
    updated_at = NOW()
  WHERE id = lid;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_sync_volume_reel
AFTER INSERT OR UPDATE OR DELETE ON releves_journaliers
FOR EACH ROW EXECUTE FUNCTION sync_lot_volume_reel();

-- ============================================================
-- TRIGGER : volume_total_livre sur lots
-- Recalcule SUM(livraisons.poids_net) WHERE lot_id AND statut='valide'
-- ============================================================

CREATE OR REPLACE FUNCTION sync_lot_volume_livre()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE lid UUID;
BEGIN
  lid := COALESCE(NEW.lot_id, OLD.lot_id);
  UPDATE lots SET
    volume_total_livre = (
      SELECT COALESCE(SUM(poids_net), 0)
      FROM livraisons
      WHERE lot_id = lid
        AND statut = 'valide'
        AND deleted_at IS NULL
    ),
    updated_at = NOW()
  WHERE id = lid;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_sync_volume_livre
AFTER INSERT OR UPDATE OF statut, poids_net ON livraisons
FOR EACH ROW EXECUTE FUNCTION sync_lot_volume_livre();

-- ============================================================
-- TRIGGER : statut automatique du lot depuis ses objets enfants
-- ============================================================

CREATE OR REPLACE FUNCTION auto_statut_lot()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  lid           UUID;
  nb_liv_total  INT;
  nb_liv_valide INT;
  nb_liv_en_att INT;
  nb_transport  INT;
BEGIN
  lid := COALESCE(NEW.lot_id, OLD.lot_id);

  SELECT
    COUNT(*)                              FILTER (WHERE deleted_at IS NULL),
    COUNT(*) FILTER (WHERE statut = 'valide'    AND deleted_at IS NULL),
    COUNT(*) FILTER (WHERE statut = 'en_attente' AND deleted_at IS NULL)
  INTO nb_liv_total, nb_liv_valide, nb_liv_en_att
  FROM livraisons WHERE lot_id = lid;

  SELECT COUNT(*) FILTER (WHERE statut != 'arrive' AND deleted_at IS NULL)
  INTO nb_transport
  FROM transports WHERE lot_id = lid;

  -- Toutes livrées et validées → LIVRE
  IF nb_liv_total > 0
     AND nb_liv_valide = nb_liv_total
     AND nb_transport = 0 THEN
    UPDATE lots SET statut = 'LIVRE', updated_at = NOW()
    WHERE id = lid AND statut NOT IN ('CLOTURE','ANNULE');

  -- Au moins une validée mais pas toutes → PARTIELLEMENT_LIVRE
  ELSIF nb_liv_valide > 0 AND nb_liv_valide < nb_liv_total THEN
    UPDATE lots SET statut = 'PARTIELLEMENT_LIVRE', updated_at = NOW()
    WHERE id = lid AND statut NOT IN ('CLOTURE','ANNULE');
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_auto_statut_lot
AFTER INSERT OR UPDATE OF statut ON livraisons
FOR EACH ROW EXECUTE FUNCTION auto_statut_lot();

-- ============================================================
-- TRIGGER : transition de statut lot — matrice complète
-- ============================================================

CREATE OR REPLACE FUNCTION check_lot_statut_transition()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  valid JSONB := '{
    "BROUILLON":              ["A_VISITER","ANNULE"],
    "A_VISITER":              ["VISITE_REALISEE","BROUILLON","ANNULE"],
    "VISITE_REALISEE":        ["VALIDE_EXPLOITATION","A_VISITER","ANNULE"],
    "VALIDE_EXPLOITATION":    ["EN_EXPLOITATION","ANNULE"],
    "EN_EXPLOITATION":        ["BORD_ROUTE","ANNULE"],
    "BORD_ROUTE":             ["A_DECHIQUETER","EN_EXPLOITATION","ANNULE"],
    "A_DECHIQUETER":          ["DECHIQUETAGE_EN_COURS","ANNULE"],
    "DECHIQUETAGE_EN_COURS":  ["EN_TRANSPORT","BORD_ROUTE","ANNULE"],
    "EN_TRANSPORT":           ["PARTIELLEMENT_LIVRE","LIVRE","ANNULE"],
    "PARTIELLEMENT_LIVRE":    ["LIVRE","EN_TRANSPORT","ANNULE"],
    "LIVRE":                  ["CLOTURE","ANNULE"],
    "CLOTURE":                [],
    "ANNULE":                 []
  }';
BEGIN
  IF NEW.statut = OLD.statut THEN RETURN NEW; END IF;
  IF NOT (valid->OLD.statut::TEXT @> TO_JSONB(NEW.statut::TEXT)) THEN
    RAISE EXCEPTION
      'Transition de statut invalide : % → % (lot %)',
      OLD.statut, NEW.statut, OLD.numero_lot;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_lot_transition
BEFORE UPDATE OF statut ON lots
FOR EACH ROW EXECUTE FUNCTION check_lot_statut_transition();

-- ============================================================
-- TRIGGER : vérification des 5 conditions de clôture
-- ============================================================

CREATE OR REPLACE FUNCTION check_cloture_conditions()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  nb_tas_ouverts     INT;
  nb_transport_ouverts INT;
  nb_pesees_manquantes INT;
  nb_docs_manquants  INT;
  nb_litiges_ouverts INT;
  msg TEXT := '';
BEGIN
  IF NEW.statut != 'CLOTURE' THEN RETURN NEW; END IF;

  -- 1. Tous les tas traités
  SELECT COUNT(*) INTO nb_tas_ouverts
  FROM tas WHERE lot_id = NEW.id
    AND statut NOT IN ('dechiquete','annule')
    AND deleted_at IS NULL;

  -- 2. Tous les transports livrés
  SELECT COUNT(*) INTO nb_transport_ouverts
  FROM transports WHERE lot_id = NEW.id
    AND statut != 'arrive'
    AND deleted_at IS NULL;

  -- 3. Pesées saisies sur toutes les livraisons
  SELECT COUNT(*) INTO nb_pesees_manquantes
  FROM livraisons WHERE lot_id = NEW.id
    AND poids_net IS NULL
    AND deleted_at IS NULL;

  -- 4. CMR + BL présents pour chaque transport/livraison
  SELECT COUNT(*) INTO nb_docs_manquants
  FROM transports t
  WHERE t.lot_id = NEW.id AND t.deleted_at IS NULL
    AND NOT EXISTS (
      SELECT 1 FROM documents d
      WHERE d.ref_type = 'transport' AND d.ref_id = t.id
        AND d.type = 'cmr' AND d.deleted_at IS NULL
    );

  -- 5. Aucun litige ouvert
  SELECT COUNT(*) INTO nb_litiges_ouverts
  FROM litiges WHERE lot_id = NEW.id
    AND statut IN ('ouvert','en_resolution');

  IF nb_tas_ouverts       > 0 THEN msg := msg || nb_tas_ouverts || ' tas non traité(s). '; END IF;
  IF nb_transport_ouverts > 0 THEN msg := msg || nb_transport_ouverts || ' transport(s) non arrivé(s). '; END IF;
  IF nb_pesees_manquantes > 0 THEN msg := msg || nb_pesees_manquantes || ' pesée(s) manquante(s). '; END IF;
  IF nb_docs_manquants    > 0 THEN msg := msg || nb_docs_manquants || ' CMR manquant(s). '; END IF;
  IF nb_litiges_ouverts   > 0 THEN msg := msg || nb_litiges_ouverts || ' litige(s) ouvert(s). '; END IF;

  IF LENGTH(msg) > 0 THEN
    RAISE EXCEPTION 'Clôture impossible — conditions non remplies : %', msg;
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_check_cloture
BEFORE UPDATE OF statut ON lots
FOR EACH ROW EXECUTE FUNCTION check_cloture_conditions();

-- ============================================================
-- VUE : tableau de bord stock bord de route
-- ============================================================

CREATE VIEW v_stock_bord_route AS
SELECT
  l.id                                                        AS lot_id,
  l.numero_lot,
  l.statut,
  COALESCE(SUM(t.volume_estime) FILTER (WHERE t.statut = 'pret'),    0) AS stock_disponible_t,
  COALESCE(SUM(t.volume_estime) FILTER (WHERE t.statut IN ('en_cours','pret')), 0) AS stock_previsionnel_t,
  COUNT(*)  FILTER (WHERE t.statut = 'pret')                          AS nb_tas_prets,
  COUNT(*)  FILTER (WHERE t.statut = 'en_cours')                      AS nb_tas_en_cours,
  COUNT(*)  FILTER (WHERE t.statut = 'dechiquete')                    AS nb_tas_dechiquetes
FROM lots l
LEFT JOIN tas t ON t.lot_id = l.id AND t.deleted_at IS NULL
WHERE l.deleted_at IS NULL
GROUP BY l.id, l.numero_lot, l.statut;

-- ============================================================
-- VUE : état de clôture d'un lot (dashboard)
-- ============================================================

CREATE VIEW v_lot_cloture_status AS
SELECT
  l.id                                                              AS lot_id,
  l.numero_lot,
  l.statut,
  COUNT(t.id)  FILTER (WHERE t.statut NOT IN ('dechiquete','annule')
                            AND t.deleted_at IS NULL)               AS tas_ouverts,
  COUNT(tr.id) FILTER (WHERE tr.statut != 'arrive'
                            AND tr.deleted_at IS NULL)              AS transports_ouverts,
  COUNT(li.id) FILTER (WHERE li.poids_net IS NULL
                            AND li.deleted_at IS NULL)              AS pesees_manquantes,
  COUNT(lg.id) FILTER (WHERE lg.statut IN ('ouvert','en_resolution')) AS litiges_ouverts,
  CASE WHEN
    COUNT(t.id)  FILTER (WHERE t.statut NOT IN ('dechiquete','annule') AND t.deleted_at IS NULL) = 0
    AND COUNT(tr.id) FILTER (WHERE tr.statut != 'arrive' AND tr.deleted_at IS NULL) = 0
    AND COUNT(li.id) FILTER (WHERE li.poids_net IS NULL AND li.deleted_at IS NULL) = 0
    AND COUNT(lg.id) FILTER (WHERE lg.statut IN ('ouvert','en_resolution')) = 0
  THEN TRUE ELSE FALSE END                                          AS pret_pour_cloture
FROM lots l
LEFT JOIN tas          t  ON t.lot_id       = l.id
LEFT JOIN transports   tr ON tr.lot_id      = l.id
LEFT JOIN livraisons   li ON li.lot_id      = l.id
LEFT JOIN litiges      lg ON lg.lot_id      = l.id
WHERE l.deleted_at IS NULL
GROUP BY l.id, l.numero_lot, l.statut;

-- ============================================================
-- INDEX COMPOSITES supplémentaires
-- ============================================================

CREATE INDEX idx_lots_statut_etf      ON lots (statut, etf_id);
CREATE INDEX idx_livraisons_lot_statut ON livraisons (lot_id, statut);
CREATE INDEX idx_transports_lot_statut ON transports (lot_id, statut);

-- ============================================================
-- FIN DU SCHÉMA V2
-- ============================================================
