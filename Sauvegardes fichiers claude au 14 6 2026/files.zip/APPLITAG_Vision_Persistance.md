# APPLITAG — Vision Produit & Persistance Phase 2

---

## APPLITAG VISION
### Le premier système d'exploitation du bois énergie

APPLITAG n'est pas un logiciel de suivi de chantier.

C'est une **plateforme verticale intégrée** pour la gestion, la traçabilité, le réseau, le marché et les données de la filière bois énergie française.

---

## Les 4 piliers

### 🌲 OPERATIONS — Le logiciel métier
Gestion bout en bout : Contact → Opportunité → Visite → Lot → Chantier → Déchiquetage → Transport → Livraison → Clôture.

CMR, BL, rapports chantier générés automatiquement. Zéro ressaisie, zéro perte de document.

**Clients cibles :** exploitants forestiers, ETF, coopératives forestières.
**Modèle :** SaaS mensuel/annuel, tarif par utilisateur ou par lot.

---

### 📡 NETWORK — Le réseau professionnel
Annuaire acteurs filière · Offres de bois disponible · Besoins combustible · Mise en relation B2B.

Déjà construit dans le modèle via Contact/Opportunité.

**Valeur :** plateforme de marché pour une filière sans place de marché numérique.

---

### 📺 MEDIA — Le média de référence
Émissions hebdo · Reportages terrain · Chronique marché · Interviews filière.

Contenu intégré dans l'app (onglet Actualités). Sponsoring fabricants engins, assureurs, prestataires.

**Horizon :** H2 2026, après 10+ clients actifs.

---

### 📊 DATA — La donnée exclusive
Prix observés agrégés anonymement · Stocks disponibles région · Humidité moyenne livrée · Tensions logistiques.

Ces données n'existent nulle part ailleurs. C'est le fossé économique défensif à long terme.

**Horizon :** H3 2027, après 30+ clients générant des données suffisantes.

---

## Chiffres clés — ce qui est déjà construit

| Livrable | Contenu |
|---|---|
| Schéma PostgreSQL | 22 modèles, 15 tables, triggers, vues |
| API REST | 12 ressources, 47 endpoints documentés |
| Écrans | 12 écrans navigables (web + mobile) |
| Règles métier | 47 règles sur 12 domaines |
| Workflow | 11 étapes, 18 transitions de statut |
| Documents | Bon d'achat, CMR, BL — auto-générés |
| Carte métier | 8 couches, 6 niveaux de zoom |
| Tests | 9/9 garde-fous workflow passés |

---

## Persistance Phase 2 — Architecture

### Schéma Prisma consolidé

```prisma
model Contact {
  id           String          @id @default(cuid())
  nom          String
  telephone    String
  typeContact  ContactType
  statut       ContactStatut   @default(nouveau)
  origine      ContactOrigine?
  commentaire  String?
  rappelPrevu  DateTime?
  gpsLat       Float?
  gpsLng       Float?
  createurId   String
  opportunites Opportunite[]
  lots         Lot[]
  createdAt    DateTime        @default(now())
  updatedAt    DateTime        @updatedAt
}

model Opportunite {
  id           String            @id @default(cuid())
  contactId    String
  contact      Contact           @relation(fields:[contactId],references:[id])
  commune      String?
  volumeEstime Decimal?
  typeBois     LotType?
  urgence      Urgence           @default(normale)
  statut       OppStatut         @default(nouvelle)
  notes        String?
  lotId        String?
  lot          Lot?              @relation(fields:[lotId],references:[id])
  createdAt    DateTime          @default(now())
}

model Lot {
  id                String       @id @default(cuid())
  numeroLot         String       @unique
  statut            LotStatut    @default(BROUILLON)
  commune           String
  essencePrincipale String?
  volumeEstime      Decimal?
  volumeReel        Decimal?
  surfaceHa         Decimal?
  humidite          Decimal?
  gpsLat            Float
  gpsLng            Float
  certification     String?
  etfNom            String?
  contactId         String?
  opportuniteId     String?
  tas               Tas[]
  transports        Transport[]
  livraisons        Livraison[]
  alertes           Alerte[]
  historiques       HistoriqueEvent[]
  createdAt         DateTime     @default(now())
}

model Tas {
  id           String      @id @default(cuid())
  lotId        String
  lot          Lot         @relation(fields:[lotId],references:[id])
  numeroTas    String
  volumeEstime Decimal
  essence      String
  statut       TasStatut   @default(en_cours)
  gpsLat       Float
  gpsLng       Float
  createdAt    DateTime    @default(now())
  @@unique([lotId, numeroTas])
}

model Transport {
  id             String           @id @default(cuid())
  lotId          String
  lot            Lot              @relation(fields:[lotId],references:[id])
  chauffeur      String
  immatriculation String
  destination    String
  statut         TransportStatut  @default(prepare)
  poidsT         Decimal?
  heureDepart    DateTime?
  heureArrivee   DateTime?
  gpsDepart      Json?
  gpsArrivee     Json?
  cmrNumero      String?
  livraison      Livraison?
  createdAt      DateTime         @default(now())
}

model Livraison {
  id              String    @id @default(cuid())
  lotId           String
  transportId     String    @unique
  transport       Transport @relation(fields:[transportId],references:[id])
  poidsBrutT      Decimal
  poidsTareT      Decimal
  poidsNetT       Decimal   @default(dbgenerated("poids_brut_t - poids_tare_t"))
  humidite        Decimal
  receptionnaire  String
  ticketBascule   String
  numeroBl        String    @unique
  statut          String    @default("en_attente")
  signatureUrl    String?
  createdAt       DateTime  @default(now())
}

model HistoriqueEvent {
  id           String   @id @default(cuid())
  lotId        String?
  lot          Lot?     @relation(fields:[lotId],references:[id])
  refType      String
  refId        String
  action       String
  message      String
  utilisateur  String
  data         Json?
  createdAt    DateTime @default(now())
}
```

---

### Endpoints CRUD consolidés

#### /api/contacts
```
POST   /api/contacts                 Créer (nom+tel+type = seuls champs requis)
GET    /api/contacts                 Liste (filtres: type, statut, search, page)
GET    /api/contacts/:id             Fiche + opportunités liées
PATCH  /api/contacts/:id             Modifier
PATCH  /api/contacts/:id/statut      Changer statut (garde-fous)
DELETE /api/contacts/:id             Soft delete
```

#### /api/opportunities
```
POST   /api/opportunities            Créer depuis contactId
GET    /api/opportunities            Pipeline (filtres: statut, urgence, commune)
GET    /api/opportunities/:id        Fiche + contact + lot lié
PATCH  /api/opportunities/:id/statut Avancer statut (garde-fous canDoOppAction)
POST   /api/opportunities/:id/convert Créer lot depuis opportunité
```

#### /api/lots
```
POST   /api/lots                     Créer
GET    /api/lots                     Liste + filtres (statut, commune, etf, page)
GET    /api/lots/:id                 Fiche complète (tas, transports, livraisons, alertes)
PATCH  /api/lots/:id/statut          Transition statut (garde-fous canDoLotAction)
GET    /api/lots/:id/cloture-status  Vérifier 5 conditions de clôture
DELETE /api/lots/:id                 Soft delete (admin uniquement, si aucun enfant)
```

#### /api/stacks (Tas)
```
POST   /api/lots/:lotId/stacks       Créer tas (GPS obligatoire)
GET    /api/lots/:lotId/stacks       Liste tas du lot
PATCH  /api/stacks/:id/complete      Marquer complet → statut pret
PATCH  /api/stacks/:id               Modifier (opérateur: ses propres tas seulement)
```

#### /api/transports
```
POST   /api/lots/:lotId/transports   Créer transport (garde-fous statut lot)
GET    /api/transports               Liste active + filtres
PATCH  /api/transports/:id/depart    Valider départ (GPS + heure)
PATCH  /api/transports/:id/arrivee   Confirmer arrivée
```

#### /api/deliveries (Livraisons)
```
POST   /api/transports/:id/delivery  Créer livraison (pesée)
PATCH  /api/deliveries/:id/validate  Valider réception + signer BL
PATCH  /api/deliveries/:id/dispute   Ouvrir litige
```

#### /api/history
```
GET    /api/lots/:lotId/history      Audit trail lot
GET    /api/history                  Global (admin)
```

---

### Fallback mock / API

```typescript
// useStore.ts — Zustand avec fallback
const useLotStore = create((set, get) => ({
  lots: [],
  loading: false,

  fetchLots: async () => {
    set({ loading: true });
    try {
      const res = await fetch('/api/lots');
      if (!res.ok) throw new Error('API unavailable');
      const data = await res.json();
      set({ lots: data.items, loading: false });
    } catch {
      // Fallback: charger les données mock
      console.warn('[APPLITAG] API indisponible — mode mock');
      set({ lots: MOCK_LOTS, loading: false });
    }
  },

  updateLotStatut: async (id, statut) => {
    const lot = get().lots.find(l => l.id === id);
    const check = canDoLotAction(lot.statut, statutToAction(statut));
    if (!check.allowed) throw new Error(check.reason);

    try {
      await fetch(`/api/lots/${id}/statut`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ statut }),
      });
    } catch {
      // Optimistic update en mode mock
    }
    set({ lots: get().lots.map(l => l.id === id ? { ...l, statut } : l) });
  },
}));
```

---

### Variables d'environnement

```env
DATABASE_URL="postgresql://applitag:password@localhost:5432/applitag_db"
JWT_SECRET="applitag-secret-min-32-chars-xxxxxxxx"
JWT_EXPIRY="24h"
S3_BUCKET="applitag-documents"
S3_REGION="eu-west-3"
PORT=3000
NODE_ENV=development
DEMO_MODE=true
```

### Commandes de démarrage

```bash
# 1. Migration initiale
npx prisma migrate dev --name init_phase2

# 2. Client Prisma
npx prisma generate

# 3. Seed complet (contacts + opportunités + lots + tas + transports)
npx prisma db seed

# 4. Lancer API NestJS
npm run start:dev

# 5. Vérifier les tests API
npm run test:api
```

---

*Document généré par APPLITAG · Sprint Persistance Phase 2*
