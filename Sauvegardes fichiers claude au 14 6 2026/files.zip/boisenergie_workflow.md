# BoisÉnergie — Workflow Exact de l'Application
## 11 étapes · Rôles · Actions · Validations · Automatismes

---

## CONVENTIONS

| Symbole | Signification |
|---|---|
| `→ STATUT` | Transition déclenchée |
| `[AUTO]` | Exécuté automatiquement sans action utilisateur |
| `[NOTIF]` | Notification envoyée (email + SMS + push) |
| `[BLOC]` | Bloque l'action si condition non remplie |
| `[LOG]` | Entrée créée dans `historiques` |
| `[OFFLINE]` | Fonctionne sans réseau, sync à la reconnexion |

---

## VUE GLOBALE — Cycle complet

```
EXPLOITANT          TERRAIN / ETF         LOGISTIQUE           CHAUFFERIE
     │                    │                    │                    │
 ①  Création lot          │                    │                    │
     │→ A_VISITER         │                    │                    │
     │                    │                    │                    │
 ②  ─────────────→  Visite terrain            │                    │
     │               → VISITE_REALISEE         │                    │
     │                    │                    │                    │
 ③  Validation exploit.   │                    │                    │
     │→ VALIDE_EXPLOIT.    │                    │                    │
     │                    │                    │                    │
 ④  ─────────────→  Démarrage chantier        │                    │
     │               → EN_EXPLOITATION          │                    │
     │                    │                    │                    │
 ⑤  ─────────────→  Saisie fin de service     │                    │
     │               → TAS créés               │                    │
     │                    │                    │                    │
 ⑥  ─────────────→  Clôture exploitation     │                    │
     │               → BORD_ROUTE              │                    │
     │                    │                    │                    │
 ⑦  Programmation        │                    │                    │
     déchiquetage         │                    │                    │
     │→ A_DECHIQUETER     │                    │                    │
     │                    │                    │                    │
 ⑧  ─────────────────────→  Déchiquetage +    │                    │
     │                       Chargement        │                    │
     │                    → EN_TRANSPORT        │                    │
     │                                         │                    │
 ⑨  ─────────────────────────────────→  Transport               │
     │                                  GPS + confirmations       │
     │                                                             │
 ⑩  ──────────────────────────────────────────────────→  Livraison
     │                                                   → LIVRE    │
     │                                                              │
 ⑪  Clôture lot                                                   │
     → CLOTURE                                                      │
```

---

## ÉTAPE 1 — CRÉATION LOT

### Acteur : Exploitant
### Écran : "Créer un lot"

**Séquence d'actions :**

```
1. Exploitant ouvre "Créer un lot"
2. Saisit le nom du chantier
3. Sélectionne le type de lot :
     - Bois sur pied
     - Bois abattu à débarder
     - Bois bord de route
     - Bois sur plateforme
     - Bois déjà déchiqueté
4. Saisit ou sélectionne le propriétaire
5. Saisit la parcelle (commune + GPS)        [OFFLINE]
6. Renseigne la certification
7. Définit la date limite d'exploitation
8. Appuie sur "Créer le lot"
```

**Validations bloquantes :**
```
[BLOC] commune IS NOT NULL
[BLOC] gps_lat IS NOT NULL AND gps_lng IS NOT NULL
[BLOC] proprietaire_id IS NOT NULL
[BLOC] type_lot IS NOT NULL
```

**Automatismes déclenchés :**
```
[AUTO] numero_lot = generate_numero_lot()        → LOT-AAAA-XXX
[AUTO] createur_id = utilisateur connecté
[AUTO] date_creation = NOW()
[AUTO] statut = 'A_VISITER'
[LOG]  action = 'LOT_CREE'
[NOTIF] → responsable terrain assigné
         Sujet : "Nouveau lot à visiter : LOT-AAAA-XXX — Commune"
```

**Résultat :**
```
lot.statut → A_VISITER
```

---

## ÉTAPE 2 — VISITE TERRAIN

### Acteur : Technicien / Opérateur terrain
### Écran : "Visite parcelle"

**Séquence d'actions :**

```
1. Technicien reçoit notification, ouvre la fiche lot
2. Sur place :
     a. GPS capturé automatiquement à l'ouverture   [AUTO][OFFLINE]
     b. Photos parcelle (min 2)                      [OFFLINE]
     c. Saisie essences présentes + % + volume estimé
     d. Surface estimée (ha)
     e. Contraintes cochées :
          □ Ligne EDF     □ Ligne télécom   □ Pente forte
          □ Zone humide   □ Voisinage       □ Route limitée
          □ Rémanents     □ Natura 2000
     f. Accès camion : Praticable / Difficile / Impossible
     g. Durée prévue exploitation (jours)
     h. Date limite exploitation
     i. Observations texte libre
3. Appuie sur "VALIDER VISITE"
```

**Validations bloquantes :**
```
[BLOC] gps_lat IS NOT NULL AND gps_lng IS NOT NULL
[BLOC] COUNT(photos liées) >= 2
[BLOC] volume_estime > 0
[BLOC] COUNT(essences) >= 1
[BLOC] SUM(essences.pct) BETWEEN 98 AND 102
[BLOC] acces_camion IS NOT NULL
```

**Automatismes déclenchés :**
```
[AUTO] visite.validation = true
[AUTO] lot.statut → VISITE_REALISEE
[AUTO] lot.volume_estime mis à jour depuis SUM(essences.volume_t)
[LOG]  action = 'VISITE_VALIDEE', utilisateur_id, gps_lat, gps_lng
[AUTO] Génération bon d'achat PDF (si certification = true)
[AUTO] Génération ordre d'exploitation PDF (brouillon)
[NOTIF → exploitant]
       Sujet : "Visite réalisée — LOT-AAAA-XXX"
       Corps : Volume estimé, essences, accès, contraintes
```

**Résultat :**
```
lot.statut → VISITE_REALISEE
visite.validation = true  →  non modifiable (sauf admin / exploitant)
```

---

## ÉTAPE 3 — VALIDATION EXPLOITATION

### Acteur : Exploitant
### Écran : "Programmation chantier"

**Séquence d'actions :**

```
1. Exploitant consulte la visite validée
2. Sélectionne l'entreprise ETF
3. Affecte les opérateurs (liste déroulante depuis users ETF)
4. Renseigne :
     - Type d'opération : Abattage / Débardage / Abattage+Débardage
     - Machine(s) utilisée(s)
     - Date début prévue
     - Date fin prévue
5. Vérifie les autorisations présentes (checkbox)
6. Collecte la signature propriétaire (tablette ou lien SMS)
7. Appuie sur "AUTORISER EXPLOITATION"
```

**Validations bloquantes :**
```
[BLOC] lot.statut = 'VISITE_REALISEE'
[BLOC] visite.validation = true
[BLOC] entreprise_etf_id IS NOT NULL
[BLOC] COUNT(operateurs affectés) >= 1
[BLOC] date_debut IS NOT NULL
[BLOC] signature_proprietaire IS NOT NULL
```

**Automatismes déclenchés :**
```
[AUTO] lot.statut → VALIDE_EXPLOITATION
[AUTO] Génération ordre d'exploitation PDF signé
[LOG]  action = 'VALIDATION_EXPLOITATION'
       ancienne_valeur = {statut: 'VISITE_REALISEE'}
       nouvelle_valeur = {statut: 'VALIDE_EXPLOITATION', etf_id, operateurs}
[NOTIF → ETF / Chef de chantier]
       Sujet : "Chantier autorisé — LOT-AAAA-XXX"
       Corps : Dates, opérateurs, accès, plan parcelle
[NOTIF → Opérateurs affectés]
       Sujet : "Vous êtes affecté au chantier LOT-AAAA-XXX"
```

**Résultat :**
```
lot.statut → VALIDE_EXPLOITATION
```

---

## ÉTAPE 4 — DÉMARRAGE CHANTIER

### Acteur : ETF / Chef de chantier
### Écran : "Début exploitation"

**Séquence d'actions :**

```
1. Chef chantier ouvre la fiche lot depuis son dashboard
2. Confirme la présence de l'équipe sur place
3. Valide la machine (immatriculation ou désignation)
4. Confirme la présence des opérateurs
5. Optionnel : photo de l'entrée de parcelle
6. Appuie sur "DÉMARRER LE CHANTIER"
```

**Validations bloquantes :**
```
[BLOC] lot.statut = 'VALIDE_EXPLOITATION'
[BLOC] utilisateur.role IN ('admin', 'exploitant', 'operateur')
[BLOC] utilisateur.entreprise_id = lot.etf_id  (sécurité)
```

**Automatismes déclenchés :**
```
[AUTO] chantier.date_debut = TODAY
[AUTO] lot.statut → EN_EXPLOITATION
[LOG]  action = 'CHANTIER_DEMARRE', gps capturé
[NOTIF → exploitant]
       "Chantier démarré — LOT-AAAA-XXX — [date heure]"
```

**Résultat :**
```
lot.statut → EN_EXPLOITATION
```

---

## ÉTAPE 5 — SAISIE FIN DE SERVICE

### Acteur : Opérateur terrain
### Écran : "Saisie production"
### Contrainte UX : max 3 écrans, offline, saisie rapide

**Séquence d'actions :**

```
Écran 1 — Production du jour
  1. Nombre de tas créés aujourd'hui
  2. Volume estimé par tas (ou global)
  3. Poids estimé par tas (ou global)
  4. Météo du jour (sélecteur rapide : ☀️🌥️🌧️❄️)
  5. Incident ? (sélecteur + texte si oui)
  6. Temps de travail (heures)

Écran 2 — GPS des tas  [OFFLINE]
  Pour chaque tas créé :
  → Numéro tas (auto : A, B, C…)
  → GPS capturé automatiquement
  → Photo du tas (optionnelle)
  → Essence principale (sélecteur)

Écran 3 — Confirmation
  → Résumé de la saisie
  → Bouton "VALIDER MA SAISIE"
```

**Automatismes déclenchés :**
```
[AUTO] releve.date = TODAY
[AUTO] releve.operateur_id = utilisateur connecté
[AUTO] Création TAS dans la base pour chaque tas saisi
       → tas.lot_id, tas.gps_lat, tas.gps_lng, tas.volume_estime
[AUTO] lot.volume_reel += SUM(releve.tonnage_t)     ← trigger SQL
[LOG]  action = 'RELEVE_SAISI', tonnage, nb_tas
[NOTIF → exploitant] synthèse quotidienne à 18h
```

**Alerte si non rempli :**
```
17h00 : Aucune saisie détectée
  [AUTO] H+12 (05h00) → SMS + push opérateur   [ALERTE INFO]
  [AUTO] H+24 (17h00) → SMS + push ETF + exploitant  [ALERTE WARNING]
  [AUTO] H+48         → Alerte critique admin    [ALERTE CRITIQUE]
```

**Résultat :**
```
lot.volume_reel mis à jour
TAS créés avec GPS
lot.statut reste EN_EXPLOITATION (jusqu'à clôture)
```

---

## ÉTAPE 6 — CLÔTURE EXPLOITATION

### Acteur : Responsable exploitation (Exploitant)
### Écran : "Validation bord de route"

**Séquence d'actions :**

```
1. Exploitant vérifie la liste des tas
2. Pour chaque tas :
     - Confirme ou corrige le volume estimé
     - Saisit l'humidité mesurée (hygromètre)
     - Valide les photos
3. Valide le volume total réel vs estimé
4. Si écart > 15% : saisit la justification    [BLOC si vide]
5. Valide la sécurité (rémanents traités, accès libre)
6. Appuie sur "LOT DISPONIBLE"
```

**Validations bloquantes :**
```
[BLOC] COUNT(tas WHERE statut='pret') >= 1
[BLOC] COUNT(tas WHERE volume_estime IS NULL OR volume_estime = 0) = 0
[BLOC] COUNT(tas WHERE gps_lat IS NULL) = 0
[BLOC] COUNT(photos tas) >= 1 par tas
[BLOC] Si |volume_reel - volume_estime| / volume_estime > 0.15
         → champ justification_ecart obligatoire
```

**Automatismes déclenchés :**
```
[AUTO] Tous tas non validés → statut = 'pret'
[AUTO] lot.humidite_reelle = AVG(tas.humidite_estimee)
[AUTO] lot.statut → BORD_ROUTE
[LOG]  action = 'CLOTURE_EXPLOITATION', volumes, humidite
[NOTIF → exploitant + DO]
       "LOT-AAAA-XXX disponible bord de route — XXX t"
```

**Résultat :**
```
lot.statut → BORD_ROUTE
Tous tas.statut = 'pret'
```

---

## ÉTAPE 7 — PROGRAMMATION DÉCHIQUETAGE

### Acteur : Exploitant
### Écran : "Planifier broyage"

**Séquence d'actions :**

```
1. Exploitant sélectionne le lot (depuis BORD_ROUTE)
2. Choisit l'entreprise de broyage
3. Définit la date prévue
4. Sélectionne le type de camion prévu
5. Renseigne la destination (chaufferie ou plateforme)
6. Génère l'ordre de transport
7. Appuie sur "PLANIFIER"
```

**Automatismes déclenchés :**
```
[AUTO] lot.statut → A_DECHIQUETER
[AUTO] Ordre de transport PDF généré (brouillon)
[LOG]  action = 'DECHIQUETAGE_PROGRAMME', date, destination
[NOTIF → Entreprise broyage]
       "Chantier de broyage planifié — LOT-AAAA-XXX — [date]"
[NOTIF → Chaufferie / Plateforme destinataire]
       "Livraison prévue le [date] — LOT-AAAA-XXX"
```

**Résultat :**
```
lot.statut → A_DECHIQUETER
```

---

## ÉTAPE 8 — DÉCHIQUETAGE + CHARGEMENT

### Acteur : Opérateur broyage
### Écran : "Chargement camion"

**Séquence d'actions :**

```
1. Opérateur broyage scanne ou sélectionne le lot
2. Valide les tas à déchiqueter (liste avec GPS)
3. Saisit le CMR :
     - N° CMR (auto-généré)           [AUTO]
     - Photo du CMR
     - Immatriculation tracteur        AA-000-AA
     - Immatriculation remorque
     - Chauffeur (nom ou sélection)
     - Type véhicule
4. Renseigne le volume chargé (t)
5. Saisit l'humidité au broyage
6. Photo(s) du chargement
7. GPS horodaté automatique           [AUTO]
8. Heure de départ saisie
9. Appuie sur "VALIDER CHARGEMENT"
```

**Validations bloquantes :**
```
[BLOC] lot.statut = 'A_DECHIQUETER'
[BLOC] COUNT(tas sélectionnés WHERE statut='pret') >= 1
[BLOC] immat_tracteur MATCH /^[A-Z]{2}-\d{3}-[A-Z]{2}$/
[BLOC] chauffeur IS NOT NULL
[BLOC] volume_charge_t > 0
[BLOC] photo_cmr IS NOT NULL
[BLOC] heure_depart IS NOT NULL
[BLOC] gps_depart IS NOT NULL
```

**Automatismes déclenchés :**
```
[AUTO] CMR généré et archivé PDF
[AUTO] Tas sélectionnés → statut = 'dechiquete'
[AUTO] Transport créé automatiquement :
         transport.cmr_reference = CMR-AAAA-XXXX
         transport.lot_id = lot.id
         transport.statut = 'prepare'
[AUTO] lot.statut → EN_TRANSPORT
[LOG]  action = 'CHARGEMENT_VALIDE', cmr, volume, immat, gps, heure
[NOTIF → chauffeur]  SMS + push
       "Mission transport LOT-AAAA-XXX — Départ confirmé"
[NOTIF → chaufferie destinataire]
       "Livraison en route — LOT-AAAA-XXX — Arrivée prévue XX:XX"
[NOTIF → exploitant]
       "LOT-AAAA-XXX chargé et parti"
```

**Résultat :**
```
lot.statut → EN_TRANSPORT
transport créé avec CMR
```

---

## ÉTAPE 9 — TRANSPORT

### Acteur : Chauffeur
### Écran : "Mission transport"

**Séquence d'actions :**

```
Sous-étape 9a — Acceptation mission
  1. Chauffeur reçoit notification
  2. Ouvre la mission dans l'app
  3. Vérifie : lot, produit, destination, poids
  4. Appuie sur "ACCEPTER LA MISSION"
  → transport.statut = 'confirme'   [LOG]

Sous-étape 9b — Confirmation départ
  5. Chauffeur au départ
  6. GPS capturé automatiquement    [AUTO]
  7. Heure horodatée automatiquement [AUTO]
  8. Appuie sur "CONFIRMER DÉPART"
  → transport.statut = 'en_route'   [LOG]

Sous-étape 9c — En route
  9. GPS suivi en arrière-plan      [AUTO]
  10. Estimation arrivée calculée dynamiquement

Sous-étape 9d — Arrivée
  11. Chauffeur arrive à destination
  12. GPS d'arrivée capturé         [AUTO]
  13. Appuie sur "CONFIRMER ARRIVÉE"
  → transport.statut = 'arrive'     [LOG]
  → Écran livraison s'ouvre automatiquement
```

**Automatismes et contrôles :**
```
[AUTO] Contrôle GPS continu :
  distance(gps_actuel, destination) CALCULÉE EN TEMPS RÉEL
  Si écart > 5 km à l'arrivée :
    → [ALERTE CRITIQUE] GPS_NON_CONFORME
    → Notifications : exploitant + transporteur + déchiqueteur
    → Livraison mise en attente, non auto-validée

[AUTO] Contrôle retard :
  Si heure_arrivee_reelle > heure_arrivee_prevue + 2h :
    → [ALERTE WARNING] RETARD_LIVRAISON
    → Notifications : exploitant + chaufferie
```

**Résultat :**
```
transport.statut → 'arrive'
Écran livraison (étape 10) ouvert automatiquement
```

---

## ÉTAPE 10 — LIVRAISON

### Acteur : Réceptionnaire chaufferie (ou chauffeur pour la saisie initiale)
### Écran : "Réception livraison"

**Séquence d'actions :**

```
Sous-étape 10a — Validation GPS lieu
  1. GPS capturé automatiquement à l'ouverture   [AUTO]
  2. Comparaison avec destination prévue         [AUTO]
  3. Si OK → continue
     Si KO → [ALERTE CRITIQUE] + blocage         [BLOC]

Sous-étape 10b — Pesée
  4. Saisie poids entrée (pont-bascule)
  5. Saisie tare véhicule
  → poids_net calculé automatiquement             [AUTO]
  6. Photo du ticket bascule
  7. Saisie numéro ticket bascule

Sous-étape 10c — Qualité
  8. Mesure humidité (hygromètre)
  → Comparaison seuil contractuel                 [AUTO]
  Si humidite > seuil :
    → [ALERTE WARNING] + proposition litige        [ALERTE]

Sous-étape 10d — Réception
  9. Nom du réceptionnaire
  10. Commentaire anomalie (optionnel)
  11. Signature réceptionnaire (tablette / lien SMS)
  12. Appuie sur "VALIDER LIVRAISON"
```

**Validations bloquantes :**
```
[BLOC] gps_livraison valide (distance < MAX_ECART_KM)
[BLOC] poids_entree > 0
[BLOC] poids_sortie > 0 AND poids_sortie < poids_entree
[BLOC] humidite BETWEEN 0 AND 100
[BLOC] receptionnaire IS NOT NULL
[BLOC] ticket_bascule IS NOT NULL
[BLOC] signature_url IS NOT NULL (BL non signé = non validé)
```

**Automatismes déclenchés :**
```
[AUTO] livraison.poids_net = poids_entree - poids_sortie
[AUTO] numero_bl = generate_numero_bl()          → BL-AAAA-XXXX
[AUTO] livraison.lot_reference = lot.numero_lot  (dénormalisé)
[AUTO] BL PDF généré et archivé
[AUTO] lot.volume_total_livre recalculé           ← trigger SQL
[AUTO] lot.statut évalué :
         Si toutes livraisons = 'valide' → LIVRE
         Sinon → PARTIELLEMENT_LIVRE              ← trigger SQL
[LOG]  action = 'LIVRAISON_VALIDEE', poids_net, humidite, gps, receptionnaire
[NOTIF → exploitant]
       "LOT-AAAA-XXX livré — BL-AAAA-XXXX — XXX t — Humidité XX%"
```

**Cas livraison partielle :**
```
livraison.poids_net < (transport.poids_net_t * 0.95)
→ [ALERTE WARNING] ECART_POIDS_LIVRAISON
→ lot.statut → PARTIELLEMENT_LIVRE (si d'autres livraisons en cours)
```

**Cas litige :**
```
Bouton "Ouvrir un litige" (visible si humidite > seuil OU écart poids > 5%)
→ litige créé avec cause, valeurs constatée / attendue
→ lot.statut → EN_LITIGE (ne peut pas clôturer)
→ [NOTIF → exploitant + admin]
```

**Résultat :**
```
livraison.statut → 'valide'
lot.statut → PARTIELLEMENT_LIVRE ou LIVRE (trigger auto)
BL archivé
```

---

## ÉTAPE 11 — CLÔTURE LOT

### Acteur : Exploitant
### Écran : "Fiche lot → Clôturer"

**Séquence d'actions :**

```
1. Exploitant ouvre la fiche lot
2. Consulte le widget "Prêt pour clôture" (v_lot_cloture_status)
3. Vérifie les 5 conditions :
     ✅ Tous les tas traités (déchiquetés ou annulés)
     ✅ Tous les transports livrés
     ✅ Toutes les pesées saisies
     ✅ Documents obligatoires présents (CMR + BL signés)
     ✅ Aucun litige ouvert
4. Si toutes conditions ✅ → bouton "CLÔTURER LOT" actif
5. Si condition ❌ → bouton grisé + liste des blocages affichée
6. Exploitant appuie sur "CLÔTURER LOT"
7. Confirmation demandée (modal)
8. Valide
```

**Validations bloquantes (trigger SQL + API) :**
```
[BLOC] COUNT(tas WHERE statut NOT IN ('dechiquete','annule')) = 0
[BLOC] COUNT(transports WHERE statut != 'arrive') = 0
[BLOC] COUNT(livraisons WHERE poids_net IS NULL) = 0
[BLOC] COUNT(litiges WHERE statut IN ('ouvert','en_resolution')) = 0
[BLOC] EXISTS(documents WHERE type='cmr' pour chaque transport)
[BLOC] EXISTS(documents WHERE type='bl' AND type='signature' pour chaque livraison)
```

**Automatismes déclenchés :**
```
[AUTO] lot.statut → CLOTURE
[AUTO] lot.cloture = true
[AUTO] Tous les objets du lot passent en lecture seule
[AUTO] Rapport de clôture PDF généré :
         - Bilan volumes (estimé vs réel vs livré)
         - Liste des BL signés
         - Humidité moyenne livrée
         - Dates et durées
         - Intervenants
[LOG]  action = 'LOT_CLOTURE'
       nouvelle_valeur = {volume_reel, volume_livre, nb_livraisons, humidite_moy}
[NOTIF → exploitant + donneur d'ordre + ETF]
       "LOT-AAAA-XXX clôturé — Rapport disponible"
```

**Résultat :**
```
lot.statut → CLOTURE  (terminal, lecture seule)
Rapport de clôture PDF archivé
```

---

## AUTOMATISMES GLOBAUX

### Notifications — Canaux et timing

| Événement | Canal | Destinataire | Timing |
|---|---|---|---|
| Lot créé | Push + email | Responsable terrain | Immédiat |
| Visite validée | Push + email | Exploitant | Immédiat |
| Chantier autorisé | Push + SMS | ETF + Opérateurs | Immédiat |
| Chargement validé | Push + SMS | Chauffeur + Chaufferie | Immédiat |
| Livraison en route | Push | Chaufferie | Immédiat |
| Livraison reçue | Push + email | Exploitant | Immédiat |
| Lot clôturé | Email | Exploitant + DO + ETF | Immédiat |
| Saisie opérateur manquante (H+12) | SMS | Opérateur | Cron 05h00 |
| Saisie opérateur manquante (H+24) | SMS + Push | ETF + Exploitant | Cron 17h00 |
| Retard livraison | Push | Exploitant + Transporteur | Trigger arrivée |
| Humidité hors seuil | Push + email | Exploitant + Chaufferie | Trigger pesée |
| GPS non conforme | Push + SMS | Exploitant + Transporteur | Trigger GPS |
| Litige ouvert | Push + email | Exploitant + Admin | Immédiat |
| BL non signé > 48h | Email | Exploitant + Chaufferie | Cron quotidien |

---

## RÈGLE UX TERRAIN — Saisie rapide offline

### Principe : 3 clics maximum pour une action critique

| Action | Nb clics | Mode offline |
|---|---|---|
| Créer un tas + GPS | 2 (GPS auto + valider) | ✅ |
| Saisir relevé journalier | 3 (tonnage + météo + valider) | ✅ |
| Marquer tas complet | 1 (bouton) | ✅ |
| Confirmer départ transport | 2 (GPS auto + valider) | ✅ |
| Confirmer arrivée livraison | 2 (GPS auto + valider) | ✅ |
| Saisir pesée | 3 (poids + humidité + valider) | ✅ |

### Comportement offline (PWA Service Worker)

```
Actions autorisées sans réseau :
  - Saisie relevé journalier
  - Création de tas + GPS
  - Marquage tas complet
  - Photos (stockées localement)
  - Confirmation départ / arrivée

À la reconnexion :
  [AUTO] Sync automatique en arrière-plan
  [AUTO] Résolution des conflits (last-write-wins sur les tas)
  [AUTO] Notification "Données synchronisées"
  [LOG]  source = 'offline_sync', timestamp_local, timestamp_sync
```

---

## RÉSUMÉ — Transitions d'état et déclencheurs

| De | Vers | Déclencheur | Acteur |
|---|---|---|---|
| — | `BROUILLON` | Lot créé | Exploitant |
| `BROUILLON` | `A_VISITER` | GPS + propriétaire saisis | Exploitant |
| `A_VISITER` | `VISITE_REALISEE` | Visite validée | Technicien terrain |
| `VISITE_REALISEE` | `VALIDE_EXPLOITATION` | Bouton "AUTORISER EXPLOITATION" | Exploitant |
| `VALIDE_EXPLOITATION` | `EN_EXPLOITATION` | Bouton "DÉMARRER LE CHANTIER" | ETF |
| `EN_EXPLOITATION` | `BORD_ROUTE` | Bouton "LOT DISPONIBLE" | Exploitant |
| `BORD_ROUTE` | `A_DECHIQUETER` | Bouton "PLANIFIER" déchiquetage | Exploitant |
| `BORD_ROUTE` | `EN_EXPLOITATION` | Retour exploitation (bidi) | Exploitant |
| `A_DECHIQUETER` | `DECHIQUETAGE_EN_COURS` | Broyage démarré | Opérateur broyage |
| `DECHIQUETAGE_EN_COURS` | `EN_TRANSPORT` | Bouton "VALIDER CHARGEMENT" | Opérateur broyage |
| `EN_TRANSPORT` | `PARTIELLEMENT_LIVRE` | 1ère livraison validée | Trigger auto |
| `EN_TRANSPORT` | `LIVRE` | Toutes livraisons validées | Trigger auto |
| `PARTIELLEMENT_LIVRE` | `LIVRE` | Dernière livraison validée | Trigger auto |
| `LIVRE` | `CLOTURE` | Bouton "CLÔTURER LOT" | Exploitant |
| `LIVRE` | `EN_LITIGE` | Litige ouvert sur livraison | Exploitant / Chaufferie |
| `EN_LITIGE` | `CLOTURE` | Litige résolu | Exploitant / Admin |
| `EN_LITIGE` | `ANNULE` | Litige abandonné | Admin |
| Tout (sauf CLOTURE) | `ANNULE` | Annulation manuelle + motif | Exploitant / Admin |

