// ============================================================
// APPLITAG MOBILE — Interface terrain optimisée téléphone
// Contact · Abattage · Débardage · Fin de service
// Boutons 48px+ · Scroll natif · GPS · Photos · Vocal
// API: https://applitag-api-production.up.railway.app
// ============================================================

import { useState, useCallback } from "react";

// ── CONFIG ────────────────────────────────────────────────────
const API = "https://applitag-api-production.up.railway.app";

// ── TOKENS MOBILE ─────────────────────────────────────────────
const C = {
  green:"#1D9E75", greenL:"#E1F5EE", greenD:"#085041",
  blue:"#185FA5",  blueL:"#E6F1FB",
  amber:"#BA7517", amberL:"#FAEEDA", amberD:"#412402",
  red:"#A32D2D",   redL:"#FCEBEB",
  brown:"#8B6914", brownL:"#F1EFE8",
  bg:"#F5F4F1",    bg2:"#ECEAE6",
  bd:"#DDDBD5",
  tx:"#1A1A18",    tx2:"#5A5955",   tx3:"#9A9892",
  sb:"#111",
};

// Taille minimale bouton terrain = 56px (doigt avec gant)
const BTN_H = 56;
const INPUT_H = 52;
const FONT_LABEL = 15;
const FONT_INPUT = 16; // évite zoom iOS
const FONT_BTN = 16;
const PADDING = 16;

// ── HELPERS ───────────────────────────────────────────────────
const uid = () => Math.random().toString(36).slice(2,9);
const nowISO = () => new Date().toISOString();
const todayS = () => new Date().toISOString().slice(0,10);

const essenceLabel = e => ({
  peuplier:"Peuplier", chene:"Chêne", hetre:"Hêtre",
  charme:"Charme", frene:"Frêne", bouleau:"Bouleau",
  resineux:"Résineux", melange:"Mélange",
}[e] ?? e);

// ── ATOMS MOBILE ──────────────────────────────────────────────

// Bouton pleine largeur — gros, tactile
const BigBtn = ({onClick,bg=C.green,color="#fff",children,disabled,icon,style={}}) => (
  <button onClick={disabled?undefined:onClick} style={{
    width:"100%", height:BTN_H, borderRadius:14,
    background:disabled?C.bg2:bg, color:disabled?C.tx3:color,
    border:"none", fontFamily:"inherit",
    fontSize:FONT_BTN, fontWeight:600,
    display:"flex", alignItems:"center", justifyContent:"center", gap:10,
    cursor:disabled?"not-allowed":"pointer",
    opacity:disabled?.5:1,
    WebkitTapHighlightColor:"transparent",
    ...style,
  }}>
    {icon&&<span style={{fontSize:22}}>{icon}</span>}
    {children}
  </button>
);

// Bouton secondaire compact
const SmBtn = ({onClick,bg=C.bg2,color=C.tx,children,style={}}) => (
  <button onClick={onClick} style={{
    padding:"10px 16px", borderRadius:10,
    background:bg, color, border:"none",
    fontFamily:"inherit", fontSize:14, fontWeight:500,
    display:"inline-flex", alignItems:"center", gap:7,
    cursor:"pointer", WebkitTapHighlightColor:"transparent",
    ...style,
  }}>{children}</button>
);

// Champ texte mobile
const MInput = ({label,value,onChange,placeholder,type="text",required,error,hint,big}) => (
  <div style={{marginBottom:14}}>
    <div style={{fontSize:13,fontWeight:600,color:error?C.red:C.tx2,marginBottom:5,
      display:"flex",justifyContent:"space-between"}}>
      <span>{label}{required&&<span style={{color:"#E24B4A"}}> *</span>}</span>
      {hint&&<span style={{fontWeight:400,color:C.tx3,fontSize:12}}>{hint}</span>}
    </div>
    {big ? (
      <textarea value={value} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder} rows={3}
        style={{width:"100%",padding:"14px",borderRadius:12,resize:"vertical",
          border:`1.5px solid ${error?C.red:C.bd}`,
          fontSize:FONT_INPUT,fontFamily:"inherit",lineHeight:1.5,
          background:"#fff",color:C.tx,outline:"none"}}/>
    ) : (
      <input value={value} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder} type={type}
        style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
          border:`1.5px solid ${error?C.red:C.bd}`,
          fontSize:FONT_INPUT,fontFamily:"inherit",
          background:"#fff",color:C.tx,outline:"none"}}/>
    )}
    {error&&<div style={{fontSize:12,color:C.red,marginTop:4}}>⚠ {error}</div>}
  </div>
);

// Sélecteur liste déroulante
const MSelect = ({label,value,onChange,options,required}) => (
  <div style={{marginBottom:14}}>
    <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:5}}>
      {label}{required&&<span style={{color:"#E24B4A"}}> *</span>}
    </div>
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
        border:`1.5px solid ${C.bd}`,fontSize:FONT_INPUT,
        fontFamily:"inherit",background:"#fff",color:C.tx,outline:"none",
        appearance:"none",backgroundImage:"url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%239A9892' d='M6 8L1 3h10z'/%3E%3C/svg%3E\")",
        backgroundRepeat:"no-repeat",backgroundPosition:"right 14px center",
        paddingRight:40,
      }}>
      {options.map(([v,l])=><option key={v} value={v}>{l}</option>)}
    </select>
  </div>
);

// Compteur +/- gros
const BigCounter = ({value,onChange,label,sub,color=C.brown}) => (
  <div style={{textAlign:"center",padding:"8px 0"}}>
    {label&&<div style={{fontSize:14,fontWeight:600,color:C.tx2,marginBottom:4}}>{label}</div>}
    {sub&&<div style={{fontSize:12,color:C.tx3,marginBottom:12}}>{sub}</div>}
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:24}}>
      <button onClick={()=>onChange(Math.max(0,value-1))} style={{
        width:64,height:64,borderRadius:16,
        border:`2px solid ${C.bd}`,background:"#fff",
        fontSize:30,cursor:"pointer",fontFamily:"inherit",
        display:"flex",alignItems:"center",justifyContent:"center",
        WebkitTapHighlightColor:"transparent",
      }}>−</button>
      <div style={{minWidth:80,textAlign:"center"}}>
        <div style={{fontSize:56,fontWeight:700,color,lineHeight:1}}>{value}</div>
        <div style={{fontSize:12,color:C.tx3,marginTop:2}}>
          {label?.toLowerCase()}
        </div>
      </div>
      <button onClick={()=>onChange(value+1)} style={{
        width:64,height:64,borderRadius:16,
        border:`2px solid ${color}`,background:color+"18",
        fontSize:30,cursor:"pointer",fontFamily:"inherit",
        color,display:"flex",alignItems:"center",justifyContent:"center",
        WebkitTapHighlightColor:"transparent",
      }}>+</button>
    </div>
  </div>
);

// Slider avec valeur
const MSlider = ({label,value,onChange,min,max,step=0.5,unit,color=C.green}) => (
  <div style={{marginBottom:14}}>
    <div style={{display:"flex",justifyContent:"space-between",
      fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
      <span>{label}</span>
      <span style={{color,fontSize:16,fontWeight:700}}>{value}{unit}</span>
    </div>
    <input type="range" min={min} max={max} step={step} value={value}
      onChange={e=>onChange(parseFloat(e.target.value))}
      style={{width:"100%",height:8,accentColor:color}}/>
    <div style={{display:"flex",justifyContent:"space-between",
      fontSize:11,color:C.tx3,marginTop:4}}>
      <span>{min}{unit}</span><span>{max}{unit}</span>
    </div>
  </div>
);

// GPS
const GpsWidget = ({value,onChange}) => {
  const [loading,setLoading] = useState(false);
  const capture = () => {
    setLoading(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => {
          onChange({lat:pos.coords.latitude,lng:pos.coords.longitude,source:"gps"});
          setLoading(false);
        },
        () => {
          // Fallback simulé si refusé
          onChange({lat:47.98+(Math.random()-.5)*.02,
                   lng:3.09+(Math.random()-.5)*.02,source:"sim"});
          setLoading(false);
        },
        {enableHighAccuracy:true,timeout:8000}
      );
    } else {
      onChange({lat:47.98,lng:3.09,source:"sim"});
      setLoading(false);
    }
  };
  if (value) return (
    <div style={{background:C.greenL,borderRadius:12,padding:"12px 14px",
      display:"flex",justifyContent:"space-between",alignItems:"center",
      marginBottom:14}}>
      <div>
        <div style={{fontSize:12,color:C.greenD,fontWeight:600,marginBottom:2}}>
          📍 {value.source==="gps"?"GPS capturé":"Position approx."}
        </div>
        <div style={{fontFamily:"monospace",fontSize:13,color:C.greenD}}>
          {value.lat.toFixed(5)}°N · {value.lng.toFixed(5)}°E
        </div>
      </div>
      <button onClick={()=>onChange(null)} style={{background:"none",border:"none",
        color:C.greenD,cursor:"pointer",fontSize:22,padding:4}}>✕</button>
    </div>
  );
  return (
    <BigBtn onClick={capture} bg={loading?C.bg2:C.greenL}
      color={loading?C.tx3:C.greenD} icon={loading?"":"📍"} style={{marginBottom:14}}>
      {loading?"Localisation en cours…":"Capturer ma position GPS"}
    </BigBtn>
  );
};

// Météo
const MeteoBar = ({value,onChange}) => (
  <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:14}}>
    {[["beau","☀️"],["nuageux","⛅"],["pluie","🌧️"],["gel","❄️"]].map(([v,ic])=>(
      <button key={v} onClick={()=>onChange(v)} style={{
        height:56,borderRadius:12,border:`2px solid ${value===v?C.green:C.bd}`,
        background:value===v?C.greenL:"#fff",cursor:"pointer",fontFamily:"inherit",
        display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
        gap:3,WebkitTapHighlightColor:"transparent",
      }}>
        <span style={{fontSize:22}}>{ic}</span>
        <span style={{fontSize:10,color:value===v?C.greenD:C.tx3}}>{v}</span>
      </button>
    ))}
  </div>
);

// Toast
const useToast = () => {
  const [toasts,setToasts] = useState([]);
  const toast = useCallback((msg,type="success")=>{
    const id=uid();
    setToasts(t=>[...t,{id,msg,type}]);
    setTimeout(()=>setToasts(t=>t.filter(x=>x.id!==id)),2800);
  },[]);
  const ToastContainer = () => (
    <div style={{position:"fixed",top:16,left:16,right:16,zIndex:9999,
      display:"flex",flexDirection:"column",gap:8,pointerEvents:"none"}}>
      {toasts.map(t=>(
        <div key={t.id} style={{
          padding:"12px 16px",borderRadius:12,fontSize:14,fontWeight:500,
          color:"#fff",textAlign:"center",
          background:t.type==="success"?C.greenD:t.type==="warn"?C.amberD:C.red,
          boxShadow:"0 4px 20px rgba(0,0,0,.25)",
        }}>{t.type==="success"?"✓":t.type==="warn"?"⚠":"✗"} {t.msg}</div>
      ))}
    </div>
  );
  return {toast,ToastContainer};
};

// ── ÉCRAN CONTACT ─────────────────────────────────────────────
const EcranContact = ({onBack,onSaved,toast}) => {
  const [nom,       setNom]       = useState("");
  const [prenom,    setPrenom]    = useState("");
  const [telephone, setTel]       = useState("");
  const [commune,   setCommune]   = useState("");
  const [type,      setType]      = useState("proprietaire_forestier");
  const [origine,   setOrigine]   = useState("appel_entrant");
  const [potentiel, setPotentiel] = useState("");
  const [commentaire,setComm]     = useState("");
  const [gps,       setGps]       = useState(null);
  const [saving,    setSaving]    = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const errors = submitted ? {
    nom:       !nom.trim()       ? "Obligatoire" : null,
    telephone: !telephone.trim() ? "Obligatoire" :
               telephone.replace(/\D/g,"").length < 8 ? "Format invalide" : null,
    commune:   !commune.trim()   ? "Obligatoire" : null,
  } : {};

  const canSave = nom.trim() && telephone.trim() && commune.trim();

  const handleSave = async () => {
    setSubmitted(true);
    if (!canSave) return;
    setSaving(true);
    const contact = {
      id:uid(), nom:nom.trim(), prenom:prenom.trim()||undefined,
      telephone:telephone.trim(), commune:commune.trim(),
      typeContact:type, origine, statut:"nouveau",
      potentiel:potentiel.trim()||undefined,
      commentaire:commentaire.trim()||undefined,
      gpsLat:gps?.lat||null, gpsLng:gps?.lng||null,
    };
    try {
      const r = await fetch(`${API}/contacts`,{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(contact),
      });
      if (r.ok) {
        toast(`Contact ${nom} enregistré ✓`);
        onSaved(contact);
      } else {
        throw new Error("Erreur serveur");
      }
    } catch(e) {
      toast("Sauvegardé en local (hors ligne)","warn");
      onSaved(contact);
    }
    setSaving(false);
  };

  return (
    <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:80}}>
      <GpsWidget value={gps} onChange={setGps}/>

      <MInput label="Nom" value={nom} onChange={setNom}
        placeholder="Dupont" required error={errors.nom}/>
      <MInput label="Prénom" value={prenom} onChange={setPrenom}
        placeholder="Jean" hint="optionnel"/>
      <MInput label="Téléphone" value={telephone} onChange={setTel}
        placeholder="06 12 34 56 78" type="tel" required error={errors.telephone}/>
      <MInput label="Commune" value={commune} onChange={setCommune}
        placeholder="Charny (89)" required error={errors.commune}/>

      <MSelect label="Type de contact" value={type} onChange={setType} required
        options={[
          ["proprietaire_forestier","👤 Propriétaire forestier"],
          ["cooperative","🌿 Coopérative"],
          ["etf","⛏ ETF"],
          ["transporteur","🚛 Transporteur"],
          ["chaufferie","🏭 Chaufferie"],
          ["plateforme","🏗️ Plateforme"],
          ["negociant","💼 Négociant"],
          ["collectivite","🏛️ Collectivité"],
          ["prospect","🔍 Prospect"],
        ]}/>

      <MSelect label="Origine du contact" value={origine} onChange={setOrigine}
        options={[
          ["appel_entrant","📞 Appel entrant"],
          ["visite_terrain","🔭 Visite terrain"],
          ["recommandation","🤝 Recommandation"],
          ["salon","🎪 Salon"],
          ["email","📧 Email"],
          ["site_internet","🌐 Site internet"],
          ["reseau_applitag","🌲 Réseau APPLITAG"],
          ["autre","… Autre"],
        ]}/>

      <MInput label="Potentiel estimé" value={potentiel} onChange={setPotentiel}
        placeholder="ex: 150 t bord de route, 25 ha taillis" hint="optionnel"/>
      <MInput label="Commentaire" value={commentaire} onChange={setComm}
        placeholder="Notes libres, rappel, accès…" big hint="optionnel"/>

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"12px 16px 24px",
        background:`linear-gradient(transparent,${C.bg} 30%)`}}>
        <BigBtn onClick={handleSave} disabled={saving}
          icon={saving?"":"✓"}>
          {saving?"Enregistrement…":"ENREGISTRER CONTACT"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN ABATTEUR ────────────────────────────────────────────
const EcranAbatteur = ({lot,onBack,onSaved,toast}) => {
  const [nbTas,    setNbTas]    = useState(0);
  const [longueur, setLongueur] = useState(4.0);
  const [largeur,  setLargeur]  = useState(2.0);
  const [hauteur,  setHauteur]  = useState(1.5);
  const [essence,  setEssence]  = useState("peuplier");
  const [humidite, setHumidite] = useState(50);
  const [meteo,    setMeteo]    = useState("beau");
  const [incident, setIncident] = useState("aucun");
  const [temps,    setTemps]    = useState(8);
  const [saving,   setSaving]   = useState(false);

  const volTas   = Math.round(longueur*largeur*hauteur*0.60*100)/100;
  const poidsTas = Math.round(volTas*0.28*100)/100;
  const volTotal = Math.round(nbTas*volTas*10)/10;
  const poidsTotal = Math.round(nbTas*poidsTas*100)/100;

  const canSave = nbTas > 0 && longueur > 0 && largeur > 0 && hauteur > 0;

  const handleSave = async () => {
    if (!canSave) { toast("Saisir au moins 1 tas","warn"); return; }
    setSaving(true);
    const releve = {
      id:uid(), lotId:lot.id, operateur:"P. Girard",
      date:todayS(), nbTas, longueur, largeur, hauteur,
      essence, humidite, meteo, incident, temps,
      volTotal, poidsTotal, createdAt:nowISO(),
    };
    toast(`✓ ${nbTas} tas · ${poidsTotal.toFixed(1)} t enregistrés`);
    onSaved(releve);
    setSaving(false);
  };

  return (
    <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:100}}>

      {/* Nombre de tas — GROS */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <BigCounter value={nbTas} onChange={setNbTas}
          label="Tas" sub="Combien de tas avez-vous abattu aujourd'hui ?"
          color={C.brown}/>
      </div>

      {/* Dimensions */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <div style={{fontSize:14,fontWeight:600,color:C.tx2,marginBottom:14}}>
          📏 Dimension moyenne d'un tas
        </div>
        <MInput label="Longueur" value={String(longueur)}
          onChange={v=>setLongueur(parseFloat(v)||0)}
          placeholder="4.0" type="number" hint="mètres"/>
        <MInput label="Largeur" value={String(largeur)}
          onChange={v=>setLargeur(parseFloat(v)||0)}
          placeholder="2.0" type="number" hint="mètres"/>
        <MInput label="Hauteur" value={String(hauteur)}
          onChange={v=>setHauteur(parseFloat(v)||0)}
          placeholder="1.5" type="number" hint="mètres"/>
        {volTas>0&&(
          <div style={{background:C.blueL,borderRadius:10,padding:"10px 14px",
            fontSize:13,color:C.blue,textAlign:"center",marginTop:4}}>
            1 tas ≈ <strong>{volTas} m³</strong> · <strong>{poidsTas} t</strong>
            <span style={{fontSize:11,color:C.tx3}}> (coeff. andain 0.60)</span>
          </div>
        )}
      </div>

      {/* Essence */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <MSelect label="🌿 Essence dominante" value={essence} onChange={setEssence}
          options={[
            ["peuplier","🌾 Peuplier — 420 kg/m³"],
            ["chene","🌳 Chêne — 700 kg/m³"],
            ["hetre","🌲 Hêtre — 720 kg/m³"],
            ["charme","🌿 Charme — 760 kg/m³"],
            ["frene","🍃 Frêne — 680 kg/m³"],
            ["bouleau","🪵 Bouleau — 600 kg/m³"],
            ["resineux","🎄 Résineux — 480 kg/m³"],
            ["melange","🌳 Mélange"],
          ]}/>
      </div>

      {/* Humidité */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <MSlider label="💧 Humidité estimée" value={humidite} onChange={setHumidite}
          min={20} max={70} unit="%" step={1}
          color={humidite>45?C.blue:humidite>35?C.amber:C.green}/>
        <div style={{textAlign:"center",fontSize:12,color:C.tx3}}>
          {humidite>=50?"🌊 Bois vert":humidite>=35?"⚠ Demi-sec":"✓ Sec"}
        </div>
      </div>

      {/* Conditions */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <div style={{fontSize:14,fontWeight:600,color:C.tx2,marginBottom:12}}>
          🌤️ Conditions de la journée
        </div>
        <MeteoBar value={meteo} onChange={setMeteo}/>
        <MSelect label="Incident" value={incident} onChange={setIncident}
          options={[
            ["aucun","✓ Aucun incident"],
            ["panne_machine","🔧 Panne machine"],
            ["arret_meteo","🌧️ Arrêt météo"],
            ["accident","🚨 Accident"],
            ["autre","… Autre"],
          ]}/>
        <MSlider label="⏱️ Temps de travail" value={temps} onChange={setTemps}
          min={1} max={12} unit="h" step={0.5} color={C.green}/>
      </div>

      {/* Bilan */}
      {nbTas>0&&volTas>0&&(
        <div style={{background:C.greenL,border:`1px solid ${C.green}40`,
          borderRadius:16,padding:20,marginBottom:16}}>
          <div style={{fontSize:14,fontWeight:600,color:C.greenD,marginBottom:12}}>
            📊 Bilan journée
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
            {[
              {l:"Tas",v:nbTas,c:C.brown},
              {l:"Volume",v:`${volTotal.toFixed(1)} m³`,c:C.blue},
              {l:"Poids",v:`${poidsTotal.toFixed(1)} t`,c:C.green},
            ].map(({l,v,c})=>(
              <div key={l} style={{background:"#fff",borderRadius:10,
                padding:"12px 8px",textAlign:"center"}}>
                <div style={{fontSize:22,fontWeight:700,color:c}}>{v}</div>
                <div style={{fontSize:11,color:C.tx3,marginTop:3}}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"12px 16px 24px",
        background:`linear-gradient(transparent,${C.bg} 30%)`}}>
        <BigBtn onClick={handleSave} disabled={saving||!canSave}
          bg={canSave?C.green:C.bg2} icon="✓">
          {saving?"Enregistrement…":"Valider ma saisie journée"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN DÉBARDEUR ───────────────────────────────────────────
const EcranDebardeur = ({lot,emplacements,onBack,onSaved,toast}) => {
  const [nbTours,      setNbTours]      = useState(0);
  const [nbTasParTour, setNbTasParTour] = useState(3);
  const [longueur,     setLongueur]     = useState(6.0);
  const [largeur,      setLargeur]      = useState(3.0);
  const [hauteur,      setHauteur]      = useState(1.5);
  const [essence,      setEssence]      = useState("peuplier");
  const [machine,      setMachine]      = useState("");
  const [empId,        setEmpId]        = useState(emplacements[0]?.id??"");
  const [gpsDepot,     setGpsDepot]     = useState(null);
  const [meteo,        setMeteo]        = useState("beau");
  const [incident,     setIncident]     = useState("aucun");
  const [temps,        setTemps]        = useState(8);
  const [saving,       setSaving]       = useState(false);

  const volTour    = Math.round(longueur*largeur*hauteur*100)/100;
  const poidsTour  = Math.round(volTour*0.28*100)/100;
  const volTotal   = Math.round(nbTours*volTour*10)/10;
  const poidsTotal = Math.round(nbTours*poidsTour*100)/100;
  const nbTasTotal = nbTours*nbTasParTour;
  const emp        = emplacements.find(e=>e.id===empId);

  const canSave = nbTours>0 && longueur>0 && largeur>0 && hauteur>0 && empId;

  const handleSave = () => {
    if (!canSave) { toast("Saisir au moins 1 tour et un emplacement","warn"); return; }
    setSaving(true);
    const releve = {
      id:uid(), lotId:lot.id, operateur:"J. Moreau", machine,
      date:todayS(), nbTours, nbTasParTour, nbTasTotal,
      longueur, largeur, hauteur, essence,
      emplacementId:empId, emplacementNom:emp?.nom,
      gpsDepot, meteo, incident, temps,
      volTotal, poidsTotal, createdAt:nowISO(),
    };
    toast(`✓ ${nbTours} tours → ${emp?.nom??empId}`);
    onSaved(releve);
    setSaving(false);
  };

  return (
    <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:100}}>

      {/* Machine */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <MInput label="🚜 Machine" value={machine} onChange={setMachine}
          placeholder="Skidder, porteur, tracteur…"/>
      </div>

      {/* Emplacement dépôt */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <div style={{fontSize:14,fontWeight:600,color:C.tx2,marginBottom:8}}>
          📍 Emplacement de dépôt
        </div>
        <div style={{fontSize:12,color:C.amber,background:C.amberL,
          borderRadius:9,padding:"8px 12px",marginBottom:12}}>
          ⚠ Sélectionnez l'emplacement défini lors de la visite initiale
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {emplacements.map(e=>{
            const sel = empId===e.id;
            const pct = e.capaciteEstimeeM3>0
              ? Math.round(e.volumeAccumuleM3/e.capaciteEstimeeM3*100) : 0;
            return (
              <div key={e.id} onClick={()=>setEmpId(e.id)} style={{
                padding:14,borderRadius:12,cursor:"pointer",
                border:`2px solid ${sel?C.green:C.bd}`,
                background:sel?C.greenL:"#fff",
              }}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                  <div style={{fontSize:14,fontWeight:600,
                    color:sel?C.greenD:C.tx}}>{e.nom}</div>
                  {sel&&<span style={{color:C.green,fontSize:18}}>✓</span>}
                </div>
                <div style={{fontSize:12,color:C.tx3,marginBottom:8}}>
                  {e.volumeAccumuleM3.toFixed(1)} m³ reçus · {e.nbToursRecus} tours
                </div>
                <div style={{height:6,background:C.bg2,borderRadius:3,overflow:"hidden"}}>
                  <div style={{height:"100%",
                    width:`${Math.min(100,pct)}%`,
                    background:pct>85?C.red:pct>60?C.amber:C.green,
                    borderRadius:3}}/>
                </div>
              </div>
            );
          })}
        </div>
        <div style={{marginTop:12}}>
          <GpsWidget value={gpsDepot} onChange={setGpsDepot}/>
        </div>
      </div>

      {/* Nombre de tours */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <BigCounter value={nbTours} onChange={setNbTours}
          label="Tours" sub="Trajets forêt → dépôt aujourd'hui"
          color={C.blue}/>
        <div style={{height:1,background:C.bd,margin:"16px 0"}}/>
        {/* Tas par tour — compteur plus petit */}
        <div style={{textAlign:"center"}}>
          <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
            Tas par tour (en moyenne)
          </div>
          <div style={{display:"flex",alignItems:"center",
            justifyContent:"center",gap:16}}>
            <button onClick={()=>setNbTasParTour(n=>Math.max(1,n-1))} style={{
              width:48,height:48,borderRadius:12,border:`2px solid ${C.bd}`,
              background:"#fff",fontSize:22,cursor:"pointer",fontFamily:"inherit",
              WebkitTapHighlightColor:"transparent",
            }}>−</button>
            <div style={{textAlign:"center",minWidth:60}}>
              <div style={{fontSize:36,fontWeight:700,color:C.blue,lineHeight:1}}>
                {nbTasParTour}
              </div>
              <div style={{fontSize:11,color:C.tx3}}>tas/tour</div>
            </div>
            <button onClick={()=>setNbTasParTour(n=>n+1)} style={{
              width:48,height:48,borderRadius:12,border:`2px solid ${C.blue}`,
              background:C.blueL,fontSize:22,cursor:"pointer",fontFamily:"inherit",
              color:C.blue,WebkitTapHighlightColor:"transparent",
            }}>+</button>
          </div>
          {nbTours>0&&(
            <div style={{fontSize:13,color:C.tx3,marginTop:8}}>
              = {nbTasTotal} tas débarié{nbTasTotal>1?"s":""} au total
            </div>
          )}
        </div>
      </div>

      {/* Dimension panier */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <div style={{fontSize:14,fontWeight:600,color:C.tx2,marginBottom:14}}>
          📏 Dimension du panier
        </div>
        <MInput label="Longueur" value={String(longueur)}
          onChange={v=>setLongueur(parseFloat(v)||0)}
          placeholder="6.0" type="number" hint="mètres"/>
        <MInput label="Largeur" value={String(largeur)}
          onChange={v=>setLargeur(parseFloat(v)||0)}
          placeholder="3.0" type="number" hint="mètres"/>
        <MInput label="Hauteur" value={String(hauteur)}
          onChange={v=>setHauteur(parseFloat(v)||0)}
          placeholder="1.5" type="number" hint="mètres"/>
        {volTour>0&&(
          <div style={{background:C.blueL,borderRadius:10,padding:"10px 14px",
            fontSize:13,color:C.blue,textAlign:"center",marginTop:4}}>
            1 tour ≈ <strong>{volTour} m³</strong> · <strong>{poidsTour} t</strong>
          </div>
        )}
      </div>

      {/* Essence */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <MSelect label="🌿 Essence dominante" value={essence} onChange={setEssence}
          options={[
            ["peuplier","🌾 Peuplier"],["chene","🌳 Chêne"],
            ["hetre","🌲 Hêtre"],["charme","🌿 Charme"],
            ["frene","🍃 Frêne"],["bouleau","🪵 Bouleau"],
            ["resineux","🎄 Résineux"],["melange","🌳 Mélange"],
          ]}/>
      </div>

      {/* Conditions */}
      <div style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:16,padding:20,marginBottom:16}}>
        <div style={{fontSize:14,fontWeight:600,color:C.tx2,marginBottom:12}}>
          🌤️ Conditions
        </div>
        <MeteoBar value={meteo} onChange={setMeteo}/>
        <MSelect label="Incident" value={incident} onChange={setIncident}
          options={[
            ["aucun","✓ Aucun"],["panne_machine","🔧 Panne"],
            ["arret_meteo","🌧️ Météo"],["enlisement","🚜 Enlisement"],
            ["autre","… Autre"],
          ]}/>
        <MSlider label="⏱️ Temps de travail" value={temps} onChange={setTemps}
          min={1} max={12} unit="h" step={0.5} color={C.blue}/>
      </div>

      {/* Bilan */}
      {nbTours>0&&volTour>0&&(
        <div style={{background:C.blueL,border:`1px solid ${C.blue}30`,
          borderRadius:16,padding:20,marginBottom:16}}>
          <div style={{fontSize:14,fontWeight:600,color:C.blueD,marginBottom:12}}>
            📊 Bilan journée débardage
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10}}>
            {[
              {l:"Tours",v:nbTours,c:C.blue},
              {l:"Tas débardiés",v:nbTasTotal,c:C.brown},
              {l:"Volume",v:`${volTotal.toFixed(1)} m³`,c:C.purple},
              {l:"Poids",v:`${poidsTotal.toFixed(1)} t`,c:C.green},
            ].map(({l,v,c})=>(
              <div key={l} style={{background:"#fff",borderRadius:10,
                padding:"12px 8px",textAlign:"center"}}>
                <div style={{fontSize:20,fontWeight:700,color:c}}>{v}</div>
                <div style={{fontSize:11,color:C.tx3,marginTop:3}}>{l}</div>
              </div>
            ))}
          </div>
          {emp&&(
            <div style={{marginTop:10,fontSize:13,color:C.blueD,textAlign:"center"}}>
              → <strong>{emp.nom}</strong> · total après :
              {" "}{(emp.volumeAccumuleM3+volTotal).toFixed(1)} m³
            </div>
          )}
        </div>
      )}

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"12px 16px 24px",
        background:`linear-gradient(transparent,${C.bg} 30%)`}}>
        <BigBtn onClick={handleSave} disabled={saving||!canSave}
          bg={canSave?C.blue:C.bg2} color="#fff" icon="✓">
          {saving?"Enregistrement…":"Valider ma saisie journée"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── ACCUEIL MOBILE ─────────────────────────────────────────────
const Accueil = ({onNav,contacts,relevesAbatteur,relevesDebardeur,emplacements}) => {
  const totAbattu  = relevesAbatteur.reduce((s,r)=>s+r.poidsTotal,0);
  const totDebardie = relevesDebardeur.reduce((s,r)=>s+r.poidsTotal,0);

  const LOT = {id:"l1",numero:"LOT-2025-007",commune:"Charny (89)"};

  return (
    <div style={{flex:1,overflowY:"auto",padding:PADDING}}>
      {/* Lot actif */}
      <div style={{background:`linear-gradient(135deg,${C.greenD},${C.green})`,
        color:"#fff",borderRadius:16,padding:20,marginBottom:16}}>
        <div style={{fontSize:11,opacity:.7,marginBottom:4,textTransform:"uppercase",
          letterSpacing:".06em"}}>CHANTIER ACTIF</div>
        <div style={{fontSize:18,fontWeight:600,marginBottom:2}}>{LOT.numero}</div>
        <div style={{fontSize:13,opacity:.8}}>{LOT.commune}</div>
      </div>

      {/* KPIs */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:16}}>
        {[
          {i:"🌲",l:"Abattu",v:`${totAbattu.toFixed(1)} t`,c:C.brown},
          {i:"🚜",l:"Débarié",v:`${totDebardie.toFixed(1)} t`,c:C.blue},
          {i:"👤",l:"Contacts",v:contacts.length,c:C.green},
        ].map(({i,l,v,c})=>(
          <div key={l} style={{background:"#fff",border:`1px solid ${C.bd}`,
            borderRadius:12,padding:14,textAlign:"center"}}>
            <div style={{fontSize:22,marginBottom:6}}>{i}</div>
            <div style={{fontSize:17,fontWeight:700,color:c}}>{v}</div>
            <div style={{fontSize:11,color:C.tx3,marginTop:3}}>{l}</div>
          </div>
        ))}
      </div>

      {/* Actions principales */}
      <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:16}}>
        <BigBtn onClick={()=>onNav("contact")} bg={C.green} icon="👤">
          Nouveau contact
        </BigBtn>
        <BigBtn onClick={()=>onNav("abatteur")} bg={C.brown} icon="🌲">
          Saisie abatteur — fin de journée
        </BigBtn>
        <BigBtn onClick={()=>onNav("debardeur")} bg={C.blue} icon="🚜">
          Saisie débardeur — fin de journée
        </BigBtn>
      </div>

      {/* Emplacements dépôt */}
      {emplacements.length>0&&(
        <div style={{background:"#fff",border:`1px solid ${C.bd}`,
          borderRadius:16,padding:16,marginBottom:16}}>
          <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:10}}>
            📦 Emplacements de dépôt
          </div>
          {emplacements.map(e=>{
            const pct = e.capaciteEstimeeM3>0
              ? Math.round(e.volumeAccumuleM3/e.capaciteEstimeeM3*100) : 0;
            return (
              <div key={e.id} style={{padding:"10px 0",
                borderBottom:`0.5px solid ${C.bd}`}}>
                <div style={{display:"flex",justifyContent:"space-between",
                  marginBottom:6,fontSize:13}}>
                  <span style={{fontWeight:500}}>{e.nom}</span>
                  <span style={{color:C.green,fontWeight:600}}>
                    {e.volumeAccumuleM3.toFixed(1)} m³
                  </span>
                </div>
                <div style={{height:6,background:C.bg2,borderRadius:3,overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${Math.min(100,pct)}%`,
                    background:pct>85?C.red:pct>60?C.amber:C.green,
                    borderRadius:3}}/>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Historique contacts récents */}
      {contacts.length>0&&(
        <div style={{background:"#fff",border:`1px solid ${C.bd}`,
          borderRadius:16,padding:16}}>
          <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:10}}>
            👤 Contacts récents
          </div>
          {contacts.slice(-3).reverse().map(c=>(
            <div key={c.id} style={{padding:"8px 0",
              borderBottom:`0.5px solid ${C.bd}`,fontSize:13}}>
              <div style={{fontWeight:500}}>{c.prenom?`${c.prenom} ${c.nom}`:c.nom}</div>
              <div style={{fontSize:12,color:C.tx3}}>{c.commune} · {c.telephone}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ── APP PRINCIPALE ─────────────────────────────────────────────
export default function App() {
  const [screen,          setScreen]          = useState("accueil");
  const [contacts,        setContacts]        = useState([]);
  const [relevesAbatteur, setRelevesAbatteur] = useState([]);
  const [relevesDebardeur,setRelevesDebardeur]= useState([]);
  const [emplacements,    setEmplacements]    = useState([
    {id:"emp1",nom:"Dépôt principal — bord RD943",
     gps:{lat:47.9812,lng:3.0891},capaciteEstimeeM3:400,
     volumeAccumuleM3:0,poidsAccumuleT:0,nbToursRecus:0},
    {id:"emp2",nom:"Zone secondaire — chemin forestier",
     gps:{lat:47.9834,lng:3.0912},capaciteEstimeeM3:150,
     volumeAccumuleM3:0,poidsAccumuleT:0,nbToursRecus:0},
  ]);

  const {toast,ToastContainer} = useToast();

  const LOT = {id:"l1",numero:"LOT-2025-007",commune:"Charny (89)"};

  const SCREENS = {
    contact: {title:"Nouveau contact", color:C.green},
    abatteur:{title:"Saisie abatteur", color:C.brown},
    debardeur:{title:"Saisie débardeur",color:C.blue},
  };

  const handleSaveContact = (c) => {
    setContacts(prev=>[...prev,c]);
    setScreen("accueil");
  };

  const handleSaveAbatteur = (r) => {
    setRelevesAbatteur(prev=>[...prev,r]);
    setScreen("accueil");
  };

  const handleSaveDebardeur = (r) => {
    setRelevesDebardeur(prev=>[...prev,r]);
    setEmplacements(prev=>prev.map(e=>e.id===r.emplacementId
      ? {...e,
          volumeAccumuleM3:Math.round((e.volumeAccumuleM3+r.volTotal)*100)/100,
          poidsAccumuleT:Math.round((e.poidsAccumuleT+r.poidsTotal)*100)/100,
          nbToursRecus:e.nbToursRecus+r.nbTours,
        } : e
    ));
    setScreen("accueil");
  };

  const sc = SCREENS[screen];

  return (
    <div style={{
      display:"flex",flexDirection:"column",
      height:"100dvh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      background:C.bg,color:C.tx,
      maxWidth:430,margin:"0 auto",
      boxShadow:"0 0 40px rgba(0,0,0,.15)",
    }}>
      <ToastContainer/>

      {/* Topbar */}
      <div style={{
        background:sc?sc.color:C.sb,
        color:"#fff",flexShrink:0,
        padding:"env(safe-area-inset-top,0) 0 0",
      }}>
        <div style={{
          display:"flex",alignItems:"center",gap:12,
          padding:"12px 16px 10px",
        }}>
          {screen!=="accueil" ? (
            <button onClick={()=>setScreen("accueil")} style={{
              background:"rgba(255,255,255,.2)",border:"none",cursor:"pointer",
              width:40,height:40,borderRadius:10,color:"#fff",
              display:"flex",alignItems:"center",justifyContent:"center",
              fontSize:20,flexShrink:0,WebkitTapHighlightColor:"transparent",
            }}>‹</button>
          ) : (
            <div style={{width:36,height:36,background:"rgba(255,255,255,.2)",
              borderRadius:9,display:"flex",alignItems:"center",
              justifyContent:"center",fontSize:18}}>🌲</div>
          )}
          <div style={{flex:1}}>
            <div style={{fontSize:16,fontWeight:600}}>
              {sc ? sc.title : "APPLITAG"}
            </div>
            {!sc&&<div style={{fontSize:11,opacity:.6}}>
              Terrain · Jean-Christophe LETIERCE
            </div>}
          </div>
          {!sc&&(
            <div style={{fontSize:11,background:"rgba(255,255,255,.15)",
              padding:"4px 10px",borderRadius:7}}>
              {LOT.numero}
            </div>
          )}
        </div>
      </div>

      {/* Contenu */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        {screen==="accueil"&&(
          <Accueil onNav={setScreen}
            contacts={contacts}
            relevesAbatteur={relevesAbatteur}
            relevesDebardeur={relevesDebardeur}
            emplacements={emplacements}/>
        )}
        {screen==="contact"&&(
          <EcranContact onBack={()=>setScreen("accueil")}
            onSaved={handleSaveContact} toast={toast}/>
        )}
        {screen==="abatteur"&&(
          <EcranAbatteur lot={LOT}
            onBack={()=>setScreen("accueil")}
            onSaved={handleSaveAbatteur} toast={toast}/>
        )}
        {screen==="debardeur"&&(
          <EcranDebardeur lot={LOT}
            emplacements={emplacements}
            onBack={()=>setScreen("accueil")}
            onSaved={handleSaveDebardeur} toast={toast}/>
        )}
      </div>

      {/* Bottom nav */}
      {screen==="accueil"&&(
        <div style={{
          background:"#fff",borderTop:`0.5px solid ${C.bd}`,
          display:"grid",gridTemplateColumns:"repeat(3,1fr)",
          padding:"8px 0",paddingBottom:"env(safe-area-inset-bottom,8px)",
          flexShrink:0,
        }}>
          {[
            {icon:"🏠",label:"Accueil",key:"accueil"},
            {icon:"🌲",label:"Abattage",key:"abatteur"},
            {icon:"🚜",label:"Débardage",key:"debardeur"},
          ].map(({icon,label,key})=>(
            <button key={key} onClick={()=>setScreen(key)} style={{
              display:"flex",flexDirection:"column",alignItems:"center",gap:3,
              background:"none",border:"none",cursor:"pointer",
              padding:"6px 0",fontFamily:"inherit",
              WebkitTapHighlightColor:"transparent",
            }}>
              <span style={{fontSize:22,opacity:screen===key?1:.4}}>{icon}</span>
              <span style={{fontSize:10,fontWeight:500,
                color:screen===key?C.green:C.tx3}}>{label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
