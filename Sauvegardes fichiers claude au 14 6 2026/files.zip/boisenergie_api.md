# BoisÉnergie — API REST & Migration Prisma

## Stack : NestJS · PostgreSQL · Prisma ORM · JWT

---

## 1. Migration Prisma

```bash
# Initialiser
npx prisma migrate dev --name init

# Générer le client
npx prisma generate

# Vérifier le schéma
npx prisma validate

# Ouvrir Prisma Studio
npx prisma studio
```

---

## 2. Seeds de données de test

```typescript
// prisma/seed.ts
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {

  // ── ENTREPRISES ──────────────────────────────────────────
  const ent_exploitant = await prisma.entreprise.create({ data: {
    type: 'exploitant', raisonSociale: 'BoisÉnergie Bourgogne',
    siret: '12345678900012', email: 'contact@boisenergie.fr',
    telephone: '03 86 00 00 01', contactNom: 'Jean Moreau',
  }});
  const ent_etf = await prisma.entreprise.create({ data: {
    type: 'etf', raisonSociale: 'ETF Moreau',
    siret: '98765432100034', email: 'etf@moreau.fr',
    telephone: '06 12 34 56 78', contactNom: 'Paul Moreau',
  }});
  const ent_transport = await prisma.entreprise.create({ data: {
    type: 'transporteur', raisonSociale: 'Transport Martel',
    siret: '11111111100056', email: 'martel@transport.fr',
  }});
  const ent_chaufferie = await prisma.entreprise.create({ data: {
    type: 'chaufferie', raisonSociale: 'Chaufferie Troyes Est',
    siret: '22222222200078', email: 'reception@chaufferie-troyes.fr',
    adresse: 'Zone industrielle Est, 10300 Troyes',
  }});

  // ── USERS ─────────────────────────────────────────────────
  const hash = await bcrypt.hash('password123', 12);
  const admin = await prisma.user.create({ data: {
    nom: 'Admin', prenom: 'Système', email: 'admin@boisenergie.fr',
    motDePasseHash: hash, role: 'admin', entrepriseId: ent_exploitant.id,
  }});
  const exploitant = await prisma.user.create({ data: {
    nom: 'Moreau', prenom: 'Jean', email: 'j.moreau@boisenergie.fr',
    motDePasseHash: hash, role: 'exploitant', entrepriseId: ent_exploitant.id,
  }});
  const operateur = await prisma.user.create({ data: {
    nom: 'Girard', prenom: 'Pierre', email: 'p.girard@etf-moreau.fr',
    motDePasseHash: hash, role: 'operateur', entrepriseId: ent_etf.id,
  }});
  const chauffeur = await prisma.user.create({ data: {
    nom: 'Martel', prenom: 'Denis', email: 'd.martel@transport-martel.fr',
    motDePasseHash: hash, role: 'chauffeur', entrepriseId: ent_transport.id,
  }});
  const receptionnaire = await prisma.user.create({ data: {
    nom: 'Dupont', prenom: 'Marc', email: 'm.dupont@chaufferie-troyes.fr',
    motDePasseHash: hash, role: 'chaufferie', entrepriseId: ent_chaufferie.id,
  }});

  // ── PROPRIÉTAIRES ─────────────────────────────────────────
  const prop1 = await prisma.proprietaire.create({ data: {
    type: 'particulier', nom: 'M. Bernard',
    telephone: '06 11 22 33 44', email: 'bernard@mail.fr',
    adresse: '12 rue des Bois, 89120 Charny',
  }});
  const prop2 = await prisma.proprietaire.create({ data: {
    type: 'sci', nom: 'SCI Les Bois',
    telephone: '03 86 11 22 33', email: 'contact@scilesbois.fr',
  }});

  // ── LOT COMPLET (EN_EXPLOITATION) ─────────────────────────
  const lot = await prisma.lot.create({ data: {
    numeroLot: 'LOT-2025-007',
    statut: 'EN_EXPLOITATION',
    typeLot: 'taillis',
    createurId: exploitant.id,
    entrepriseExploitanteId: ent_exploitant.id,
    dateDebutPrevue: new Date('2025-03-01'),
    dateFinPrevue: new Date('2025-06-30'),
    certification: true,
    certificationType: 'PEFC',
    certificationRef: 'PEFC/10-31-2089',
    essencePrincipale: 'peuplier',
    volumeEstime: 350,
    humiditeEstimee: 35,
    gpsLat: 47.9812,
    gpsLng: 3.0891,
    commentaire: 'Accès chemin forestier praticable. Rémanents zone nord.',
    proprietaires: { create: [
      { proprietaireId: prop1.id, roleSurLot: 'Propriétaire principal' },
      { proprietaireId: prop2.id, roleSurLot: 'Ayant droit' },
    ]},
    parcelles: { create: [
      { referenceCadastrale: 'A-042', commune: 'Charny', surfaceHa: 8.5,
        gpsLat: 47.9812, gpsLng: 3.0891, accesDescription: 'Chemin forestier 4m' },
      { referenceCadastrale: 'A-043', commune: 'Charny', surfaceHa: 4.0,
        gpsLat: 47.9820, gpsLng: 3.0900 },
    ]},
    visites: { create: [{
      utilisateurId: exploitant.id,
      dateVisite: new Date('2025-02-18'),
      essences: [
        { essence: 'peuplier', pct: 65, volume_t: 227, granulometrie: 'p45' },
        { essence: 'frene',    pct: 25, volume_t: 87,  granulometrie: 'p45' },
        { essence: 'saule',    pct: 10, volume_t: 36,  granulometrie: 'p63' },
      ],
      volumeEstime: 350,
      surfaceEstimee: 12.5,
      observations: 'Zone nord : rémanents anciens.',
      validation: true,
      gpsLat: 47.9801, gpsLng: 3.0876,
    }]},
    tas: { create: [
      { numeroTas: 'A', gpsLat: 47.9812, gpsLng: 3.0891,
        volumeEstime: 85, essence: 'peuplier', humiditeEstimee: 36,
        complet: true, statut: 'pret', disponible: true },
      { numeroTas: 'B', gpsLat: 47.9807, gpsLng: 3.0899,
        volumeEstime: 35, essence: 'frene', humiditeEstimee: 34,
        complet: true, statut: 'pret', disponible: true },
      { numeroTas: 'C', gpsLat: 47.9819, gpsLng: 3.0884,
        volumeEstime: 35, essence: 'peuplier',
        complet: false, statut: 'en_cours', disponible: false },
    ]},
  }});

  // Relevés journaliers
  await prisma.chantierOperation.create({ data: {
    lotId: lot.id, typeOperation: 'abattage_debardage',
    entrepriseId: ent_etf.id, operateurId: operateur.id,
    machine: 'Tronçonneuse + Skidder AB-234', statut: 'en_cours',
    dateDebut: new Date('2025-03-03'),
  }});

  console.log('✅ Seeds exécutés avec succès');
  console.log(`   ${await prisma.user.count()} utilisateurs`);
  console.log(`   ${await prisma.entreprise.count()} entreprises`);
  console.log(`   ${await prisma.lot.count()} lots`);
  console.log(`   ${await prisma.tas.count()} tas`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
```

```json
// package.json — ajouter :
{
  "prisma": {
    "seed": "ts-node prisma/seed.ts"
  }
}
```

```bash
npx prisma db seed
```

---

## 3. Endpoints API REST

### Convention
- Base URL : `/api/v1`
- Auth : `Authorization: Bearer <jwt>`
- Erreurs : `{ statusCode, message, error }`
- Pagination : `?page=1&limit=20`
- Soft delete : `DELETE` → `deleted_at = NOW()`

---

### AUTH

```
POST   /api/v1/auth/login
POST   /api/v1/auth/refresh
POST   /api/v1/auth/logout
GET    /api/v1/auth/me
```

**POST /auth/login**
```json
// Body
{ "email": "j.moreau@boisenergie.fr", "password": "password123" }

// Response 200
{
  "accessToken": "eyJ...",
  "refreshToken": "eyJ...",
  "user": { "id": "uuid", "nom": "Moreau", "prenom": "Jean", "role": "exploitant" }
}
```

---

### LOTS

```
GET    /api/v1/lots                    Liste paginée + filtres
GET    /api/v1/lots/:id               Fiche complète
POST   /api/v1/lots                    Créer
PATCH  /api/v1/lots/:id               Modifier
PATCH  /api/v1/lots/:id/statut        Changer le statut
DELETE /api/v1/lots/:id               Soft delete (admin)
GET    /api/v1/lots/:id/stock         Stock bord de route calculé
GET    /api/v1/lots/:id/cloture-status Conditions de clôture
```

**GET /lots** — Query params
```
?statut=EN_EXPLOITATION
?commune=Charny
?entrepriseId=uuid
?page=1&limit=20
?sort=date_creation&order=desc
```

**POST /lots** — Body
```json
{
  "commune": "Charny (89)",
  "typeLot": "taillis",
  "essencePrincipale": "peuplier",
  "volumeEstime": 350,
  "humiditeEstimee": 35,
  "gpsLat": 47.9812,
  "gpsLng": 3.0891,
  "certification": true,
  "certificationType": "PEFC",
  "certificationRef": "PEFC/10-31-2089",
  "entrepriseExploitanteId": "uuid",
  "dateDebutPrevue": "2025-03-01",
  "dateFinPrevue": "2025-06-30",
  "commentaire": "...",
  "proprietaireIds": ["uuid1", "uuid2"]
}
```

**Règles de validation POST /lots**
- `commune` : required, string, min 2 chars
- `gpsLat` : required, number, between -90 and 90
- `gpsLng` : required, number, between -180 and 180
- `volumeEstime` : optional, number, min 0
- `humiditeEstimee` : optional, number, between 0 and 100
- `proprietaireIds` : min 1 élément

**PATCH /lots/:id/statut** — Body
```json
{
  "statut": "VALIDE_EXPLOITATION",
  "motif": "Visite validée le 18/02/2025"
}
```

**Règle** : transition vérifiée côté API ET côté trigger SQL.
Transitions invalides → 422 Unprocessable Entity.

---

### PARCELLES

```
GET    /api/v1/lots/:lotId/parcelles
POST   /api/v1/lots/:lotId/parcelles
PATCH  /api/v1/parcelles/:id
DELETE /api/v1/parcelles/:id
```

**POST /lots/:lotId/parcelles**
```json
{
  "referenceCadastrale": "A-042",
  "commune": "Charny",
  "surfaceHa": 8.5,
  "gpsLat": 47.9812,
  "gpsLng": 3.0891,
  "accesDescription": "Chemin forestier 4m largeur",
  "contraintes": "Rémanents zone nord"
}
```

---

### VISITES TERRAIN

```
GET    /api/v1/lots/:lotId/visites
GET    /api/v1/visites/:id
POST   /api/v1/lots/:lotId/visites
PATCH  /api/v1/visites/:id
PATCH  /api/v1/visites/:id/valider
```

**POST /lots/:lotId/visites**
```json
{
  "dateVisite": "2025-02-18",
  "essences": [
    { "essence": "peuplier", "pct": 65, "volume_t": 227, "granulometrie": "p45" },
    { "essence": "frene",    "pct": 25, "volume_t": 87,  "granulometrie": "p45" }
  ],
  "volumeEstime": 350,
  "surfaceEstimee": 12.5,
  "observations": "Zone nord : rémanents.",
  "gpsLat": 47.9801,
  "gpsLng": 3.0876
}
```

**PATCH /visites/:id/valider**
```json
{ "validation": true }
// Déclenche → lot.statut = VISITE_REALISEE
```

**Règle** : `SUM(essences[].pct)` doit égaler 100 ± 2 %.

---

### OPÉRATIONS CHANTIER

```
GET    /api/v1/lots/:lotId/operations
POST   /api/v1/lots/:lotId/operations
PATCH  /api/v1/operations/:id
POST   /api/v1/operations/:id/releve   Saisir tonnage journalier
```

**POST /operations/:id/releve**
```json
{
  "date": "2025-06-06",
  "tonnageT": 48,
  "humiditePct": 36,
  "meteo": "nuageux",
  "incident": "aucun",
  "notes": "Bonnes conditions terrain"
}
```

**Règle** : unique par (lotId, operateurId, date).
Déclenche trigger → `lots.volume_reel` recalculé.

---

### TAS

```
GET    /api/v1/lots/:lotId/tas
GET    /api/v1/tas/:id
POST   /api/v1/lots/:lotId/tas
PATCH  /api/v1/tas/:id
PATCH  /api/v1/tas/:id/completer       Marquer complet → statut = prêt
```

**POST /lots/:lotId/tas**
```json
{
  "numeroTas": "C",
  "gpsLat": 47.9819,
  "gpsLng": 3.0884,
  "volumeEstime": 35,
  "poidsEstime": 33,
  "essence": "peuplier",
  "humiditeEstimee": 35
}
```

**PATCH /tas/:id/completer**
```json
{}
// Passe statut → pret, disponible → true
// Si tous tas prets → lot.statut → BORD_ROUTE
```

**Règle** : GPS obligatoire. `numeroTas` unique par lot.

---

### DÉCHIQUETAGES

```
GET    /api/v1/lots/:lotId/dechiquetages
POST   /api/v1/lots/:lotId/dechiquetages
PATCH  /api/v1/dechiquetages/:id
PATCH  /api/v1/dechiquetages/:id/valider-chargement
```

**POST /lots/:lotId/dechiquetages**
```json
{
  "entrepriseId": "uuid",
  "operateurId": "uuid",
  "immatEngin": "AB-123-CD",
  "enginDescription": "Bandit 2590XP",
  "granulometrie": "p45",
  "tasIds": ["uuid-tas-A", "uuid-tas-B"],
  "dateDebut": "2025-06-09T06:00:00Z"
}
```

**PATCH /dechiquetages/:id/valider-chargement**
```json
{
  "volumeChargeT": 42,
  "humiditePct": 34,
  "dateFin": "2025-06-09T08:30:00Z"
}
// Génère automatiquement le CMR
// Passe tas sélectionnés → statut = déchiqueté
// lot.statut → DECHIQUETAGE_EN_COURS
```

**Règles** :
- `immatEngin` : required, format regex `/^[A-Z]{2}-\d{3}-[A-Z]{2}$/`
- `tasIds` : min 1 tas, tous en statut `pret`
- `volumeChargeT` : required pour valider chargement

---

### TRANSPORTS

```
GET    /api/v1/lots/:lotId/transports
GET    /api/v1/transports/:id
POST   /api/v1/lots/:lotId/transports
PATCH  /api/v1/transports/:id
PATCH  /api/v1/transports/:id/valider-depart
PATCH  /api/v1/transports/:id/valider-arrivee
```

**POST /lots/:lotId/transports**
```json
{
  "dechiquetageId": "uuid",
  "transporteurId": "uuid",
  "chauffeurNom": "D. Martel",
  "typeVehicule": "Semi-remorque",
  "immatriculationTracteur": "EF-456-GH",
  "immatriculationRemorque": "IJ-789-KL",
  "poidsBrutT": 60.0,
  "poidsTareT": 18.0,
  "heureArriveePrevue": "2025-06-09T09:05:00Z"
}
```

**PATCH /transports/:id/valider-depart**
```json
{
  "heureDepart": "2025-06-09T07:45:00Z",
  "gpsDepart": { "lat": 47.9812, "lng": 3.0891 },
  "signatureChauffeurUrl": "https://s3.../signature-cmr-089.png"
}
// lot.statut → EN_TRANSPORT
// cmrReference généré automatiquement
```

**Règles** :
- `immatriculationTracteur` : required
- `poidsBrutT >= poidsTareT` obligatoire
- `signatureChauffeurUrl` : required pour valider départ

---

### LIVRAISONS

```
GET    /api/v1/lots/:lotId/livraisons
GET    /api/v1/livraisons/:id
POST   /api/v1/transports/:transportId/livraison
PATCH  /api/v1/livraisons/:id
PATCH  /api/v1/livraisons/:id/valider
PATCH  /api/v1/livraisons/:id/litige
```

**POST /transports/:transportId/livraison**
```json
{
  "destinationType": "chaufferie",
  "destinationId": "uuid-chaufferie",
  "gpsLivraisonLat": 48.2900,
  "gpsLivraisonLng": 4.0733,
  "poidsEntree": 60.0,
  "poidsSortie": 18.0,
  "humidite": 32,
  "dateLivraison": "2025-06-09T09:12:00Z",
  "receptionnaire": "M. Dupont",
  "ticketBascule": "TB-2025-04421"
}
// numeroBl généré : BL-2025-XXXX
// lotReference dénormalisé depuis lot.numeroLot
```

**PATCH /livraisons/:id/valider**
```json
{
  "signatureUrl": "https://s3.../signature-bl-089.png"
}
// Vérifie humidite <= client.humiditeMax → sinon alerte
// Si toutes livraisons lot = valide → lot.statut → LIVRE (trigger)
```

**PATCH /livraisons/:id/litige**
```json
{
  "cause": "humidite",
  "valeurConstatee": 38,
  "valeurAttendue": 35,
  "description": "Humidité mesurée à 38 % dépasse le seuil contractuel de 35 %"
}
// lot.statut → EN_LITIGE si non résolu
```

---

### DOCUMENTS

```
GET    /api/v1/lots/:lotId/documents
POST   /api/v1/lots/:lotId/documents    Upload S3
DELETE /api/v1/documents/:id
GET    /api/v1/documents/:id/url        URL présignée S3
```

**POST /lots/:lotId/documents**
```
Content-Type: multipart/form-data

typeDocument: "photo"
refType: "tas"
refId: "uuid-tas"
file: <binary>
```

**Response**
```json
{
  "id": "uuid",
  "fichierUrl": "https://s3.amazonaws.com/boisenergie/lots/LOT-2025-007/...",
  "typeDocument": "photo",
  "createdAt": "2025-06-09T08:00:00Z"
}
```

---

### ALERTES

```
GET    /api/v1/alertes                  Toutes (filtres niveau, statut)
GET    /api/v1/lots/:lotId/alertes
PATCH  /api/v1/alertes/:id/resoudre
```

---

### HISTORIQUES

```
GET    /api/v1/lots/:lotId/historiques   Audit trail complet
GET    /api/v1/historiques?userId=uuid   Par utilisateur
```

---

## 4. Guards NestJS (rôles)

```typescript
// Exemple décorateur
@Roles('exploitant', 'admin')
@Patch(':id/statut')
changerStatut(@Param('id') id: string, @Body() dto: ChangerStatutDto) {}

// Matrice simplifiée
// POST /lots              → exploitant, admin
// PATCH /lots/:id/statut  → exploitant, admin
// POST /operations/releve → operateur, exploitant, admin
// POST /tas/:id/completer → operateur, exploitant, admin
// PATCH /transports/depart→ chauffeur, transporteur
// POST /livraisons        → chaufferie, receptionnaire
// GET  /historiques       → admin, exploitant
```

---

## 5. Variables d'environnement

```env
# .env
DATABASE_URL="postgresql://user:password@localhost:5432/boisenergie"
JWT_SECRET="your-super-secret-key-min-32-chars"
JWT_EXPIRY="24h"
JWT_REFRESH_EXPIRY="30d"
S3_BUCKET="boisenergie-docs"
S3_REGION="eu-west-3"
S3_ACCESS_KEY="..."
S3_SECRET_KEY="..."
SENTRY_DSN="..."
PORT=3000
```

