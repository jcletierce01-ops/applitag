import { useState } from "react";
import Contacts     from "./applitag_sprint0_contacts.jsx";
import Visite       from "./applitag_sprint1_visite.jsx";
import Tas          from "./applitag_gestion_tas.jsx";
import Dashboard    from "./applitag_dashboard_web.jsx";
import Offline      from "./applitag_offline_sync.jsx";
import Documents    from "./applitag_documents_terrain.jsx";
import Checklist    from "./applitag_checklist_pilote.jsx";
import FinChantier  from "./applitag_fin_chantier_rentabilite.jsx";
import Essences     from "./applitag_referentiel_essences.jsx";
import Mvp          from "./applitag_mvp_stabilisation.jsx";

const MODULES = [
  { id:"contacts",   label:"Contact & Opportunité",    icon:"👤", color:"#1D9E75", Component:Contacts    },
  { id:"visite",     label:"Visite terrain",           icon:"🔭", color:"#185FA5", Component:Visite      },
  { id:"tas",        label:"Gestion des tas",          icon:"📦", color:"#8B6914", Component:Tas         },
  { id:"dashboard",  label:"Dashboard PC",             icon:"🖥️", color:"#534AB7", Component:Dashboard   },
  { id:"offline",    label:"Offline & Sync",           icon:"📡", color:"#BA7517", Component:Offline     },
  { id:"documents",  label:"Documents terrain",        icon:"📄", color:"#185FA5", Component:Documents   },
  { id:"checklist",  label:"Checklist pilote",         icon:"✅", color:"#1D9E75", Component:Checklist   },
  { id:"fin",        label:"Fin de chantier",          icon:"📊", color:"#534AB7", Component:FinChantier },
  { id:"essences",   label:"Référentiel essences",     icon:"🌿", color:"#3B6D11", Component:Essences    },
  { id:"mvp",        label:"MVP & Présentation",       icon:"🚀", color:"#D85A30", Component:Mvp         },
];

const G = "#1D9E75";

export default function App() {
  const [active, setActive] = useState(null);
  const mod = MODULES.find(m => m.id === active);

  if (mod) {
    const { Component, label, icon } = mod;
    return (
      <div style={{fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"}}>
        {/* Barre retour sticky */}
        <div style={{position:"sticky",top:0,zIndex:1000,background:"#111",
          display:"flex",alignItems:"center",gap:10,padding:"10px 14px",
          borderBottom:".5px solid #222"}}>
          <button onClick={()=>setActive(null)} style={{
            background:"none",border:"none",color:G,
            fontSize:22,cursor:"pointer",padding:"0 8px 0 0",lineHeight:1,
          }}>‹</button>
          <span style={{fontSize:16}}>{icon}</span>
          <span style={{fontSize:13,fontWeight:600,color:"#fff"}}>{label}</span>
          <div style={{marginLeft:"auto",fontSize:11,color:"#444"}}>APPLITAG</div>
        </div>
        {/* Module complet */}
        <Component />
      </div>
    );
  }

  return (
    <div style={{fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      background:"#111",color:"#fff",minHeight:"100vh"}}>

      {/* Header */}
      <div style={{padding:"24px 18px 16px",borderBottom:".5px solid #1a1a1a"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16}}>
          <div style={{width:38,height:38,background:G,borderRadius:8,
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:19}}>🌲</div>
          <div>
            <div style={{fontSize:20,fontWeight:600}}>
              APPLI<span style={{color:G}}>TAG</span>
            </div>
            <div style={{fontSize:10,color:"#444"}}>MVP v1.0 · Jean-Christophe LETIERCE</div>
          </div>
        </div>
        <div style={{fontSize:14,color:"#9FE1CB",lineHeight:1.6}}>
          De la forêt à la chaufferie — tracé à chaque étape.
        </div>
      </div>

      {/* Grille modules */}
      <div style={{padding:"16px",display:"grid",
        gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))",gap:10}}>
        {MODULES.map(m => (
          <div key={m.id} onClick={()=>setActive(m.id)} style={{
            background:"rgba(255,255,255,.05)",
            border:`.5px solid rgba(255,255,255,.1)`,
            borderRadius:12,padding:"14px 12px",cursor:"pointer",
            transition:"all .15s",
          }}
          onMouseEnter={e=>{e.currentTarget.style.borderColor=m.color;e.currentTarget.style.background=m.color+"18"}}
          onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,.1)";e.currentTarget.style.background="rgba(255,255,255,.05)"}}>
            <div style={{fontSize:26,marginBottom:10}}>{m.icon}</div>
            <div style={{fontSize:12,fontWeight:600,color:"#fff",marginBottom:6,lineHeight:1.3}}>
              {m.label}
            </div>
            <div style={{fontSize:10,color:m.color}}>Ouvrir →</div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div style={{padding:"16px 18px 28px",borderTop:".5px solid #1a1a1a",
        display:"flex",justifyContent:"space-between"}}>
        <span style={{fontSize:11,color:"#333"}}>www.applitag.fr</span>
        <span style={{fontSize:11,color:"#333"}}>contact@applitag.fr</span>
      </div>
    </div>
  );
}
