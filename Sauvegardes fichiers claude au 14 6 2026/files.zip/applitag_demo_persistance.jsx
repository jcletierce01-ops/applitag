// ============================================================
// APPLITAG — Sprint : Scénario Démo + Démo Guidée + Persistance
// JSDoc TypeScript-style · Mock cohérent · Parcours 10 étapes
// ============================================================

import { useState, useCallback, useEffect, useRef, useMemo } from "react";

// ── TYPES ──────────────────────────────────────────────────────────────────────
/**
 * @typedef {'proprietaire_forestier'|'cooperative'|'etf'|'transporteur'|'chaufferie'|'plateforme'} ContactType
 * @typedef {'nouveau'|'a_rappeler'|'qualifie'|'converti'|'perdu'} ContactStatut
 * @typedef {'nouvelle'|'a_visiter'|'visite_programmee'|'visite_faite'|'lot_cree'|'perdue'} OppStatut
 * @typedef {'BROUILLON'|'A_VISITER'|'VISITE_REALISEE'|'VALIDE_EXPLOITATION'|'EN_EXPLOITATION'|'BORD_ROUTE'|'A_DECHIQUETER'|'EN_TRANSPORT'|'PARTIELLEMENT_LIVRE'|'LIVRE'|'CLOTURE'} LotStatut
 * @typedef {'prepare'|'en_route'|'arrive'|'annule'} TransportStatut
 * @typedef {'info'|'warn'|'critique'} AlerteNiveau
 */

/**
 * @typedef {Object} Contact
 * @property {string} id
 * @property {string} nom
 * @property {string} [prenom]
 * @property {string} telephone
 * @property {string} [email]
 * @property {string} [societe]
 * @property {ContactType} typeContact
 * @property {ContactStatut} statut
 * @property {string} [origine]
 * @property {string} [commentaire]
 * @property {number} [gpsLat]
 * @property {number} [gpsLng]
 * @property {string} createdAt
 */

/**
 * @typedef {Object} Opportunite
 * @property {string} id
 * @property {string} contactId
 * @property {string} [commune]
 * @property {number} [volumeEstime]
 * @property {string} [typeBois]
 * @property {'basse'|'normale'|'haute'|'immediate'} urgence
 * @property {OppStatut} statut
 * @property {string} [notes]
 * @property {string} [lotId]
 * @property {number} [gpsLat]
 * @property {number} [gpsLng]
 * @property {string} createdAt
 */

/**
 * @typedef {Object} Tas
 * @property {string} id
 * @property {string} lotId
 * @property {string} numeroTas
 * @property {number} volumeEstime
 * @property {string} essence
 * @property {'en_cours'|'pret'|'dechiquete'} statut
 * @property {number} gpsLat
 * @property {number} gpsLng
 */

/**
 * @typedef {Object} Lot
 * @property {string} id
 * @property {string} numeroLot
 * @property {LotStatut} statut
 * @property {string} commune
 * @property {string} [essencePrincipale]
 * @property {number} [volumeEstime]
 * @property {number} [volumeReel]
 * @property {number} [surfaceHa]
 * @property {number} [humidite]
 * @property {number} gpsLat
 * @property {number} gpsLng
 * @property {string} [certification]
 * @property {string} [etfNom]
 * @property {string} [opportuniteId]
 * @property {string} [contactId]
 * @property {Tas[]} tas
 * @property {string} createdAt
 */

/**
 * @typedef {Object} Transport
 * @property {string} id
 * @property {string} lotId
 * @property {string} lotNumero
 * @property {string} chauffeur
 * @property {string} immatriculation
 * @property {string} destination
 * @property {TransportStatut} statut
 * @property {number} poidsT
 * @property {string} [heureDepart]
 * @property {number} gpsLat
 * @property {number} gpsLng
 * @property {string} createdAt
 */

/**
 * @typedef {Object} Chaufferie
 * @property {string} id
 * @property {string} nom
 * @property {string} commune
 * @property {number} capaciteTan
 * @property {number} stockActuelT
 * @property {number} humiditeMax
 * @property {number} gpsLat
 * @property {number} gpsLng
 */

/**
 * @typedef {Object} Plateforme
 * @property {string} id
 * @property {string} nom
 * @property {string} commune
 * @property {number} capaciteT
 * @property {number} stockActuelT
 * @property {number} humiditeMoy
 * @property {number} gpsLat
 * @property {number} gpsLng
 */

/**
 * @typedef {Object} Alerte
 * @property {string} id
 * @property {AlerteNiveau} niveau
 * @property {string} message
 * @property {string} refType
 * @property {string} [refId]
 * @property {boolean} resolue
 * @property {string} createdAt
 */

/**
 * @typedef {Object} HistoriqueEvent
 * @property {string} id
 * @property {string} refId
 * @property {string} refType
 * @property {string} action
 * @property {string} message
 * @property {string} utilisateur
 * @property {string} createdAt
 */

/**
 * @typedef {Object} AppStore
 * @property {Contact[]} contacts
 * @property {Opportunite[]} opportunites
 * @property {Lot[]} lots
 * @property {Transport[]} transports
 * @property {Chaufferie[]} chaufferies
 * @property {Plateforme[]} plateformes
 * @property {Alerte[]} alertes
 * @property {HistoriqueEvent[]} historique
 */

// ── DATASET DÉMO ───────────────────────────────────────────────────────────────
/** @returns {AppStore} */
const buildDemoData = () => ({
  contacts: [
    { id:"c1", nom:"Vasseur", prenom:"Alain", telephone:"06 12 34 56 78",
      email:"a.vasseur@gmail.com", typeContact:"proprietaire_forestier",
      statut:"a_rappeler", origine:"appel_entrant",
      commentaire:"~500 t de peuplier bord de route en Yonne. Rappel vendredi matin.",
      gpsLat:47.98, gpsLng:3.09, createdAt:"2025-06-01T08:00:00Z" },
    { id:"c2", nom:"Coop Forêts Bourgogne", telephone:"03 86 44 55 66",
      email:"contact@coopbourgogne.fr", typeContact:"cooperative",
      statut:"qualifie", origine:"recommandation",
      commentaire:"Gère 12 propriétés sur Yonne-Nièvre. Budget coupes 2025-2026.",
      gpsLat:47.32, gpsLng:3.01, createdAt:"2025-05-15T09:00:00Z" },
    { id:"c3", nom:"Lemaire", prenom:"Patrick", telephone:"06 88 77 66 55",
      typeContact:"proprietaire_forestier", statut:"qualifie", origine:"visite_terrain",
      commentaire:"200 t chêne. Accès difficile — piste forestière 3m. Urgence modérée.",
      gpsLat:47.85, gpsLng:3.52, createdAt:"2025-05-20T10:00:00Z" },
    { id:"c4", nom:"ETF Duclos Forêts", telephone:"06 22 33 44 55",
      email:"duclos@etfforets.fr", typeContact:"etf", statut:"converti",
      societe:"Duclos Forêts SARL", origine:"recommandation",
      commentaire:"Spé. peuplier Yonne. Disponible mars-juillet. Zone Charny-Joigny.",
      gpsLat:47.98, gpsLng:2.98, createdAt:"2025-04-10T08:00:00Z" },
    { id:"c5", nom:"Girard Transport", telephone:"03 86 12 34 56",
      typeContact:"transporteur", statut:"qualifie", societe:"Girard Transport SA",
      commentaire:"4 semi-remorques. Disponibles dès 06h. Rayon 150 km.",
      gpsLat:48.10, gpsLng:3.25, createdAt:"2025-04-20T11:00:00Z" },
  ],

  opportunites: [
    { id:"o1", contactId:"c1", commune:"Charny (89)", volumeEstime:500,
      typeBois:"bois_sur_pied", urgence:"haute", statut:"a_visiter",
      notes:"Peuplier 65%, frêne 35%. Accès chemin forestier praticable.",
      gpsLat:47.98, gpsLng:3.09, createdAt:"2025-06-01T08:30:00Z" },
    { id:"o2", contactId:"c2", commune:"Auxerre (89)", volumeEstime:800,
      typeBois:"bois_abattu", urgence:"normale", statut:"visite_programmee",
      notes:"Plusieurs parcelles. Chêne futaie. Certification PEFC possible.",
      gpsLat:47.80, gpsLng:3.57, createdAt:"2025-05-16T09:00:00Z" },
    { id:"o3", contactId:"c3", commune:"Tonnerre (89)", volumeEstime:200,
      typeBois:"bois_sur_pied", urgence:"basse", statut:"visite_faite",
      notes:"Chêne 100%. Visite réalisée 28/05. Volume confirmé 190 t.",
      gpsLat:47.85, gpsLng:3.98, createdAt:"2025-05-21T10:00:00Z" },
    { id:"o4", contactId:"c1", commune:"Joigny (89)", volumeEstime:320,
      typeBois:"bord_de_route", urgence:"haute", statut:"lot_cree",
      notes:"Peuplier bord de route. LOT créé.", lotId:"LOT-2025-006",
      gpsLat:47.98, gpsLng:2.98, createdAt:"2025-04-05T08:00:00Z" },
  ],

  lots: [
    { id:"l1", numeroLot:"LOT-2025-007", statut:"EN_EXPLOITATION",
      commune:"Charny (89)", essencePrincipale:"peuplier",
      volumeEstime:350, volumeReel:238, surfaceHa:12.5, humidite:38,
      gpsLat:47.9812, gpsLng:3.0891, certification:"PEFC",
      etfNom:"ETF Duclos Forêts", opportuniteId:"o1", contactId:"c1",
      tas:[
        {id:"t1",lotId:"l1",numeroTas:"A",volumeEstime:85,essence:"peuplier",statut:"pret",gpsLat:47.9812,gpsLng:3.0891},
        {id:"t2",lotId:"l1",numeroTas:"B",volumeEstime:35,essence:"frene",statut:"pret",gpsLat:47.9807,gpsLng:3.0899},
        {id:"t3",lotId:"l1",numeroTas:"C",volumeEstime:35,essence:"peuplier",statut:"en_cours",gpsLat:47.9819,gpsLng:3.0884},
      ], createdAt:"2025-01-15T08:00:00Z" },
    { id:"l2", numeroLot:"LOT-2025-006", statut:"EN_TRANSPORT",
      commune:"Joigny (89)", essencePrincipale:"peuplier",
      volumeEstime:320, volumeReel:318, surfaceHa:9.0, humidite:32,
      gpsLat:47.9826, gpsLng:2.9816, certification:"PEFC",
      etfNom:"ETF Duclos Forêts", opportuniteId:"o4", contactId:"c1",
      tas:[
        {id:"t4",lotId:"l2",numeroTas:"A",volumeEstime:160,essence:"peuplier",statut:"dechiquete",gpsLat:47.983,gpsLng:2.982},
        {id:"t5",lotId:"l2",numeroTas:"B",volumeEstime:158,essence:"peuplier",statut:"dechiquete",gpsLat:47.981,gpsLng:2.981},
      ], createdAt:"2025-02-01T08:00:00Z" },
    { id:"l3", numeroLot:"LOT-2025-005", statut:"LIVRE",
      commune:"Sens (89)", essencePrincipale:"chene",
      volumeEstime:145, volumeReel:142, surfaceHa:5.5, humidite:31,
      gpsLat:48.1967, gpsLng:3.2875, certification:"FSC",
      etfNom:"Coop Forêts Bourgogne",
      tas:[], createdAt:"2025-03-01T08:00:00Z" },
  ],

  transports: [
    { id:"tr1", lotId:"l2", lotNumero:"LOT-2025-006", chauffeur:"D. Martel",
      immatriculation:"EF-456-GH", destination:"Chaufferie Troyes Est",
      statut:"en_route", poidsT:42, heureDepart:"07:45",
      gpsLat:48.05, gpsLng:3.32, createdAt:"2025-06-09T07:45:00Z" },
    { id:"tr2", lotId:"l2", lotNumero:"LOT-2025-006", chauffeur:"M. Simon",
      immatriculation:"AB-789-CD", destination:"Chaufferie Troyes Est",
      statut:"en_route", poidsT:42, heureDepart:"09:15",
      gpsLat:48.12, gpsLng:3.45, createdAt:"2025-06-09T09:15:00Z" },
    { id:"tr3", lotId:"l3", lotNumero:"LOT-2025-005", chauffeur:"P. Leroy",
      immatriculation:"GH-321-IJ", destination:"Plateforme Sens Biomasse",
      statut:"arrive", poidsT:38.5,
      gpsLat:48.197, gpsLng:3.287, createdAt:"2025-06-08T14:00:00Z" },
    { id:"tr4", lotId:"l3", lotNumero:"LOT-2025-005", chauffeur:"K. Dupas",
      immatriculation:"KL-654-MN", destination:"Plateforme Sens Biomasse",
      statut:"arrive", poidsT:42,
      gpsLat:48.195, gpsLng:3.285, createdAt:"2025-06-08T16:00:00Z" },
  ],

  chaufferies: [
    { id:"ch1", nom:"Chaufferie Troyes Est", commune:"Troyes (10)",
      capaciteTan:5000, stockActuelT:320, humiditeMax:35,
      gpsLat:48.2900, gpsLng:4.0733 },
    { id:"ch2", nom:"Chaufferie Auxerre Centre", commune:"Auxerre (89)",
      capaciteTan:3000, stockActuelT:180, humiditeMax:35,
      gpsLat:47.7979, gpsLng:3.5714 },
  ],

  plateformes: [
    { id:"pl1", nom:"Plateforme Sens Biomasse", commune:"Sens (89)",
      capaciteT:8000, stockActuelT:2480, humiditeMoy:34,
      gpsLat:48.1967, gpsLng:3.2875 },
    { id:"pl2", nom:"Plateforme Auxerre Nord", commune:"Auxerre (89)",
      capaciteT:5000, stockActuelT:1100, humiditeMoy:33,
      gpsLat:47.810, gpsLng:3.555 },
  ],

  alertes: [
    { id:"a1", niveau:"critique", message:"LOT-2025-007 — Humidité 38% > seuil contractuel 35%",
      refType:"lot", refId:"l1", resolue:false, createdAt:"2025-06-10T06:00:00Z" },
    { id:"a2", niveau:"critique", message:"CMR-2025-0087 — GPS camion EF-456-GH non conforme (+7 km)",
      refType:"transport", refId:"tr1", resolue:false, createdAt:"2025-06-09T08:30:00Z" },
    { id:"a3", niveau:"warn", message:"LOT-2025-007 — Saisie opérateur manquante depuis 24h",
      refType:"lot", refId:"l1", resolue:false, createdAt:"2025-06-09T17:00:00Z" },
    { id:"a4", niveau:"warn", message:"LOT-2025-006 — BL-2025-0088 non signé depuis 48h",
      refType:"lot", refId:"l2", resolue:false, createdAt:"2025-06-08T10:00:00Z" },
    { id:"a5", niveau:"info", message:"Opportunité Charny 500t — Rappel de visite prévu vendredi",
      refType:"opportunite", refId:"o1", resolue:false, createdAt:"2025-06-10T08:00:00Z" },
  ],

  historique: [
    { id:"h1", refId:"l1", refType:"lot", action:"lot_cree",
      message:"LOT-2025-007 créé — Charny (89) · 350 t Peuplier", utilisateur:"J. Moreau", createdAt:"2025-01-15T08:00:00Z" },
    { id:"h2", refId:"l1", refType:"lot", action:"statut_change",
      message:"LOT-2025-007 → EN_EXPLOITATION (ETF Duclos Forêts)", utilisateur:"J. Moreau", createdAt:"2025-03-03T08:00:00Z" },
    { id:"h3", refId:"o1", refType:"opportunite", action:"opportunite_creee",
      message:"Nouvelle opportunité — Vasseur Alain · Charny · ~500 t", utilisateur:"J. Moreau", createdAt:"2025-06-01T08:30:00Z" },
    { id:"h4", refId:"tr1", refType:"transport", action:"transport_parti",
      message:"CMR-2025-0089 — D. Martel parti 07h45 · LOT-2025-006", utilisateur:"Système", createdAt:"2025-06-09T07:45:00Z" },
    { id:"h5", refId:"l2", refType:"lot", action:"statut_change",
      message:"LOT-2025-006 → EN_TRANSPORT", utilisateur:"J. Moreau", createdAt:"2025-06-09T07:00:00Z" },
    { id:"h6", refId:"a1", refType:"alerte", action:"alerte",
      message:"Alerte humidité — LOT-2025-007 · 38% > 35%", utilisateur:"Système", createdAt:"2025-06-10T06:00:00Z" },
  ],
});

// ── WORKFLOW GUARDS + UNIT TESTS ────────────────────────────────────────────────
/** @param {LotStatut} s @param {string} a @returns {{allowed:boolean,reason?:string}} */
const canDoLotAction = (s, a) => {
  const rules = {
    valider_visite:         ["A_VISITER","VISITE_REALISEE"],
    demarrer_exploitation:  ["VALIDE_EXPLOITATION"],
    ajouter_tas:            ["EN_EXPLOITATION","BORD_ROUTE"],
    planifier_dechiquetage: ["BORD_ROUTE"],
    creer_transport:        ["A_DECHIQUETER","DECHIQUETAGE_EN_COURS"],
    cloturer:               ["LIVRE","PARTIELLEMENT_LIVRE"],
  };
  const lbl = { A_VISITER:"À visiter",VISITE_REALISEE:"Visite réalisée",VALIDE_EXPLOITATION:"Validé",
    EN_EXPLOITATION:"En exploitation",BORD_ROUTE:"Bord de route",A_DECHIQUETER:"À déchiqueter",
    DECHIQUETAGE_EN_COURS:"Déchiquetage",EN_TRANSPORT:"En transport",
    PARTIELLEMENT_LIVRE:"Part. livré",LIVRE:"Livré",CLOTURE:"Clôturé",ANNULE:"Annulé" };
  const aLbl = { valider_visite:"Valider la visite",demarrer_exploitation:"Démarrer l'exploitation",
    ajouter_tas:"Ajouter un tas",planifier_dechiquetage:"Planifier le déchiquetage",
    creer_transport:"Créer un transport",cloturer:"Clôturer le lot" };
  if (!rules[a]) return { allowed:true };
  if (rules[a].includes(s)) return { allowed:true };
  return { allowed:false, reason:`"${aLbl[a]}" nécessite ${rules[a].map(x=>lbl[x]).join(" ou ")} — actuel : ${lbl[s]||s}` };
};

/** @param {OppStatut} s @param {string} a @returns {{allowed:boolean,reason?:string}} */
const canDoOppAction = (s, a) => {
  const rules = {
    planifier_visite:["nouvelle","a_visiter","a_rappeler"],
    creer_lot:       ["visite_programmee","visite_faite"],
    abandonner:      ["nouvelle","a_visiter","a_rappeler","visite_programmee","visite_faite"],
  };
  const aLbl = { planifier_visite:"Planifier une visite",creer_lot:"Créer un lot",abandonner:"Abandonner" };
  if (!rules[a]) return { allowed:true };
  if (rules[a].includes(s)) return { allowed:true };
  return { allowed:false, reason:`"${aLbl[a]}" non disponible pour le statut "${s}"` };
};

// Unit tests
const UNIT_TESTS = [
  [()=>canDoLotAction("EN_EXPLOITATION","valider_visite").allowed===false, "LOT EN_EXPLOITATION ≠ valider_visite"],
  [()=>canDoLotAction("VISITE_REALISEE","valider_visite").allowed===true,  "LOT VISITE_REALISEE → valider_visite ✓"],
  [()=>canDoLotAction("BORD_ROUTE","planifier_dechiquetage").allowed===true,"LOT BORD_ROUTE → planifier_dechiquetage ✓"],
  [()=>canDoLotAction("LIVRE","cloturer").allowed===true,                   "LOT LIVRE → cloturer ✓"],
  [()=>canDoLotAction("EN_EXPLOITATION","cloturer").allowed===false,        "LOT EN_EXPLOITATION ≠ cloturer"],
  [()=>canDoOppAction("nouvelle","planifier_visite").allowed===true,        "OPP nouvelle → planifier_visite ✓"],
  [()=>canDoOppAction("lot_cree","abandonner").allowed===false,             "OPP lot_cree ≠ abandonner"],
  [()=>canDoOppAction("visite_faite","creer_lot").allowed===true,           "OPP visite_faite → creer_lot ✓"],
  [()=>canDoOppAction("perdue","planifier_visite").allowed===false,         "OPP perdue ≠ planifier_visite"],
];
const TEST_RESULTS = UNIT_TESTS.map(([fn, name]) => {
  try { return { pass:fn(), name }; } catch(e) { return { pass:false, name, err:e }; }
});
const TESTS_PASSED = TEST_RESULTS.filter(r=>r.pass).length;
console.log(`[APPLITAG Tests] ${TESTS_PASSED}/${UNIT_TESTS.length} passed`);
TEST_RESULTS.forEach(r => console.log(`  ${r.pass?"✓":"✗"} ${r.name}`));

// ── DÉMO GUIDÉE — ÉTAPES ───────────────────────────────────────────────────────
/**
 * @typedef {Object} DemoStep
 * @property {number} step
 * @property {string} titre
 * @property {string} description
 * @property {string} action
 * @property {string} highlight
 * @property {string} screen
 * @property {string} emoji
 */

/** @type {DemoStep[]} */
const DEMO_STEPS = [
  { step:1,  emoji:"📊", titre:"Vue globale — Dashboard",
    description:"Le tableau de bord APPLITAG centralise tout : lots actifs, transports en cours, alertes, carte opérationnelle. C'est le poste de pilotage de l'exploitant.",
    action:"Explorer le dashboard", highlight:"kpis", screen:"dashboard" },
  { step:2,  emoji:"📞", titre:"Nouveau contact propriétaire",
    description:"Un propriétaire forestier appelle : Alain Vasseur, ~500 t de peuplier à Charny. On capture son contact en moins de 30 secondes avec nom, téléphone et type.",
    action:"Voir la fiche contact", highlight:"contact", screen:"contacts" },
  { step:3,  emoji:"💡", titre:"Transformation en opportunité",
    description:"Le contact devient une opportunité : commune, volume estimé, type de bois, urgence. Le pipeline commercial s'allonge. Le lot n'existe pas encore.",
    action:"Voir l'opportunité", highlight:"opportunite", screen:"opportunites" },
  { step:4,  emoji:"🔭", titre:"Visite terrain planifiée",
    description:"L'exploitant ou un technicien part en visite : GPS capturé, photos, essences identifiées, contraintes terrain, accès camion. La visite valide le volume et l'essence.",
    action:"Voir la visite", highlight:"visite", screen:"visite" },
  { step:5,  emoji:"🌲", titre:"Création du lot / chantier",
    description:"La visite validée déclenche la création du LOT-2025-007. Numéro automatique, statut À_VISITER puis VISITE_REALISEE. L'ETF est affecté, le chantier démarre.",
    action:"Voir le lot", highlight:"lot", screen:"lot" },
  { step:6,  emoji:"📦", titre:"Ajout des tas bord de route",
    description:"Les opérateurs saisissent leurs relevés quotidiens. Chaque tas est géolocalisé, pesé, photographié. Le volume réel se met à jour automatiquement.",
    action:"Voir les tas", highlight:"tas", screen:"tas" },
  { step:7,  emoji:"🪓", titre:"Planification du déchiquetage",
    description:"Lot passé en BORD_ROUTE. Le déchiqueteur est planifié, le CMR pré-rempli, l'immatriculation du camion enregistrée. GPS de départ horodaté.",
    action:"Voir le déchiquetage", highlight:"dechiquetage", screen:"dechiq" },
  { step:8,  emoji:"🚛", titre:"Transport en cours",
    description:"CMR signé, camion parti. Le chauffeur confirme depuis l'app mobile. GPS suivi en temps réel, alerte si déviation. Arrivée confirmée à la chaufferie.",
    action:"Voir le transport", highlight:"transport", screen:"transport" },
  { step:9,  emoji:"🏭", titre:"Livraison et pesée",
    description:"Réception à la Chaufferie Troyes Est. Pesée bascule : 42 t. Humidité : 32% < seuil 35%. BL généré automatiquement et signé. Lot → PARTIELLEMENT_LIVRÉ.",
    action:"Voir la livraison", highlight:"livraison", screen:"livraison" },
  { step:10, emoji:"🔒", titre:"Clôture du lot",
    description:"5 conditions vérifiées automatiquement : tous tas déchiquetés, tous transports livrés, toutes pesées saisies, CMR + BL signés, aucun litige ouvert. Lot → CLÔTURÉ.",
    action:"Retour dashboard", highlight:"cloture", screen:"dashboard" },
];

// ── TOKENS ─────────────────────────────────────────────────────────────────────
const T = {
  green:"#1D9E75", greenL:"#E1F5EE", greenD:"#085041",
  purple:"#534AB7", purpleL:"#EEEDFE", purpleD:"#26215C",
  coral:"#D85A30", coralL:"#FAECE7", coralD:"#4A1B0C",
  blue:"#185FA5", blueL:"#E6F1FB", blueD:"#042C53",
  amber:"#BA7517", amberL:"#FAEEDA", amberD:"#412402",
  red:"#A32D2D", redL:"#FCEBEB",
  bg:"#F5F4F1", bg2:"#ECEAE6",
  bd:"#DDDBD5", bd2:"#C8C5BE",
  tx:"#1A1A18", tx2:"#5A5955", tx3:"#9A9892",
  sb:"#111", sbBd:"#222", sbHov:"#1E1E1E",
};

// ── HELPERS ─────────────────────────────────────────────────────────────────────
const uid = () => Math.random().toString(36).slice(2,9);
const nowISO = () => new Date().toISOString();
const fmt = (d) => d ? new Date(d).toLocaleDateString("fr-FR",{day:"2-digit",month:"short"}) : "—";

/** @param {LotStatut} s */
const lotBadge = (s) => ({
  BROUILLON:           {bg:"#F0EEE9",color:"#555",   label:"Brouillon"},
  A_VISITER:           {bg:T.amberL, color:T.amberD, label:"À visiter"},
  VISITE_REALISEE:     {bg:T.amberL, color:T.amberD, label:"Visité"},
  VALIDE_EXPLOITATION: {bg:T.greenL, color:T.greenD, label:"Validé"},
  EN_EXPLOITATION:     {bg:T.blueL,  color:T.blueD,  label:"En exploitation"},
  BORD_ROUTE:          {bg:"#F1EFE8",color:"#5C4A1E", label:"Bord de route"},
  A_DECHIQUETER:       {bg:T.purpleL,color:T.purpleD, label:"À déchiqueter"},
  DECHIQUETAGE_EN_COURS:{bg:T.purpleL,color:T.purpleD,label:"Déchiquetage"},
  EN_TRANSPORT:        {bg:T.purpleL,color:T.purpleD, label:"En transport"},
  PARTIELLEMENT_LIVRE: {bg:T.amberL, color:T.amberD, label:"Part. livré"},
  LIVRE:               {bg:T.greenL, color:T.greenD,  label:"Livré ✓"},
  CLOTURE:             {bg:T.greenL, color:T.greenD,  label:"Clôturé ✓"},
  ANNULE:              {bg:T.redL,   color:T.red,     label:"Annulé"},
}[s] ?? {bg:T.bg2,color:T.tx2,label:s});

/** @param {OppStatut} s */
const oppBadge = (s) => ({
  nouvelle:          {bg:T.bg2,    color:T.tx2,    label:"Nouvelle"},
  a_visiter:         {bg:T.amberL, color:T.amberD, label:"À visiter"},
  visite_programmee: {bg:T.blueL,  color:T.blueD,  label:"Visite prog."},
  visite_faite:      {bg:T.purpleL,color:T.purpleD,label:"Visite faite"},
  lot_cree:          {bg:T.greenL, color:T.greenD, label:"Lot créé ✓"},
  perdue:            {bg:T.redL,   color:T.red,    label:"Perdue"},
}[s] ?? {bg:T.bg2,color:T.tx2,label:s});

// ── ATOMS ──────────────────────────────────────────────────────────────────────
const Badge = ({bg,color,children}) => (
  <span style={{display:"inline-block",padding:"2px 8px",borderRadius:9,
    fontSize:10,fontWeight:600,background:bg,color,whiteSpace:"nowrap"}}>{children}</span>
);

const Btn = ({onClick,bg=T.bg2,color=T.tx,children,disabled,sm,style={}}) => (
  <button onClick={disabled?undefined:onClick} style={{
    padding:sm?"5px 10px":"8px 14px",borderRadius:8,
    fontSize:sm?11:12,fontWeight:500,display:"inline-flex",alignItems:"center",gap:6,
    cursor:disabled?"not-allowed":"pointer",border:"none",fontFamily:"inherit",
    background:disabled?T.bg2:bg,color:disabled?T.tx3:color,
    opacity:disabled?0.65:1,transition:"all .1s",whiteSpace:"nowrap",...style,
  }}>{children}</button>
);

const PBtn = ({onClick,children,disabled,style={}}) => (
  <Btn onClick={onClick} bg={T.green} color="#fff" disabled={disabled} style={style}>{children}</Btn>
);

const Card = ({children,style={}}) => (
  <div style={{background:"#fff",border:`1px solid ${T.bd}`,borderRadius:12,...style}}>
    {children}
  </div>
);

const SCard = ({title,extra,children,highlighted}) => (
  <Card style={{overflow:"hidden",outline:highlighted?`2px solid ${T.amber}`:"none",
    outlineOffset:2}}>
    <div style={{padding:"9px 13px",borderBottom:`1px solid ${T.bd}`,
      background:T.bg,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
      <div style={{fontSize:11,fontWeight:600,color:T.tx2,textTransform:"uppercase",
        letterSpacing:".05em"}}>{title}</div>
      {extra}
    </div>
    <div style={{padding:"10px 13px"}}>{children}</div>
  </Card>
);

const Row = ({k,v,vc,border=true}) => (
  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",
    padding:"5px 0",borderBottom:border?`0.5px solid ${T.bd}`:"none",fontSize:12}}>
    <span style={{color:T.tx2}}>{k}</span>
    <span style={{fontWeight:600,color:vc??T.tx}}>{v}</span>
  </div>
);

// Toast
const useToasts = () => {
  const [toasts,setToasts] = useState([]);
  const add = useCallback((type,msg) => {
    const id = uid();
    setToasts(t=>[...t,{id,type,msg}]);
    setTimeout(()=>setToasts(t=>t.filter(x=>x.id!==id)),3500);
  },[]);
  return [toasts, add];
};

const Toasts = ({toasts}) => (
  <div style={{position:"fixed",top:16,right:16,zIndex:9999,
    display:"flex",flexDirection:"column",gap:7,pointerEvents:"none"}}>
    {toasts.map(t=>(
      <div key={t.id} style={{
        padding:"10px 16px",borderRadius:10,fontSize:12,fontWeight:500,
        background:t.type==="success"?T.greenD:t.type==="error"?T.red:T.amberD,
        color:"#fff",boxShadow:"0 4px 16px rgba(0,0,0,.2)",
        animation:"slideIn .2s ease",display:"flex",gap:8,alignItems:"center",
      }}>
        {t.type==="success"?"✓":t.type==="error"?"✗":"⚠"} {t.msg}
      </div>
    ))}
  </div>
);

// Confirm modal
const ConfirmModal = ({msg,onConfirm,onCancel}) => (
  <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.45)",
    display:"flex",alignItems:"center",justifyContent:"center",zIndex:9998}}>
    <div style={{background:"#fff",borderRadius:14,padding:"22px 26px",maxWidth:400,
      boxShadow:"0 8px 40px rgba(0,0,0,.25)"}}>
      <div style={{fontSize:15,fontWeight:600,marginBottom:8}}>Confirmation requise</div>
      <div style={{fontSize:13,color:T.tx2,marginBottom:20,lineHeight:1.6}}>{msg}</div>
      <div style={{display:"flex",gap:9,justifyContent:"flex-end"}}>
        <Btn onClick={onCancel}>Annuler</Btn>
        <Btn onClick={onConfirm} bg={T.red} color="#fff">Confirmer</Btn>
      </div>
    </div>
  </div>
);

// Blocked action
const BlockedBtn = ({reason,children}) => (
  <div style={{position:"relative",display:"inline-flex"}} title={reason}>
    <Btn disabled>{children}</Btn>
    <span style={{position:"absolute",top:-6,right:-6,width:16,height:16,
      borderRadius:"50%",background:T.amber,color:"#fff",fontSize:9,
      display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700}}>!</span>
  </div>
);

// ── TIMELINE LOT ───────────────────────────────────────────────────────────────
const LotTimeline = ({statut}) => {
  const steps = [
    {s:"BROUILLON",l:"Créé"},{s:"VISITE_REALISEE",l:"Visité"},
    {s:"VALIDE_EXPLOITATION",l:"Validé"},{s:"EN_EXPLOITATION",l:"Exploit."},
    {s:"BORD_ROUTE",l:"Bord route"},{s:"EN_TRANSPORT",l:"Transport"},
    {s:"LIVRE",l:"Livré"},{s:"CLOTURE",l:"Clôturé"},
  ];
  const ci = steps.findIndex(x=>x.s===statut);
  return (
    <div style={{display:"flex",alignItems:"center",gap:0,overflowX:"auto",padding:"4px 0"}}>
      {steps.map((x,i)=>{
        const done=i<ci, active=i===ci;
        return (
          <div key={x.s} style={{display:"flex",alignItems:"center",flexShrink:0}}>
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
              <div style={{width:18,height:18,borderRadius:"50%",
                background:done?T.green:active?T.amber:T.bg2,
                border:`1.5px solid ${done?T.green:active?T.amber:T.bd2}`,
                display:"flex",alignItems:"center",justifyContent:"center",
                fontSize:9,color:done?"#fff":active?T.amberD:T.tx3}}>
                {done?"✓":i+1}
              </div>
              <span style={{fontSize:8,color:done?T.greenD:active?T.amberD:T.tx3,
                fontWeight:active?700:400,whiteSpace:"nowrap"}}>{x.l}</span>
            </div>
            {i<steps.length-1&&<div style={{width:20,height:2,background:done?T.green:T.bg2,
              margin:"0 2px",marginBottom:14,flexShrink:0}}/>}
          </div>
        );
      })}
    </div>
  );
};

// ── SVG MAP ────────────────────────────────────────────────────────────────────
const ApplitagMap = ({lots,transports,opportunites,chaufferies,plateformes,filters,onMarkerClick,highlightType}) => {
  const [hov,setHov] = useState(null);
  const toXY = (lat,lng) => ({
    x:((lng-2.7)/1.8)*540+30,
    y:((48.55-lat)/0.95)*320+20
  });
  const markers = [];
  if(filters.includes("lots")) lots.forEach(l=>{
    const p=toXY(l.gpsLat,l.gpsLng); const b=lotBadge(l.statut);
    markers.push({...p,id:l.id,type:"lot",label:l.numeroLot,
      icon:l.statut==="EN_EXPLOITATION"?"⛏":l.statut==="EN_TRANSPORT"?"🚛":"🌲",
      bg:b.bg,stroke:b.color,data:l});
  });
  if(filters.includes("opportunites")) opportunites.forEach(o=>{
    const p=toXY(o.gpsLat??47.9,o.gpsLng??3.1);
    markers.push({...p,id:o.id,type:"opportunite",label:o.commune??"Opp.",
      icon:"💡",bg:T.amberL,stroke:T.amberD,data:o});
  });
  if(filters.includes("transports")) transports.filter(t=>t.statut==="en_route").forEach(t=>{
    const p=toXY(t.gpsLat,t.gpsLng);
    markers.push({...p,id:t.id,type:"transport",label:t.chauffeur,
      icon:"🚛",bg:T.purpleL,stroke:T.purpleD,data:t});
  });
  if(filters.includes("chaufferies")) chaufferies.forEach(c=>{
    const p=toXY(c.gpsLat,c.gpsLng);
    markers.push({...p,id:c.id,type:"chaufferie",label:c.nom.split(" ")[1]||c.nom,
      icon:"🏭",bg:T.blueL,stroke:T.blueD,data:c});
  });
  if(filters.includes("plateformes")) plateformes.forEach(pl=>{
    const p=toXY(pl.gpsLat,pl.gpsLng);
    markers.push({...p,id:pl.id,type:"plateforme",label:pl.nom.split(" ")[1]||pl.nom,
      icon:"🏗️",bg:T.purpleL,stroke:T.purpleD,data:pl});
  });

  return (
    <svg viewBox="0 0 600 360" style={{width:"100%",height:"100%",
      background:"linear-gradient(155deg,#E8F4EC,#D4EAD9 55%,#C6E2CF)"}}>
      {[.25,.5,.75].map(f=>(
        <g key={f}>
          <line x1={f*600} y1={0} x2={f*600} y2={360} stroke="rgba(255,255,255,.3)" strokeWidth="1" strokeDasharray="4,3"/>
          <line x1={0} y1={f*360} x2={600} y2={f*360} stroke="rgba(255,255,255,.3)" strokeWidth="1" strokeDasharray="4,3"/>
        </g>
      ))}
      {/* Transport paths */}
      {filters.includes("transports") && transports.filter(t=>t.statut==="en_route").map(t=>{
        const dest = chaufferies.find(c=>t.destination.includes(c.nom.split(" ")[1]||"---"))
          || plateformes.find(p=>t.destination.includes(p.nom.split(" ")[1]||"---"));
        if(!dest) return null;
        const from=toXY(t.gpsLat,t.gpsLng), to=toXY(dest.gpsLat,dest.gpsLng);
        return (
          <line key={t.id} x1={from.x} y1={from.y} x2={to.x} y2={to.y}
            stroke={T.purple} strokeWidth="1.5" strokeDasharray="6,3" opacity=".5"/>
        );
      })}
      {markers.map(m=>{
        const isHov=hov===m.id;
        const isHL=highlightType&&highlightType===m.type;
        return (
          <g key={m.id} style={{cursor:"pointer"}}
            onMouseEnter={()=>setHov(m.id)} onMouseLeave={()=>setHov(null)}
            onClick={()=>onMarkerClick(m.type,m.data)}>
            {(isHov||isHL)&&<circle cx={m.x} cy={m.y} r={20} fill={m.bg} opacity=".4"/>}
            <circle cx={m.x} cy={m.y+2} r={13} fill="rgba(0,0,0,.08)"/>
            <circle cx={m.x} cy={m.y} r={isHov||isHL?14:11}
              fill={m.bg} stroke={m.stroke} strokeWidth={isHov||isHL?2:1.5}/>
            <text x={m.x} y={m.y+5} textAnchor="middle" fontSize={isHov||isHL?14:11}>{m.icon}</text>
            {(isHov||isHL)&&(
              <g>
                <rect x={m.x-38} y={m.y-32} width={76} height={18} rx={4} fill="rgba(0,0,0,.78)"/>
                <text x={m.x} y={m.y-20} textAnchor="middle" fontSize={9} fill="#fff" fontWeight="600">{m.label}</text>
              </g>
            )}
          </g>
        );
      })}
      <rect x={6} y={6} width={82} height={markers.length*13+8} rx={5} fill="rgba(255,255,255,.88)"/>
      {[...new Set(markers.map(m=>m.type))].map((type,i)=>{
        const icons={lot:"🌲",opportunite:"💡",transport:"🚛",chaufferie:"🏭",plateforme:"🏗️"};
        const lbls={lot:"Lots",opportunite:"Opportunités",transport:"Camions",chaufferie:"Chaufferies",plateforme:"Plateformes"};
        return (
          <g key={type}>
            <text x={12} y={20+i*13} fontSize={10}>{icons[type]}</text>
            <text x={26} y={20+i*13} fontSize={9} fill={T.tx2}>{lbls[type]}</text>
          </g>
        );
      })}
    </svg>
  );
};

// ── DÉMO GUIDÉE OVERLAY ────────────────────────────────────────────────────────
const DemoOverlay = ({step, total, stepData, onNext, onPrev, onQuit}) => {
  const progress = (step/total)*100;
  return (
    <div style={{position:"fixed",bottom:24,left:"50%",transform:"translateX(-50%)",
      zIndex:9000,width:560,maxWidth:"calc(100vw - 32px)"}}>
      {/* Barre de progression flottante */}
      <div style={{background:"rgba(17,17,17,.96)",borderRadius:16,
        padding:"16px 20px",boxShadow:"0 8px 40px rgba(0,0,0,.4)",
        backdropFilter:"blur(8px)"}}>
        {/* Header */}
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
          <div style={{width:36,height:36,borderRadius:10,background:T.green,
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>
            {stepData.emoji}
          </div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{color:"#fff",fontWeight:600,fontSize:14,marginBottom:2}}>
              Étape {step}/{total} — {stepData.titre}
            </div>
            <div style={{height:3,background:"rgba(255,255,255,.15)",borderRadius:2}}>
              <div style={{height:"100%",width:`${progress}%`,background:T.green,
                borderRadius:2,transition:"width .4s ease"}}/>
            </div>
          </div>
          <button onClick={onQuit} style={{background:"rgba(255,255,255,.1)",
            border:"none",cursor:"pointer",color:"rgba(255,255,255,.7)",
            fontSize:13,padding:"4px 9px",borderRadius:7,fontFamily:"inherit"}}>
            Quitter
          </button>
        </div>

        {/* Description */}
        <div style={{color:"rgba(255,255,255,.85)",fontSize:12,lineHeight:1.7,
          marginBottom:14,padding:"10px 12px",background:"rgba(255,255,255,.06)",
          borderRadius:9}}>
          {stepData.description}
        </div>

        {/* Actions */}
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          {step > 1 && (
            <Btn onClick={onPrev} bg="rgba(255,255,255,.1)" color="#ccc"
              style={{border:"1px solid rgba(255,255,255,.15)"}}>
              ‹ Précédent
            </Btn>
          )}
          {/* Step dots */}
          <div style={{flex:1,display:"flex",gap:5,justifyContent:"center"}}>
            {Array.from({length:total}).map((_,i)=>(
              <div key={i} style={{width:i===step-1?18:6,height:6,borderRadius:3,
                background:i<step?T.green:i===step-1?T.amber:"rgba(255,255,255,.2)",
                transition:"all .3s"}}/>
            ))}
          </div>
          <PBtn onClick={onNext}
            style={{padding:"8px 18px",fontSize:13}}>
            {step===total?"Terminer la démo":"Suivant →"}
          </PBtn>
        </div>
      </div>
    </div>
  );
};

// ── PERSISTANCE PANEL ──────────────────────────────────────────────────────────
const PersistancePanel = ({store, onReset}) => {
  const [tab,setTab] = useState("schema");
  const TABS = [["schema","Schéma Prisma"],["api","API CRUD"],["migration","Migration"],["status","Statut"]];
  return (
    <div style={{flex:1,overflowY:"auto",padding:"16px 20px"}}>
      <div style={{marginBottom:16,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:16,fontWeight:600}}>Persistance — PostgreSQL</div>
          <div style={{fontSize:11,color:T.tx3}}>Schéma Prisma · Migration · API CRUD</div>
        </div>
        <Btn onClick={onReset} bg={T.amberL} color={T.amberD}>↺ Réinitialiser données démo</Btn>
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:0,borderBottom:`1px solid ${T.bd}`,marginBottom:16}}>
        {TABS.map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} style={{
            padding:"8px 16px",fontSize:12,fontWeight:500,border:"none",cursor:"pointer",
            fontFamily:"inherit",background:"none",color:tab===id?T.green:T.tx3,
            borderBottom:`2px solid ${tab===id?T.green:"transparent"}`,
          }}>{label}</button>
        ))}
      </div>

      {tab==="status" && (
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:16}}>
          {[
            ["Contacts",store.contacts.length,T.green,"👤"],
            ["Opportunités",store.opportunites.length,T.purple,"💡"],
            ["Lots",store.lots.length,T.blue,"🌲"],
            ["Transports",store.transports.length,T.amber,"🚛"],
            ["Chaufferies",store.chaufferies.length,T.coral,"🏭"],
            ["Plateformes",store.plateformes.length,T.purple,"🏗️"],
            ["Alertes",store.alertes.length,T.red,"🔔"],
            ["Historique",store.historique.length,T.tx2,"📋"],
          ].map(([l,n,c,ic])=>(
            <div key={l} style={{background:"#fff",border:`1px solid ${T.bd}`,
              borderRadius:10,padding:"12px 14px",textAlign:"center"}}>
              <div style={{fontSize:20}}>{ic}</div>
              <div style={{fontSize:20,fontWeight:700,color:c,margin:"4px 0"}}>{n}</div>
              <div style={{fontSize:10,color:T.tx3}}>{l}</div>
            </div>
          ))}
        </div>
      )}

      {tab==="status" && (
        <SCard title="Tests unitaires workflow">
          {TEST_RESULTS.map((r,i)=>(
            <div key={i} style={{display:"flex",gap:8,alignItems:"center",padding:"4px 0",
              borderBottom:i<TEST_RESULTS.length-1?`0.5px solid ${T.bd}`:"none",fontSize:12}}>
              <span style={{color:r.pass?T.green:T.red,fontSize:14,fontWeight:700}}>
                {r.pass?"✓":"✗"}
              </span>
              <span style={{color:r.pass?T.tx:T.red}}>{r.name}</span>
            </div>
          ))}
          <div style={{marginTop:10,padding:"8px 10px",background:TESTS_PASSED===UNIT_TESTS.length?T.greenL:T.redL,
            borderRadius:8,fontSize:12,fontWeight:600,
            color:TESTS_PASSED===UNIT_TESTS.length?T.greenD:T.red}}>
            {TESTS_PASSED}/{UNIT_TESTS.length} tests passés
          </div>
        </SCard>
      )}

      {tab==="schema" && (
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {[
            {model:"User",fields:[["id","String @id @default(cuid())"],["nom","String"],["prenom","String?"],["email","String @unique"],["role","UserRole"],["entrepriseId","String @db.Uuid"],["createdAt","DateTime @default(now())"]]},
            {model:"Contact",fields:[["id","String @id @default(cuid())"],["nom","String"],["telephone","String"],["typeContact","ContactType"],["statut","ContactStatut @default(nouveau)"],["origine","ContactOrigine?"],["commentaire","String?"],["rappelPrevu","DateTime?"],["gpsLat","Float?"],["gpsLng","Float?"],["createurId","String"],["createdAt","DateTime @default(now())"],["opportunites","Opportunite[]"],["lots","Lot[]"]]},
            {model:"Opportunite",fields:[["id","String @id @default(cuid())"],["contactId","String"],["commune","String?"],["volumeEstime","Decimal?"],["typeBois","LotType?"],["urgence","Urgence @default(normale)"],["statut","OppStatut @default(nouvelle)"],["notes","String?"],["lotId","String?"],["gpsLat","Float?"],["gpsLng","Float?"],["createdAt","DateTime @default(now())"]]},
            {model:"Lot",fields:[["id","String @id @default(cuid())"],["numeroLot","String @unique"],["statut","LotStatut @default(BROUILLON)"],["commune","String"],["essencePrincipale","String?"],["volumeEstime","Decimal?"],["volumeReel","Decimal?"],["surfaceHa","Decimal?"],["humidite","Decimal?"],["gpsLat","Float"],["gpsLng","Float"],["certification","String?"],["etfNom","String?"],["contactId","String?"],["opportuniteId","String?"],["tas","Tas[]"],["transports","Transport[]"],["livraisons","Livraison[]"],["alertes","Alerte[]"],["historiques","Historique[]"],["createdAt","DateTime @default(now())"]]},
            {model:"Tas",fields:[["id","String @id @default(cuid())"],["lotId","String"],["numeroTas","String"],["volumeEstime","Decimal"],["essence","String"],["statut","TasStatut @default(en_cours)"],["gpsLat","Float"],["gpsLng","Float"],["createdAt","DateTime @default(now())"]]},
            {model:"Transport",fields:[["id","String @id @default(cuid())"],["lotId","String"],["chauffeur","String"],["immatriculation","String"],["destination","String"],["statut","TransportStatut @default(prepare)"],["poidsT","Decimal?"],["heureDepart","DateTime?"],["gpsLat","Float?"],["gpsLng","Float?"],["createdAt","DateTime @default(now())"]]},
          ].map(({model,fields})=>(
            <SCard key={model} title={`model ${model}`}>
              <div style={{fontFamily:"monospace",fontSize:11,lineHeight:1.8}}>
                {fields.map(([f,t])=>(
                  <div key={f} style={{display:"flex",gap:16,padding:"1px 0",
                    borderBottom:`0.5px solid ${T.bd}`}}>
                    <span style={{color:T.blue,minWidth:140}}>{f}</span>
                    <span style={{color:T.green}}>{t}</span>
                  </div>
                ))}
              </div>
            </SCard>
          ))}
        </div>
      )}

      {tab==="api" && (
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {[
            {resource:"Contacts",routes:[
              ["POST",  "/api/v1/contacts","Créer un contact"],
              ["GET",   "/api/v1/contacts","Liste + filtres (type, statut, search)"],
              ["GET",   "/api/v1/contacts/:id","Fiche contact + opportunités liées"],
              ["PATCH", "/api/v1/contacts/:id","Modifier contact"],
              ["PATCH", "/api/v1/contacts/:id/statut","Changer le statut"],
            ]},
            {resource:"Opportunités",routes:[
              ["POST",  "/api/v1/opportunites","Créer depuis un contact"],
              ["GET",   "/api/v1/opportunites","Pipeline complet"],
              ["PATCH", "/api/v1/opportunites/:id/statut","Avancer le statut"],
              ["POST",  "/api/v1/opportunites/:id/creer-lot","Convertir en lot"],
            ]},
            {resource:"Lots",routes:[
              ["POST",  "/api/v1/lots","Créer un lot"],
              ["GET",   "/api/v1/lots","Liste + filtres statut/commune/ETF"],
              ["GET",   "/api/v1/lots/:id","Fiche complète avec tas/transports/livraisons"],
              ["PATCH", "/api/v1/lots/:id/statut","Changer statut (garde-fous)"],
              ["GET",   "/api/v1/lots/:id/cloture-status","Vérifier conditions clôture"],
            ]},
            {resource:"Tas",routes:[
              ["POST",  "/api/v1/lots/:lotId/tas","Créer un tas"],
              ["PATCH", "/api/v1/tas/:id/completer","Marquer complet → pret"],
            ]},
            {resource:"Transports",routes:[
              ["POST",  "/api/v1/lots/:lotId/transports","Créer un transport"],
              ["PATCH", "/api/v1/transports/:id/valider-depart","GPS + heure départ"],
              ["PATCH", "/api/v1/transports/:id/valider-arrivee","Confirmer arrivée"],
            ]},
            {resource:"Alertes",routes:[
              ["GET",   "/api/v1/alertes","Toutes (filtres niveau, statut)"],
              ["PATCH", "/api/v1/alertes/:id/resoudre","Résoudre une alerte"],
            ]},
          ].map(({resource,routes})=>(
            <SCard key={resource} title={resource}>
              {routes.map(([method,path,desc])=>(
                <div key={path} style={{display:"flex",gap:10,padding:"5px 0",
                  borderBottom:`0.5px solid ${T.bd}`,fontSize:11,alignItems:"flex-start"}}>
                  <span style={{
                    padding:"1px 7px",borderRadius:5,fontWeight:700,fontSize:9,
                    minWidth:44,textAlign:"center",flexShrink:0,
                    background:method==="GET"?T.blueL:method==="POST"?T.greenL:T.amberL,
                    color:method==="GET"?T.blueD:method==="POST"?T.greenD:T.amberD,
                  }}>{method}</span>
                  <span style={{fontFamily:"monospace",color:T.blue,minWidth:240}}>{path}</span>
                  <span style={{color:T.tx2}}>{desc}</span>
                </div>
              ))}
            </SCard>
          ))}
        </div>
      )}

      {tab==="migration" && (
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <SCard title="Commandes de démarrage">
            <div style={{fontFamily:"monospace",fontSize:11,lineHeight:2,
              background:T.bg2,padding:"12px",borderRadius:8}}>
              {[
                "# 1. Initialiser la migration",
                "npx prisma migrate dev --name init",
                "",
                "# 2. Générer le client Prisma",
                "npx prisma generate",
                "",
                "# 3. Charger les données démo",
                "npx prisma db seed",
                "",
                "# 4. Ouvrir Prisma Studio",
                "npx prisma studio",
                "",
                "# 5. Lancer l'API NestJS",
                "npm run start:dev",
              ].map((l,i)=>(
                <div key={i} style={{color:l.startsWith("#")?T.tx3:l===""?"transparent":T.green}}>
                  {l||<>&nbsp;</>}
                </div>
              ))}
            </div>
          </SCard>
          <SCard title="seed.ts — extrait">
            <div style={{fontFamily:"monospace",fontSize:11,lineHeight:1.7,
              background:T.bg2,padding:"12px",borderRadius:8,overflowX:"auto"}}>
              {`import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  // Contacts
  await prisma.contact.createMany({
    data: DEMO_CONTACTS.map(c => ({
      nom: c.nom, telephone: c.telephone,
      typeContact: c.typeContact, statut: c.statut,
      commentaire: c.commentaire,
    })),
  });

  // Lots avec tas
  for (const lot of DEMO_LOTS) {
    await prisma.lot.create({
      data: {
        numeroLot: lot.numeroLot, statut: lot.statut,
        commune: lot.commune, gpsLat: lot.gpsLat, gpsLng: lot.gpsLng,
        tas: { create: lot.tas },
      },
    });
  }
  console.log('✓ Données démo chargées');
}
main().catch(console.error)
  .finally(() => prisma.$disconnect());`.split("\n").map((l,i)=>(
                <div key={i} style={{color:l.includes("async")||l.includes("await")||l.includes("const")||l.includes("import")
                  ?T.blue:l.includes("//")
                  ?T.tx3:T.tx}}>{l||<>&nbsp;</>}</div>
              ))}
            </div>
          </SCard>
          <SCard title="Variables d'environnement (.env)">
            <div style={{fontFamily:"monospace",fontSize:11,lineHeight:2,
              background:T.bg2,padding:"12px",borderRadius:8}}>
              {[
                `DATABASE_URL="postgresql://user:password@localhost:5432/applitag"`,
                `JWT_SECRET="your-super-secret-key-min-32-chars"`,
                `JWT_EXPIRY="24h"`,
                `S3_BUCKET="applitag-docs"`,
                `S3_REGION="eu-west-3"`,
                `PORT=3000`,
              ].map((l,i)=>(
                <div key={i} style={{color:T.green}}>{l}</div>
              ))}
            </div>
          </SCard>
        </div>
      )}
    </div>
  );
};

// ── SIDEBAR ─────────────────────────────────────────────────────────────────────
const MENU = [
  {id:"dashboard",icon:"📊",label:"Dashboard"},
  {id:"lots",icon:"🌲",label:"Lots"},
  {id:"opportunites",icon:"💡",label:"Opportunités"},
  {id:"contacts",icon:"👥",label:"Contacts"},
  {id:"transports",icon:"🚛",label:"Transports"},
  {id:"alertes",icon:"🔔",label:"Alertes"},
  {id:"persistance",icon:"🗄️",label:"Persistance"},
  {id:"demo",icon:"🎬",label:"Mode démo"},
];

const Sidebar = ({active,onNav,alertCount}) => (
  <div style={{width:188,minWidth:188,background:T.sb,display:"flex",
    flexDirection:"column",height:"100vh",position:"sticky",top:0,flexShrink:0}}>
    <div style={{padding:"15px 13px 10px",borderBottom:`1px solid ${T.sbBd}`,
      display:"flex",alignItems:"center",gap:9}}>
      <div style={{width:28,height:28,background:T.green,borderRadius:8,
        display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}>🌲</div>
      <div>
        <div style={{fontSize:13,fontWeight:700,color:"#fff",letterSpacing:".02em"}}>APPLITAG</div>
        <div style={{fontSize:9,color:"#555",textTransform:"uppercase",letterSpacing:".04em"}}>Bois Énergie</div>
      </div>
    </div>
    <div style={{flex:1,overflowY:"auto",padding:"7px 5px"}}>
      {MENU.map(m=>(
        <button key={m.id} onClick={()=>onNav(m.id)} style={{
          width:"100%",padding:"8px 9px",borderRadius:7,display:"flex",
          alignItems:"center",gap:8,cursor:"pointer",border:"none",fontFamily:"inherit",
          background:active===m.id?T.green:T.sb,
          color:active===m.id?"#fff":"#999",
          fontSize:12,fontWeight:active===m.id?600:400,marginBottom:1,textAlign:"left",
          position:"relative",transition:"all .1s",
        }}>
          <span style={{fontSize:14,opacity:active===m.id?1:0.55}}>{m.icon}</span>
          {m.label}
          {m.id==="alertes"&&alertCount>0&&(
            <span style={{marginLeft:"auto",background:T.red,color:"#fff",
              fontSize:9,fontWeight:700,padding:"1px 5px",borderRadius:7}}>{alertCount}</span>
          )}
          {m.id==="demo"&&(
            <span style={{marginLeft:"auto",background:T.amber,color:"#fff",
              fontSize:8,fontWeight:700,padding:"1px 5px",borderRadius:5}}>DÉMO</span>
          )}
        </button>
      ))}
    </div>
    <div style={{padding:"10px 11px",borderTop:`1px solid ${T.sbBd}`,
      display:"flex",alignItems:"center",gap:8}}>
      <div style={{width:26,height:26,borderRadius:"50%",background:T.green,
        display:"flex",alignItems:"center",justifyContent:"center",
        fontSize:10,fontWeight:700,color:"#fff"}}>JM</div>
      <div>
        <div style={{fontSize:11,fontWeight:600,color:"#ddd"}}>J. Moreau</div>
        <div style={{fontSize:9,color:"#666"}}>Exploitant</div>
      </div>
    </div>
  </div>
);

// ── DASHBOARD PAGE ──────────────────────────────────────────────────────────────
const DashboardPage = ({store, onOpenFiche, onNav, demoHighlight}) => {
  const [filters,setFilters] = useState(["lots","transports","chaufferies","plateformes","opportunites"]);
  const {lots,transports,opportunites,chaufferies,plateformes,alertes,historique} = store;
  const openAlerts = alertes.filter(a=>!a.resolue);
  const toggle = (f)=>setFilters(p=>p.includes(f)?p.filter(x=>x!==f):[...p,f]);
  const FILTER_OPTS = [
    ["lots","🌲 Lots"],["opportunites","💡 Opport."],["transports","🚛 Transports"],
    ["chaufferies","🏭 Chaufferies"],["plateformes","🏗️ Plateformes"],
  ];
  const tonnes7j = lots.flatMap(l=>l.livraisons??[]).filter(l=>l?.statut==="valide").reduce((s,l)=>s+l.poids,0);
  const humMoy = lots.filter(l=>l.humidite).length
    ? lots.filter(l=>l.humidite).reduce((s,l)=>s+l.humidite,0)/lots.filter(l=>l.humidite).length : 0;

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",overflowY:"auto"}}>
      {/* KPIs */}
      <div style={{padding:"14px 18px 0",display:"grid",
        gridTemplateColumns:"repeat(5,1fr)",gap:9}}
        id="kpis" style={{padding:"14px 18px 0",
          display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:9,
          outline:demoHighlight==="kpis"?`2px solid ${T.amber}`:"none",
          outlineOffset:4,borderRadius:12}}>
        {[
          {l:"En exploitation",v:lots.filter(l=>l.statut==="EN_EXPLOITATION").length,s:"Chantiers actifs",c:T.blue,i:"⛏",nav:"lots"},
          {l:"Tonnes livrées 7j",v:`${tonnes7j} t`,s:"Livraisons validées",c:T.green,i:"📦",nav:"lots"},
          {l:"Humidité moyenne",v:`${humMoy.toFixed(1)} %`,s:humMoy>35?"⚠ Seuil 35%":"✓ Conforme",c:humMoy>35?T.red:T.green,i:"💧",nav:null},
          {l:"Transports actifs",v:transports.filter(t=>t.statut==="en_route").length,s:"CMR en cours",c:T.purple,i:"🚛",nav:"transports"},
          {l:"Alertes critiques",v:openAlerts.filter(a=>a.niveau==="critique").length,s:`${openAlerts.length} total`,c:openAlerts.length?T.red:T.green,i:"🔔",nav:"alertes"},
        ].map(({l,v,s,c,i,nav})=>(
          <div key={l} onClick={()=>nav&&onNav(nav)}
            style={{background:"#fff",border:`1px solid ${T.bd}`,borderRadius:12,
              padding:"12px 14px",cursor:nav?"pointer":"default",
              transition:"box-shadow .1s"}}
            onMouseEnter={e=>{if(nav)e.currentTarget.style.boxShadow="0 2px 12px rgba(0,0,0,.09)"}}
            onMouseLeave={e=>e.currentTarget.style.boxShadow=""}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
              <div style={{fontSize:10,color:T.tx2}}>{l}</div>
              <span style={{fontSize:17}}>{i}</span>
            </div>
            <div style={{fontSize:22,fontWeight:700,color:c}}>{v}</div>
            <div style={{fontSize:10,color:T.tx3,marginTop:2}}>{s}</div>
          </div>
        ))}
      </div>

      <div style={{flex:1,display:"grid",gridTemplateColumns:"1fr 264px",
        gap:10,padding:"12px 18px",minHeight:0}}>
        <div style={{display:"flex",flexDirection:"column",gap:9,minWidth:0}}>
          {/* Map */}
          <Card style={{flex:1,minHeight:300,display:"flex",flexDirection:"column",overflow:"hidden"}}>
            <div style={{padding:"8px 12px",borderBottom:`1px solid ${T.bd}`,
              background:T.bg,display:"flex",alignItems:"center",
              justifyContent:"space-between",flexShrink:0}}>
              <div style={{fontSize:11,fontWeight:600,color:T.tx2,
                textTransform:"uppercase",letterSpacing:".05em"}}>Carte opérationnelle</div>
              <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
                {FILTER_OPTS.map(([f,label])=>(
                  <button key={f} onClick={()=>toggle(f)} style={{
                    padding:"3px 8px",borderRadius:6,fontSize:10,fontWeight:500,
                    cursor:"pointer",border:"none",fontFamily:"inherit",
                    background:filters.includes(f)?T.green:T.bg2,
                    color:filters.includes(f)?"#fff":T.tx2,
                  }}>{label}</button>
                ))}
              </div>
            </div>
            <div style={{flex:1,minHeight:260}}>
              <ApplitagMap lots={lots} transports={transports} opportunites={opportunites}
                chaufferies={chaufferies} plateformes={plateformes}
                filters={filters} highlightType={demoHighlight}
                onMarkerClick={(type,data)=>onOpenFiche(type,data)}/>
            </div>
          </Card>

          {/* Raccourcis */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:7}}>
            {[
              ["📦","Livraisons\naujourd'hui","livraisons",0],
              ["🔴","Alertes\ncritiques","alertes",openAlerts.filter(a=>a.niveau==="critique").length],
              ["📦","Bord\nde route","lots",lots.filter(l=>l.statut==="BORD_ROUTE").length],
              ["🚛","Transports\nen cours","transports",transports.filter(t=>t.statut==="en_route").length],
              ["🔭","À visiter","opportunites",opportunites.filter(o=>o.statut==="a_visiter").length],
            ].map(([ic,l,nav,n])=>(
              <button key={l} onClick={()=>onNav(nav)} style={{
                background:"#fff",border:`1px solid ${T.bd}`,borderRadius:10,
                padding:"9px 6px",cursor:"pointer",textAlign:"center",fontFamily:"inherit",
              }}>
                <div style={{fontSize:17}}>{ic}</div>
                <div style={{fontSize:15,fontWeight:700,color:n>0?T.green:T.tx3,margin:"3px 0"}}>{n}</div>
                <div style={{fontSize:9,color:T.tx3,lineHeight:1.3,whiteSpace:"pre-line"}}>{l}</div>
              </button>
            ))}
          </div>

          {/* Lots actifs */}
          <Card style={{overflow:"hidden"}}>
            <div style={{padding:"8px 12px",borderBottom:`1px solid ${T.bd}`,background:T.bg,
              display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{fontSize:11,fontWeight:600,color:T.tx2,textTransform:"uppercase",
                letterSpacing:".05em"}}>Lots actifs</div>
              <Btn onClick={()=>onNav("lots")} sm bg={T.greenL} color={T.greenD}>Voir tous</Btn>
            </div>
            <div style={{padding:"0 12px"}}>
              {lots.map(l=>{
                const b=lotBadge(l.statut);
                const av=l.volumeEstime?Math.min(100,Math.round(((l.volumeReel??0)/l.volumeEstime)*100)):0;
                return (
                  <div key={l.id} onClick={()=>onOpenFiche("lot",l)}
                    style={{display:"flex",alignItems:"center",gap:10,
                      padding:"8px 0",borderBottom:`0.5px solid ${T.bd}`,cursor:"pointer"}}>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{display:"flex",gap:7,alignItems:"center",marginBottom:3}}>
                        <span style={{fontFamily:"monospace",fontSize:12,fontWeight:600}}>{l.numeroLot}</span>
                        <Badge bg={b.bg} color={b.color}>{b.label}</Badge>
                      </div>
                      <div style={{fontSize:10,color:T.tx3}}>{l.commune} · {l.essencePrincipale}</div>
                      <div style={{height:3,background:T.bg2,borderRadius:2,marginTop:5}}>
                        <div style={{height:"100%",width:`${av}%`,background:T.green,borderRadius:2}}/>
                      </div>
                    </div>
                    <div style={{textAlign:"right",flexShrink:0}}>
                      <div style={{fontSize:13,fontWeight:700,color:T.green}}>{l.volumeReel??0} t</div>
                      <div style={{fontSize:9,color:T.tx3}}>réel</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* RIGHT */}
        <div style={{display:"flex",flexDirection:"column",gap:9}}>
          {openAlerts.length>0&&(
            <SCard title="Alertes" extra={<Badge bg={T.redL} color={T.red}>{openAlerts.length}</Badge>}>
              {openAlerts.slice(0,4).map((a,i)=>{
                const lot=lots.find(l=>l.id===a.refId);
                const bg={critique:T.redL,warn:T.amberL,info:T.blueL}[a.niveau];
                const col={critique:T.red,warn:T.amberD,info:T.blueD}[a.niveau];
                return (
                  <div key={a.id} onClick={()=>lot&&onOpenFiche("lot",lot)}
                    style={{padding:"6px 0",borderBottom:i<openAlerts.slice(0,4).length-1?`0.5px solid ${T.bd}`:"none",
                      cursor:lot?"pointer":"default"}}>
                    <div style={{display:"flex",gap:5,marginBottom:3}}>
                      <Badge bg={bg} color={col}>{a.niveau}</Badge>
                    </div>
                    <div style={{fontSize:11,color:T.tx,lineHeight:1.4}}>{a.message}</div>
                    <div style={{fontSize:9,color:T.tx3,marginTop:2}}>{fmt(a.createdAt)}</div>
                  </div>
                );
              })}
            </SCard>
          )}
          <SCard title="Activité récente" extra={null}>
            <div style={{display:"flex",flexDirection:"column",gap:0}}>
              {historique.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt))
                .slice(0,8).map((e,i)=>{
                  const icons={lot_cree:"🌲",statut_change:"🔄",opportunite_creee:"💡",
                    transport_parti:"🚛",alerte:"⚠️",visite_validee:"✅"};
                  const refObj = e.refType==="lot"?lots.find(l=>l.id===e.refId)
                    : e.refType==="opportunite"?opportunites.find(o=>o.id===e.refId):null;
                  return (
                    <div key={e.id} onClick={()=>refObj&&onOpenFiche(e.refType,refObj)}
                      style={{display:"flex",gap:7,padding:"6px 0",
                        borderBottom:i<7?`0.5px solid ${T.bd}`:"none",
                        cursor:refObj?"pointer":"default"}}>
                      <div style={{width:20,height:20,borderRadius:"50%",background:T.bg2,
                        display:"flex",alignItems:"center",justifyContent:"center",
                        fontSize:10,flexShrink:0}}>{icons[e.action]??"•"}</div>
                      <div>
                        <div style={{fontSize:11,color:T.tx,lineHeight:1.3}}>{e.message}</div>
                        <div style={{fontSize:9,color:T.tx3}}>{fmt(e.createdAt)} · {e.utilisateur}</div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </SCard>
        </div>
      </div>
    </div>
  );
};

// ── DEMO PAGE ──────────────────────────────────────────────────────────────────
const DemoPage = ({onLaunch, onReset, store}) => (
  <div style={{flex:1,overflowY:"auto",padding:"20px"}}>
    <div style={{maxWidth:700,margin:"0 auto"}}>
      <div style={{background:T.green,borderRadius:16,padding:"24px",color:"#fff",marginBottom:16}}>
        <div style={{fontSize:22,fontWeight:700,marginBottom:6}}>🎬 Mode démo APPLITAG</div>
        <div style={{fontSize:14,opacity:.9,lineHeight:1.7}}>
          Présentation complète pour partenaires, clients pilotes et investisseurs.
          Jeu de données réaliste, parcours guidé en 10 étapes, workflow complet filière bois énergie.
        </div>
      </div>

      {/* Dataset stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:9,marginBottom:16}}>
        {[
          [store.contacts.length,"Contacts","👤",T.green],
          [store.opportunites.length,"Opportunités","💡",T.purple],
          [store.lots.length,"Lots","🌲",T.blue],
          [store.transports.length,"Transports","🚛",T.amber],
          [store.chaufferies.length,"Chaufferies","🏭",T.coral],
          [store.plateformes.length,"Plateformes","🏗️",T.purple],
          [store.alertes.length,"Alertes","🔔",T.red],
          [store.historique.length,"Événements","📋",T.tx2],
        ].map(([n,l,i,c])=>(
          <div key={l} style={{background:"#fff",border:`1px solid ${T.bd}`,
            borderRadius:10,padding:"11px 13px",textAlign:"center"}}>
            <div style={{fontSize:18}}>{i}</div>
            <div style={{fontSize:20,fontWeight:700,color:c,margin:"3px 0"}}>{n}</div>
            <div style={{fontSize:10,color:T.tx3}}>{l}</div>
          </div>
        ))}
      </div>

      {/* Parcours */}
      <SCard title="Parcours de démonstration — 10 étapes">
        {DEMO_STEPS.map((s,i)=>(
          <div key={s.step} style={{display:"flex",gap:12,padding:"10px 0",
            borderBottom:i<DEMO_STEPS.length-1?`0.5px solid ${T.bd}`:"none"}}>
            <div style={{width:32,height:32,borderRadius:8,background:T.greenL,
              display:"flex",alignItems:"center",justifyContent:"center",
              fontSize:17,flexShrink:0}}>{s.emoji}</div>
            <div style={{flex:1}}>
              <div style={{fontSize:12,fontWeight:600,marginBottom:2}}>
                {s.step}. {s.titre}
              </div>
              <div style={{fontSize:11,color:T.tx3,lineHeight:1.5}}>{s.description.slice(0,120)}…</div>
            </div>
          </div>
        ))}
      </SCard>

      {/* Tests */}
      <SCard title={`Tests unitaires — ${TESTS_PASSED}/${UNIT_TESTS.length} passés`}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4}}>
          {TEST_RESULTS.map((r,i)=>(
            <div key={i} style={{display:"flex",gap:6,alignItems:"center",
              padding:"3px 0",fontSize:11}}>
              <span style={{color:r.pass?T.green:T.red,fontWeight:700}}>{r.pass?"✓":"✗"}</span>
              <span style={{color:r.pass?T.tx:T.red}}>{r.name}</span>
            </div>
          ))}
        </div>
      </SCard>

      <div style={{display:"flex",gap:10,marginTop:12}}>
        <PBtn onClick={onLaunch} style={{flex:2,padding:"14px",fontSize:14,justifyContent:"center"}}>
          ▶ Lancer la démo guidée
        </PBtn>
        <Btn onClick={onReset} bg={T.amberL} color={T.amberD} style={{flex:1,justifyContent:"center",padding:"14px"}}>
          ↺ Réinitialiser les données
        </Btn>
      </div>
    </div>
  </div>
);

// ── APP ─────────────────────────────────────────────────────────────────────────
export default function App() {
  const [store, setStore] = useState(buildDemoData);
  const [page, setPage] = useState("demo");
  const [fiche, setFiche] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [toasts, addToast] = useToasts();
  const [demoMode, setDemoMode] = useState(false);
  const [demoStep, setDemoStep] = useState(1);

  const resetStore = useCallback(()=>{
    setStore(buildDemoData());
    setFiche(null);
    addToast("success","Données démo réinitialisées");
  },[addToast]);

  const openFiche = useCallback((type,data)=>{
    const extra = type==="opportunite"
      ? {contact:store.contacts.find(c=>c.id===data.contactId)}
      : type==="lot"
      ? {contact:store.contacts.find(c=>c.id===data.contactId)}
      : {};
    setFiche({type,data,...extra});
  },[store.contacts]);

  const updateLot = useCallback((lot)=>{
    setStore(s=>({...s,
      lots:s.lots.map(l=>l.id===lot.id?lot:l),
      historique:[...s.historique,{id:uid(),refId:lot.id,refType:"lot",action:"statut_change",
        message:`${lot.numeroLot} → ${lotBadge(lot.statut).label}`,utilisateur:"J. Moreau",createdAt:nowISO()}]
    }));
    if(fiche?.type==="lot"&&fiche.data.id===lot.id) setFiche(f=>({...f,data:lot}));
    addToast("success",`${lot.numeroLot} → ${lotBadge(lot.statut).label}`);
  },[fiche,addToast]);

  const updateOpp = useCallback((opp)=>{
    setStore(s=>({...s, opportunites:s.opportunites.map(o=>o.id===opp.id?opp:o)}));
    if(fiche?.type==="opportunite"&&fiche.data.id===opp.id) setFiche(f=>({...f,data:opp}));
    addToast("success",`Opportunité → ${oppBadge(opp.statut).label}`);
  },[fiche,addToast]);

  const resolveAlerte = useCallback((id)=>{
    setStore(s=>({...s,alertes:s.alertes.map(a=>a.id===id?{...a,resolue:true}:a)}));
    addToast("success","Alerte résolue");
  },[addToast]);

  const launchDemo = () => {
    setDemoMode(true);
    setDemoStep(1);
    setPage("dashboard");
    addToast("success","Démo guidée lancée — 10 étapes");
  };

  const demoNext = () => {
    if(demoStep>=DEMO_STEPS.length){setDemoMode(false);setPage("demo");return;}
    const next=DEMO_STEPS[demoStep];
    setDemoStep(demoStep+1);
    if(next.screen==="dashboard"||next.screen==="contacts"||next.screen==="opportunites")
      setPage(next.screen==="contacts"?"contacts":next.screen==="opportunites"?"opportunites":"dashboard");
    else setPage("dashboard");
    if(next.highlight==="lot"||next.highlight==="tas"||next.highlight==="dechiquetage"||next.highlight==="transport"||next.highlight==="livraison")
      openFiche("lot",store.lots[0]);
    else if(next.highlight==="opportunite")
      openFiche("opportunite",store.opportunites[0]);
    else if(next.highlight==="contact")
      openFiche("contact",store.contacts[0]);
    else if(next.highlight==="cloture")
      setFiche(null);
  };

  const demoPrev = () => {
    if(demoStep<=1) return;
    setDemoStep(demoStep-1);
  };

  const openAlerts = store.alertes.filter(a=>!a.resolue);
  const curDemoStep = DEMO_STEPS[demoStep-1];
  const demoHighlight = demoMode ? curDemoStep?.highlight : null;

  const renderPage = () => {
    if(page==="dashboard") return (
      <DashboardPage store={store} onOpenFiche={openFiche} onNav={setPage} demoHighlight={demoHighlight}/>
    );
    if(page==="demo") return (
      <DemoPage onLaunch={launchDemo} onReset={resetStore} store={store}/>
    );
    if(page==="persistance") return (
      <PersistancePanel store={store} onReset={resetStore}/>
    );
    if(page==="alertes") return (
      <div style={{flex:1,overflowY:"auto",padding:"16px 20px",display:"flex",flexDirection:"column",gap:8}}>
        {store.alertes.map(a=>{
          const b={critique:{bg:T.redL,c:T.red},warn:{bg:T.amberL,c:T.amberD},info:{bg:T.blueL,c:T.blueD}}[a.niveau];
          const lot=store.lots.find(l=>l.id===a.refId);
          return (
            <div key={a.id} style={{background:"#fff",border:`1px solid ${T.bd}`,borderRadius:12,
              padding:"12px 14px",borderLeft:`4px solid ${b.c}`,
              opacity:a.resolue?.7:1}}>
              <div style={{display:"flex",justifyContent:"space-between",gap:10,alignItems:"flex-start"}}>
                <div>
                  <div style={{display:"flex",gap:7,marginBottom:5}}>
                    <Badge bg={b.bg} color={b.c}>{a.niveau}</Badge>
                    {a.resolue&&<Badge bg={T.greenL} color={T.greenD}>Résolue</Badge>}
                  </div>
                  <div style={{fontSize:13,color:T.tx,lineHeight:1.5}}>{a.message}</div>
                  <div style={{fontSize:11,color:T.tx3,marginTop:4}}>{fmt(a.createdAt)}{lot&&<span style={{color:T.blue,marginLeft:8,cursor:"pointer"}} onClick={()=>openFiche("lot",lot)}>→ {lot.numeroLot}</span>}</div>
                </div>
                {!a.resolue&&<Btn onClick={()=>resolveAlerte(a.id)} bg={T.greenL} color={T.greenD} sm>Résoudre</Btn>}
              </div>
            </div>
          );
        })}
      </div>
    );
    // Stub pages
    const stub={lots:"🌲 Lots",contacts:"👥 Contacts",opportunites:"💡 Opportunités",transports:"🚛 Transports"}[page];
    if(stub) return (
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
        justifyContent:"center",gap:12,color:T.tx3,padding:40}}>
        <div style={{fontSize:48}}>{stub.split(" ")[0]}</div>
        <div style={{fontSize:16,fontWeight:500,color:T.tx}}>{stub}</div>
        <div style={{fontSize:12}}>Module complet dans les sprints précédents (applitag_dashboard_web.jsx)</div>
        <Badge bg={T.blueL} color={T.blueD}>Sprint précédent</Badge>
      </div>
    );
    return null;
  };

  return (
    <div style={{display:"flex",minHeight:"100vh",background:T.bg,
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,sans-serif"}}>
      <style>{`@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}`}</style>
      <Toasts toasts={toasts}/>
      {confirm&&<ConfirmModal msg={confirm.msg} onConfirm={()=>{confirm.fn();setConfirm(null);}} onCancel={()=>setConfirm(null)}/>}

      <Sidebar active={page} onNav={(id)=>{setPage(id);setFiche(null);}} alertCount={openAlerts.length}/>

      <div style={{flex:1,display:"flex",flexDirection:"column",minWidth:0,overflow:"hidden"}}>
        {/* Topbar */}
        <div style={{background:"#fff",borderBottom:`1px solid ${T.bd}`,
          padding:"9px 18px",display:"flex",alignItems:"center",gap:10,
          position:"sticky",top:0,zIndex:100,flexShrink:0}}>
          <div style={{flex:1}}>
            <div style={{fontSize:15,fontWeight:600}}>
              {MENU.find(m=>m.id===page)?.label ?? "APPLITAG"}
            </div>
            {page==="dashboard"&&<div style={{fontSize:10,color:T.tx3}}>Saison 2025 · Yonne (89)</div>}
          </div>
          {demoMode&&(
            <div style={{background:T.amberL,color:T.amberD,padding:"4px 12px",
              borderRadius:8,fontSize:11,fontWeight:600,display:"flex",gap:8,alignItems:"center"}}>
              🎬 Démo guidée — étape {demoStep}/{DEMO_STEPS.length}
              <button onClick={()=>setDemoMode(false)} style={{background:"none",border:"none",
                cursor:"pointer",color:T.amberD,fontSize:13,padding:0}}>✕</button>
            </div>
          )}
          <div style={{display:"flex",gap:8}}>
            <Btn onClick={()=>{setPage("demo")}} bg={T.amberL} color={T.amberD} sm>🎬 Démo</Btn>
            <Btn onClick={()=>openFiche("opportunite",store.opportunites[0])} bg={T.amberL} color={T.amberD}>+ Opportunité</Btn>
            <Btn onClick={()=>{addToast("success","Nouveau lot créé");}} bg={T.green} color="#fff">+ Nouveau lot</Btn>
            <button onClick={()=>setPage("alertes")} style={{position:"relative",
              background:openAlerts.length>0?T.redL:T.bg2,border:"none",cursor:"pointer",
              padding:"6px 8px",borderRadius:8}}>
              <span style={{fontSize:15}}>🔔</span>
              {openAlerts.length>0&&<span style={{position:"absolute",top:2,right:2,
                width:14,height:14,borderRadius:"50%",background:T.red,color:"#fff",
                fontSize:8,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center"}}>
                {openAlerts.length}</span>}
            </button>
          </div>
        </div>

        {/* Content + right panel */}
        <div style={{flex:1,display:"flex",overflow:"hidden"}}>
          <div style={{flex:1,overflow:"auto",display:"flex",flexDirection:"column"}}>
            {renderPage()}
          </div>

          {/* Fiche panneau droit */}
          {fiche&&(
            <div style={{width:370,minWidth:370,height:"100%",background:"#fff",
              borderLeft:`1px solid ${T.bd}`,display:"flex",flexDirection:"column",
              flexShrink:0,overflow:"hidden"}}>
              {fiche.type==="lot"&&(
                <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
                  <div style={{padding:"12px 14px",borderBottom:`1px solid ${T.bd}`,
                    display:"flex",gap:8,alignItems:"center"}}>
                    <button onClick={()=>setFiche(null)} style={{background:"none",border:"none",
                      cursor:"pointer",fontSize:18,color:T.tx2}}>‹</button>
                    <div style={{flex:1}}>
                      <div style={{fontFamily:"monospace",fontSize:14,fontWeight:700}}>{fiche.data.numeroLot}</div>
                      <div style={{fontSize:11,color:T.tx3}}>{fiche.data.commune}</div>
                    </div>
                    <Badge bg={lotBadge(fiche.data.statut).bg} color={lotBadge(fiche.data.statut).color}>
                      {lotBadge(fiche.data.statut).label}
                    </Badge>
                  </div>
                  <div style={{flex:1,overflowY:"auto",padding:"12px 14px",display:"flex",flexDirection:"column",gap:9}}>
                    <SCard title="Cycle de vie">
                      <LotTimeline statut={fiche.data.statut}/>
                    </SCard>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:7}}>
                      {[["Volume est.",`${fiche.data.volumeEstime??0} t`,T.tx],["Réel",`${fiche.data.volumeReel??0} t`,T.green],["Humidité",`${fiche.data.humidite??0} %`,fiche.data.humidite>35?T.red:T.tx]].map(([l,v,c])=>(
                        <div key={l} style={{background:T.bg2,borderRadius:8,padding:"8px",textAlign:"center"}}>
                          <div style={{fontSize:9,color:T.tx3}}>{l}</div>
                          <div style={{fontSize:14,fontWeight:700,color:c}}>{v}</div>
                        </div>
                      ))}
                    </div>
                    {fiche.data.tas?.length>0&&(
                      <SCard title="Tas">
                        {fiche.data.tas.map(t=>(
                          <div key={t.id} style={{display:"flex",justifyContent:"space-between",
                            padding:"5px 0",borderBottom:`0.5px solid ${T.bd}`,fontSize:11}}>
                            <span style={{fontWeight:500}}>Tas {t.numeroTas}</span>
                            <div style={{display:"flex",gap:5}}>
                              <Badge bg={T.bg2} color={T.tx2}>{t.volumeEstime} t</Badge>
                              <Badge bg={t.statut==="pret"?T.greenL:t.statut==="dechiquete"?T.purpleL:T.amberL}
                                color={t.statut==="pret"?T.greenD:t.statut==="dechiquete"?T.purpleD:T.amberD}>{t.statut}</Badge>
                            </div>
                          </div>
                        ))}
                      </SCard>
                    )}
                    <SCard title="Actions workflow">
                      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                        {[
                          {a:"valider_visite",l:"✅ Valider visite",ts:"VISITE_REALISEE"},
                          {a:"demarrer_exploitation",l:"⛏ Démarrer",ts:"EN_EXPLOITATION"},
                          {a:"ajouter_tas",l:"📦 Ajouter tas",ts:null},
                          {a:"planifier_dechiquetage",l:"🪓 Déchiquetage",ts:"A_DECHIQUETER"},
                          {a:"creer_transport",l:"🚛 Transport",ts:"EN_TRANSPORT"},
                          {a:"cloturer",l:"🔒 Clôturer",ts:"CLOTURE"},
                        ].map(({a,l,ts})=>{
                          const chk=canDoLotAction(fiche.data.statut,a);
                          return chk.allowed ? (
                            <Btn key={a} sm onClick={()=>{
                              const fn=()=>{if(ts)updateLot({...fiche.data,statut:ts});else addToast("success",l);};
                              if(a==="cloturer"){setConfirm({msg:`Clôturer ${fiche.data.numeroLot} ?`,fn});}else fn();
                            }} bg={T.greenL} color={T.greenD} style={{justifyContent:"center"}}>{l}</Btn>
                          ):(
                            <BlockedBtn key={a} reason={chk.reason}>{l}</BlockedBtn>
                          );
                        })}
                      </div>
                    </SCard>
                  </div>
                </div>
              )}
              {fiche.type==="opportunite"&&(
                <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
                  <div style={{background:T.purple,color:"#fff",padding:"12px 14px"}}>
                    <button onClick={()=>setFiche(null)} style={{background:"none",border:"none",
                      cursor:"pointer",color:"rgba(255,255,255,.7)",fontSize:16,marginBottom:6}}>‹ Retour</button>
                    <div style={{fontSize:15,fontWeight:500}}>{fiche.data.commune??"Opportunité"}</div>
                    <div style={{display:"flex",gap:7,marginTop:4}}>
                      <Badge bg="rgba(255,255,255,.25)" color="#fff">{oppBadge(fiche.data.statut).label}</Badge>
                      {fiche.data.volumeEstime&&<Badge bg="rgba(255,255,255,.25)" color="#fff">~{fiche.data.volumeEstime} t</Badge>}
                    </div>
                  </div>
                  <div style={{flex:1,overflowY:"auto",padding:"12px 14px",display:"flex",flexDirection:"column",gap:9}}>
                    {fiche.contact&&(
                      <SCard title="Contact">
                        <Row k="Nom" v={`${fiche.contact.prenom??""} ${fiche.contact.nom}`}/>
                        <Row k="Téléphone" v={fiche.contact.telephone} vc={T.blue}/>
                        <Row k="Type" v={fiche.contact.typeContact} border={false}/>
                      </SCard>
                    )}
                    {fiche.data.notes&&(
                      <div style={{background:T.bg2,borderRadius:9,padding:"9px 11px",
                        fontSize:12,color:T.tx,lineHeight:1.6}}>{fiche.data.notes}</div>
                    )}
                    <SCard title="Actions">
                      <div style={{display:"flex",flexDirection:"column",gap:7}}>
                        {(()=>{
                          const cv=canDoOppAction(fiche.data.statut,"planifier_visite");
                          const cl=canDoOppAction(fiche.data.statut,"creer_lot");
                          const ca=canDoOppAction(fiche.data.statut,"abandonner");
                          return (<>
                            {cv.allowed?<PBtn onClick={()=>{updateOpp({...fiche.data,statut:"visite_programmee"});addToast("success","Visite planifiée");}}>🔭 Planifier une visite</PBtn>:<BlockedBtn reason={cv.reason}>🔭 Planifier une visite</BlockedBtn>}
                            {cl.allowed?<Btn onClick={()=>{updateOpp({...fiche.data,statut:"lot_cree"});addToast("success","Lot créé depuis l'opportunité");}} bg={T.greenL} color={T.greenD} style={{justifyContent:"center"}}>🌲 Créer un lot</Btn>:<BlockedBtn reason={cl.reason}>🌲 Créer un lot</BlockedBtn>}
                            {ca.allowed?<Btn onClick={()=>setConfirm({msg:`Abandonner l'opportunité ${fiche.data.commune} ?`,fn:()=>updateOpp({...fiche.data,statut:"perdue"})})} bg={T.redL} color={T.red} style={{justifyContent:"center"}}>✕ Abandonner</Btn>:<BlockedBtn reason={ca.reason}>✕ Abandonner</BlockedBtn>}
                          </>);
                        })()}
                      </div>
                    </SCard>
                  </div>
                </div>
              )}
              {(fiche.type==="chaufferie"||fiche.type==="plateforme")&&(
                <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
                  <div style={{padding:"12px 14px",borderBottom:`1px solid ${T.bd}`,
                    display:"flex",gap:8,alignItems:"center"}}>
                    <button onClick={()=>setFiche(null)} style={{background:"none",border:"none",
                      cursor:"pointer",fontSize:18,color:T.tx2}}>‹</button>
                    <div>
                      <div style={{fontSize:14,fontWeight:500}}>{fiche.data.nom}</div>
                      <div style={{fontSize:11,color:T.tx3}}>{fiche.data.commune}</div>
                    </div>
                  </div>
                  <div style={{flex:1,overflowY:"auto",padding:"12px 14px",display:"flex",flexDirection:"column",gap:9}}>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:7}}>
                      <div style={{background:T.blueL,borderRadius:9,padding:"10px",textAlign:"center"}}>
                        <div style={{fontSize:9,color:T.blueD}}>Capacité/an</div>
                        <div style={{fontSize:16,fontWeight:700,color:T.blueD}}>
                          {(fiche.data.capaciteTan||fiche.data.capaciteT||0).toLocaleString()} t
                        </div>
                      </div>
                      <div style={{background:T.greenL,borderRadius:9,padding:"10px",textAlign:"center"}}>
                        <div style={{fontSize:9,color:T.greenD}}>Stock actuel</div>
                        <div style={{fontSize:16,fontWeight:700,color:T.greenD}}>{fiche.data.stockActuelT||0} t</div>
                      </div>
                    </div>
                    <SCard title="Actions">
                      <div style={{display:"flex",flexDirection:"column",gap:7}}>
                        {fiche.type==="chaufferie"?(<>
                          <PBtn onClick={()=>addToast("success","Livraison prévue créée")}>+ Nouvelle livraison prévue</PBtn>
                          <Btn onClick={()=>addToast("success","Contrat associé")} bg={T.blueL} color={T.blueD} style={{justifyContent:"center"}}>📄 Associer contrat</Btn>
                          <Btn onClick={()=>addToast("success","Besoin créé")} bg={T.amberL} color={T.amberD} style={{justifyContent:"center"}}>🔥 Besoin combustible</Btn>
                        </>):(<>
                          <PBtn onClick={()=>addToast("success","Entrée stock enregistrée")}>📥 Entrée stock</PBtn>
                          <Btn onClick={()=>addToast("warn","Sortie stock enregistrée")} bg={T.amberL} color={T.amberD} style={{justifyContent:"center"}}>📤 Sortie stock</Btn>
                          <Btn onClick={()=>addToast("success","Lot associé")} bg={T.greenL} color={T.greenD} style={{justifyContent:"center"}}>🌲 Associer un lot</Btn>
                        </>)}
                      </div>
                    </SCard>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Démo guidée overlay */}
      {demoMode&&(
        <DemoOverlay step={demoStep} total={DEMO_STEPS.length}
          stepData={curDemoStep}
          onNext={demoNext} onPrev={demoPrev}
          onQuit={()=>{setDemoMode(false);}}/>
      )}
    </div>
  );
}
