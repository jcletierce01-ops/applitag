// ============================================================
// APPLITAG MOBILE — Auth QR + PIN + Multi-tenant
// ============================================================

import { useState, useCallback, useEffect, useRef } from "react";
import { Html5Qrcode } from "html5-qrcode";

const API = "https://applitag-api-production.up.railway.app";

const C = {
  green:"#1D9E75", greenL:"#E1F5EE", greenD:"#085041",
  blue:"#185FA5",  blueL:"#E6F1FB",  blueD:"#042C53",
  amber:"#BA7517", amberL:"#FAEEDA", amberD:"#412402",
  red:"#A32D2D",   redL:"#FCEBEB",
  purple:"#534AB7",purpleL:"#EEEDFE",purpleD:"#26215C",
  brown:"#8B6914", brownL:"#F1EFE8",
  bg:"#F5F4F1", bg2:"#ECEAE6",
  bd:"#DDDBD5", bd2:"#C8C5BE",
  tx:"#1A1A18", tx2:"#5A5955", tx3:"#9A9892",
  sb:"#111",
};

const BTN_H = 56;
const INPUT_H = 52;
const FONT_INPUT = 16;
const PADDING = 16;

const uid = () => Math.random().toString(36).slice(2,9);
const nowISO = () => new Date().toISOString();
const todayS = () => new Date().toISOString().slice(0,10);

const genLotNumero = (codePostal, seq) => {
  const now = new Date();
  const annee = now.getFullYear();
  const mois = String(now.getMonth()+1).padStart(2,"0");
  const dept = (codePostal||"00").toString().slice(0,2);
  const seqStr = String(seq||1).padStart(3,"0");
  return `LOT-${annee}-${mois}-${dept}-${seqStr}`;
};

// Auth helpers
const getToken = () => localStorage.getItem("applitag_token");
const getUser  = () => { try { return JSON.parse(localStorage.getItem("applitag_user")||"null"); } catch { return null; } };
const getEntrepriseId = () => localStorage.getItem("applitag_entreprise_id");
const setAuth  = (token, user, entrepriseId) => {
  localStorage.setItem("applitag_token", token);
  localStorage.setItem("applitag_user", JSON.stringify(user));
  localStorage.setItem("applitag_entreprise_id", entrepriseId);
};
const clearAuth = () => {
  localStorage.removeItem("applitag_token");
  localStorage.removeItem("applitag_user");
  localStorage.removeItem("applitag_entreprise_id");
};
const authHeaders = () => ({
  "Content-Type":"application/json",
  "Authorization":`Bearer ${getToken()}`,
});

const ORIGINE_OPTS = [
  ["appel_entrant","📞","Appel entrant"],
  ["visite_terrain","🔭","Visite terrain"],
  ["recommandation","🤝","Recommandation"],
  ["salon","🎪","Salon"],
  ["email","📧","Email"],
  ["site_internet","🌐","Site internet"],
  ["reseau_applitag","🌲","Réseau APPLITAG"],
  ["autre","…","Autre"],
];
const TYPE_CONTACT_OPTS = [
  ["proprietaire_forestier","👤","Propriétaire forestier"],
  ["cooperative","🌿","Coopérative"],
  ["etf","⛏","ETF"],
  ["transporteur","🚛","Transporteur"],
  ["chaufferie","🏭","Chaufferie"],
  ["plateforme","🏗️","Plateforme"],
  ["negociant","💼","Négociant"],
  ["collectivite","🏛️","Collectivité"],
  ["prospect","🔍","Prospect"],
];
const TYPE_RESSOURCE_OPTS = [
  ["bois_energie","🪵","Bois énergie"],
  ["bois_oeuvre","🌲","Bois d'œuvre"],
  ["bois_rond","🪨","Bois rond"],
  ["bois_trituration","📄","Bois de trituration"],
  ["bois_bord_route","🛣️","Bois bord de route"],
  ["stock_plaquettes","🪣","Stock plaquettes"],
  ["mixte","🌳","Mixte"],
];
const PRIORITE_OPTS = [
  ["basse","⚪","Basse"],
  ["moyenne","🟡","Moyenne"],
  ["haute","🟠","Haute"],
  ["immediate","🔴","Immédiate"],
];
const STATUT_OPTS = [
  ["nouveau","🆕","Nouveau"],
  ["a_rappeler","📞","À rappeler"],
  ["qualifie","✅","Qualifié"],
  ["visite_prevue","🔭","Visite prévue"],
  ["perdu","❌","Perdu"],
];

// ── ATOMS ─────────────────────────────────────────────────────
const BigBtn = ({onClick,bg=C.green,color="#fff",children,disabled,icon,style={}}) => (
  <button onClick={disabled?undefined:onClick} style={{
    width:"100%",height:BTN_H,borderRadius:14,
    background:disabled?C.bg2:bg,color:disabled?C.tx3:color,
    border:"none",fontFamily:"inherit",fontSize:16,fontWeight:600,
    display:"flex",alignItems:"center",justifyContent:"center",gap:10,
    cursor:disabled?"not-allowed":"pointer",opacity:disabled?.5:1,
    WebkitTapHighlightColor:"transparent",...style,
  }}>
    {icon&&<span style={{fontSize:22}}>{icon}</span>}
    {children}
  </button>
);

const MInput = ({label,value,onChange,placeholder,type="text",required,error,hint,big}) => (
  <div style={{marginBottom:14}}>
    <div style={{fontSize:13,fontWeight:600,color:error?C.red:C.tx2,marginBottom:5,
      display:"flex",justifyContent:"space-between"}}>
      <span>{label}{required&&<span style={{color:"#E24B4A"}}> *</span>}</span>
      {hint&&<span style={{fontWeight:400,color:C.tx3,fontSize:12}}>{hint}</span>}
    </div>
    {big ? (
      <textarea value={value} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder} rows={3}
        style={{width:"100%",padding:"14px",borderRadius:12,resize:"none",
          border:`1.5px solid ${error?C.red:C.bd}`,
          fontSize:FONT_INPUT,fontFamily:"inherit",lineHeight:1.5,
          background:"#fff",color:C.tx,outline:"none"}}/>
    ) : (
      <input value={value} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder} type={type}
        style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
          border:`1.5px solid ${error?C.red:C.bd}`,
          fontSize:FONT_INPUT,fontFamily:"inherit",
          background:"#fff",color:C.tx,outline:"none"}}/>
    )}
    {error&&<div style={{fontSize:12,color:C.red,marginTop:4}}>⚠ {error}</div>}
  </div>
);

const GridSelect = ({options,value,onChange,cols=3}) => (
  <div style={{display:"grid",gridTemplateColumns:`repeat(${cols},1fr)`,gap:8,marginBottom:14}}>
    {options.map(([v,emoji,label])=>{
      const active = value===v;
      return (
        <button key={v} onClick={()=>onChange(v)} style={{
          padding:"10px 6px",borderRadius:12,
          border:`1.5px solid ${active?C.green:C.bd}`,
          background:active?C.greenL:"#fff",cursor:"pointer",
          fontFamily:"inherit",display:"flex",flexDirection:"column",
          alignItems:"center",gap:4,WebkitTapHighlightColor:"transparent",
        }}>
          <span style={{fontSize:20}}>{emoji}</span>
          <span style={{fontSize:10,fontWeight:active?600:400,
            color:active?C.greenD:C.tx2,textAlign:"center",lineHeight:1.3}}>
            {label}
          </span>
        </button>
      );
    })}
  </div>
);

const SectionTitle = ({icon,label}) => (
  <div style={{fontSize:13,fontWeight:700,color:C.tx2,marginBottom:12,marginTop:8,
    display:"flex",alignItems:"center",gap:7,
    paddingBottom:8,borderBottom:`1px solid ${C.bd}`}}>
    <span style={{fontSize:16}}>{icon}</span>{label}
  </div>
);

// ── ÉCRAN LOGIN ───────────────────────────────────────────────
const LoginScreen = ({onLogin, onLoginOperateur}) => {
  const [step, setStep] = useState("scan"); // scan | pin | operateur
  const [entrepriseId, setEntrepriseId] = useState("");
  const [entrepriseNom, setEntrepriseNom] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [opNom, setOpNom] = useState("");
  const [opPin, setOpPin] = useState("");
  const qrRef = useRef(null);
  const scannerRef = useRef(null);

  useEffect(() => {
    if (step === "scan") {
      const scanner = new Html5Qrcode("qr-reader");
      scannerRef.current = scanner;
      scanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        (text) => {
          try {
            const data = JSON.parse(text);
            if (data.entrepriseId && data.nom) {
              scanner.stop().catch(()=>{});
              setEntrepriseId(data.entrepriseId);
              setEntrepriseNom(data.nom);
              setStep("pin");
            }
          } catch {
            setError("QR code invalide");
          }
        },
        () => {}
      ).catch(() => setError("Impossible d'accéder à la caméra"));
      return () => { scanner.stop().catch(()=>{}); };
    }
  }, [step]);

  const handlePin = (digit) => {
    if (pin.length < 4) setPin(p => p + digit);
  };
  const handleDel = () => setPin(p => p.slice(0,-1));

  useEffect(() => {
    if (pin.length === 4) handleLogin();
  }, [pin]);

  const handleLogin = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API}/auth/login`, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({ entrepriseId, pin }),
      });
      if (!res.ok) throw new Error("PIN incorrect");
      const data = await res.json();
      setAuth(data.access_token, data.utilisateur, entrepriseId);
      onLogin(data.utilisateur);
    } catch(e) {
      setError("PIN incorrect — réessayez");
      setPin("");
    }
    setLoading(false);
  };

  const handleLoginOperateur = async () => {
    if (!opNom.trim()||!opPin.trim()) { setError("Saisissez votre nom et PIN"); return; }
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API}/operateurs/login`, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          entrepriseId: "c1b035b8-c2d5-4b84-a07e-2a3d503fb96c",
          nom: opNom, pin: opPin
        }),
      });
      if (!res.ok) throw new Error("Identifiants incorrects");
      const data = await res.json();
      onLoginOperateur(data);
    } catch(e) {
      setError("Nom ou PIN incorrect — réessayez");
    }
    setLoading(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",
      background:C.sb,color:"#fff"}}>
      {/* Header */}
      <div style={{padding:"32px 24px 24px",textAlign:"center"}}>
        <img src="/logo.png" alt="APPLITAG" style={{width:80,height:80,objectFit:"contain",marginBottom:12}}/>
        <div style={{fontSize:22,fontWeight:700}}>APPLITAG</div>
        <div style={{fontSize:13,opacity:.6,marginTop:4}}>Gestion forestière terrain</div>
      </div>

      <div style={{flex:1,padding:PADDING,overflowY:"auto",background:C.sb}}>
        {step==="scan"&&(
          <div>
            <div style={{fontSize:14,color:"rgba(255,255,255,.7)",
              textAlign:"center",marginBottom:20,lineHeight:1.6}}>
              Scannez le QR code fourni par votre administrateur
            </div>
            <div id="qr-reader" style={{borderRadius:16,overflow:"hidden",
              background:"#000",marginBottom:16}}/>
            {error&&(
              <div style={{color:C.amber,fontSize:13,textAlign:"center",marginBottom:12}}>
                ⚠ {error}
              </div>
            )}
            <button onClick={()=>{
              setEntrepriseId("c1b035b8-c2d5-4b84-a07e-2a3d503fb96c");
              setEntrepriseNom("APPLITAG");
              setStep("pin");
            }} style={{width:"100%",padding:14,borderRadius:12,
              background:"rgba(255,255,255,.1)",border:"1px solid rgba(255,255,255,.2)",
              color:"rgba(255,255,255,.7)",fontFamily:"inherit",fontSize:13,
              cursor:"pointer",WebkitTapHighlightColor:"transparent",marginBottom:10}}>
              Saisir manuellement l'identifiant
            </button>
            <div style={{textAlign:"center",color:"rgba(255,255,255,.3)",fontSize:12,margin:"12px 0"}}>
              ou
            </div>
            <button onClick={()=>{ setError(""); setStep("operateur"); }} style={{
              width:"100%",padding:14,borderRadius:12,
              background:"rgba(29,158,117,.2)",border:"1px solid rgba(29,158,117,.4)",
              color:"rgba(255,255,255,.8)",fontFamily:"inherit",fontSize:13,
              cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>
              👷 Connexion opérateur terrain
            </button>
          </div>
        )}

        {step==="pin"&&(
          <div>
            <div style={{textAlign:"center",marginBottom:24}}>
              <div style={{fontSize:13,color:"rgba(255,255,255,.5)",marginBottom:4}}>
                Entreprise
              </div>
              <div style={{fontSize:18,fontWeight:700,color:C.green}}>
                {entrepriseNom}
              </div>
            </div>
            <div style={{fontSize:14,color:"rgba(255,255,255,.7)",
              textAlign:"center",marginBottom:24}}>
              Entrez votre code PIN
            </div>
            <div style={{display:"flex",justifyContent:"center",gap:16,marginBottom:32}}>
              {[0,1,2,3].map(i=>(
                <div key={i} style={{
                  width:18,height:18,borderRadius:"50%",
                  background:pin.length>i?C.green:"rgba(255,255,255,.2)",
                  transition:"background .15s",
                }}/>
              ))}
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,margin:"0 auto",maxWidth:320}}>
              {[1,2,3,4,5,6,7,8,9].map(d=>(
                <button key={d} onClick={()=>handlePin(String(d))}
                  style={{height:68,borderRadius:14,
                    background:"rgba(255,255,255,.1)",
                    border:"1px solid rgba(255,255,255,.15)",
                    color:"#fff",fontSize:26,fontWeight:500,
                    cursor:"pointer",fontFamily:"inherit",
                    WebkitTapHighlightColor:"transparent"}}>
                  {d}
                </button>
              ))}
              <button onClick={handleDel}
                style={{height:68,borderRadius:14,
                  background:"rgba(255,255,255,.08)",
                  border:"1px solid rgba(255,255,255,.1)",
                  color:"#fff",fontSize:22,
                  cursor:"pointer",fontFamily:"inherit",
                  WebkitTapHighlightColor:"transparent"}}>⌫</button>
              <button onClick={()=>handlePin("0")}
                style={{height:68,borderRadius:14,
                  background:"rgba(255,255,255,.1)",
                  border:"1px solid rgba(255,255,255,.15)",
                  color:"#fff",fontSize:26,fontWeight:500,
                  cursor:"pointer",fontFamily:"inherit",
                  WebkitTapHighlightColor:"transparent"}}>0</button>
              <div/>
            </div>
            {error&&(
              <div style={{color:C.amber,fontSize:13,textAlign:"center",marginTop:16}}>
                ⚠ {error}
              </div>
            )}
            {loading&&(
              <div style={{color:"rgba(255,255,255,.5)",fontSize:13,
                textAlign:"center",marginTop:16}}>
                Vérification…
              </div>
            )}
            <button onClick={()=>setStep("scan")} style={{
              width:"100%",marginTop:24,padding:12,
              background:"transparent",border:"none",
              color:"rgba(255,255,255,.4)",fontFamily:"inherit",
              fontSize:13,cursor:"pointer"}}>
              {"<"} Rescanner le QR code
            </button>
          </div>
        )}

        {step==="operateur"&&(
          <div>
            <div style={{textAlign:"center",marginBottom:24}}>
              <div style={{fontSize:36,marginBottom:8}}>👷</div>
              <div style={{fontSize:16,fontWeight:600}}>Opérateur terrain</div>
              <div style={{fontSize:12,color:"rgba(255,255,255,.5)",marginTop:4}}>
                Saisissez vos identifiants
              </div>
            </div>
            <div style={{marginBottom:14}}>
              <div style={{fontSize:13,fontWeight:600,color:"rgba(255,255,255,.6)",marginBottom:6}}>
                Nom
              </div>
              <input value={opNom} onChange={e=>setOpNom(e.target.value)}
                placeholder="Votre nom de famille"
                style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
                  border:"1.5px solid rgba(255,255,255,.2)",fontSize:FONT_INPUT,
                  fontFamily:"inherit",background:"rgba(255,255,255,.1)",
                  color:"#fff",outline:"none"}}/>
            </div>
            <div style={{marginBottom:20}}>
              <div style={{fontSize:13,fontWeight:600,color:"rgba(255,255,255,.6)",marginBottom:6}}>
                Code PIN
              </div>
              <input value={opPin} onChange={e=>setOpPin(e.target.value)}
                placeholder="Votre PIN"
                type="password"
                style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
                  border:"1.5px solid rgba(255,255,255,.2)",fontSize:FONT_INPUT,
                  fontFamily:"inherit",background:"rgba(255,255,255,.1)",
                  color:"#fff",outline:"none"}}/>
            </div>
            {error&&(
              <div style={{color:C.amber,fontSize:13,textAlign:"center",marginBottom:12}}>
                ⚠ {error}
              </div>
            )}
            <button onClick={handleLoginOperateur} disabled={loading} style={{
              width:"100%",height:BTN_H,borderRadius:14,
              background:loading?C.bg2:C.green,color:"#fff",
              border:"none",fontFamily:"inherit",fontSize:16,fontWeight:600,
              cursor:loading?"not-allowed":"pointer",
              WebkitTapHighlightColor:"transparent"}}>
              {loading?"Vérification…":"SE CONNECTER"}
            </button>
            <button onClick={()=>{ setError(""); setStep("scan"); }} style={{
              width:"100%",marginTop:16,padding:12,
              background:"transparent",border:"none",
              color:"rgba(255,255,255,.4)",fontFamily:"inherit",
              fontSize:13,cursor:"pointer"}}>
              {"<"} Retour
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// ── QR CODE ADMIN ─────────────────────────────────────────────
const QrCodeAdmin = ({entrepriseId, entrepriseNom, onClose}) => {
  const canvasRef = useRef(null);
  const [qrUrl, setQrUrl] = useState("");

  useEffect(()=>{
    const data = JSON.stringify({entrepriseId, nom:entrepriseNom});
    const url = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(data)}`;
    setQrUrl(url);
  },[entrepriseId, entrepriseNom]);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",
      background:C.sb,color:"#fff"}}>
      <div style={{padding:"20px 16px 16px",display:"flex",alignItems:"center",gap:12}}>
        <button onClick={onClose} style={{background:"rgba(255,255,255,.15)",
          border:"none",color:"#fff",width:36,height:36,borderRadius:9,
          cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",
          justifyContent:"center",WebkitTapHighlightColor:"transparent"}}>{"<"}</button>
        <div style={{fontSize:16,fontWeight:600}}>QR Code entreprise</div>
      </div>
      <div style={{flex:1,display:"flex",flexDirection:"column",
        alignItems:"center",justifyContent:"center",padding:24}}>
        <div style={{background:"#fff",borderRadius:20,padding:20,marginBottom:20}}>
          {qrUrl&&<img src={qrUrl} alt="QR Code" style={{width:260,height:260,display:"block"}}/>}
        </div>
        <div style={{fontSize:18,fontWeight:700,marginBottom:6}}>{entrepriseNom}</div>
        <div style={{fontSize:11,color:"rgba(255,255,255,.4)",fontFamily:"monospace",
          marginBottom:24,textAlign:"center"}}>{entrepriseId}</div>
        <div style={{fontSize:13,color:"rgba(255,255,255,.6)",textAlign:"center",lineHeight:1.6}}>
          Faites scanner ce QR code par vos collaborateurs lors de leur première connexion.
        </div>
      </div>
    </div>
  );
};

// ── FICHE 0 ───────────────────────────────────────────────────
const Fiche0 = ({onBack, onSaved, toast, contactCount, entrepriseId}) => {
  const [origine,       setOrigine]  = useState("");
  const [nomApporteur,  setApporteur]= useState("");
  const [dateContact,   setDateC]    = useState(todayS());
  const [typeContact,   setType]     = useState("proprietaire_forestier");
  const [nom,           setNom]      = useState("");
  const [prenom,        setPrenom]   = useState("");
  const [telephone,     setTel]      = useState("");
  const [email,         setEmail]    = useState("");
  const [adressePostale,setAdresse]  = useState("");
  const [commune,       setCommune]  = useState("");
  const [codePostal,    setCP]       = useState("");
  const [adresseParcelle,setParc]    = useState("");
  const [surfaceHa,     setSurface]  = useState("");
  const [refCadastrale, setRef]      = useState("");
  const [typeRessource, setRessource]= useState("");
  const [mixteDetails,  setMixteD]   = useState([]);
  const [priorite,      setPriorite] = useState("moyenne");
  const [statut,        setStatut]   = useState("nouveau");
  const [commentaire,   setComment]  = useState("");
  const [saving,  setSaving]  = useState(false);
  const [errors,  setErrors]  = useState({});

  const validate = () => {
    const e = {};
    if (!nom.trim())        e.nom = "Obligatoire";
    if (!telephone.trim())  e.telephone = "Obligatoire";
    if (!commune.trim())    e.commune = "Obligatoire";
    if (!codePostal.trim()) e.codePostal = "Obligatoire pour le n° de lot";
    if (!typeRessource)     e.typeRessource = "Sélectionner une nature";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) { toast("Compléter les champs obligatoires","warn"); return; }
    setSaving(true);
    const seq = (contactCount||0) + 1;
    const lotNumero = genLotNumero(codePostal, seq);
    const contact = {
      nom, prenom, telephone, email,
      adressePostale, commune, adresseParcelle,
      surfaceHa: surfaceHa ? parseFloat(surfaceHa) : null,
      refCadastrale, typeContact, origine, nomApporteur, dateContact,
      statut, potentiel: typeRessource==="mixte"
        ? `mixte:${mixteDetails.join(",")}`
        : typeRessource, commentaire, lotNumero,
      entrepriseId,
    };
    try {
      const res = await fetch(`${API}/contacts`, {
        method:"POST",
        headers: authHeaders(),
        body:JSON.stringify(contact),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const saved = await res.json();
      toast(`Fiche créée — ${lotNumero}`);
      onSaved(saved);
    } catch(e) {
      toast("Erreur API","warn");
    }
    setSaving(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      <div style={{background:C.purple,color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.2)",
            border:"none",color:"#fff",width:36,height:36,borderRadius:9,
            cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",
            justifyContent:"center",WebkitTapHighlightColor:"transparent"}}>{"<"}</button>
          <div>
            <div style={{fontSize:16,fontWeight:600}}>📋 Nouvelle fiche contact</div>
            <div style={{fontSize:11,opacity:.7,marginTop:2}}>
              Fiche 0 — Origine · Propriétaire · Parcelle
            </div>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:100}}>
        <SectionTitle icon="📡" label="Origine du contact"/>
        <div style={{marginBottom:14}}>
          <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Source</div>
          <GridSelect options={ORIGINE_OPTS} value={origine} onChange={setOrigine} cols={4}/>
        </div>
        <MInput label="Nom de l'apporteur" value={nomApporteur}
          onChange={setApporteur} placeholder="Personne qui a transmis l'info" hint="optionnel"/>
        <MInput label="Date du contact" value={dateContact} onChange={setDateC} type="date"/>

        <SectionTitle icon="👤" label="Propriétaire / Contact"/>
        <div style={{marginBottom:14}}>
          <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
            Type <span style={{color:"#E24B4A"}}>*</span>
          </div>
          <GridSelect options={TYPE_CONTACT_OPTS} value={typeContact} onChange={setType} cols={3}/>
        </div>
        <MInput label="Nom" value={nom} onChange={setNom}
          placeholder="Nom de famille" required error={errors.nom}/>
        <MInput label="Prénom" value={prenom} onChange={setPrenom}
          placeholder="Prénom" hint="optionnel"/>
        <MInput label="Téléphone" value={telephone} onChange={setTel}
          placeholder="06 xx xx xx xx" type="tel" required error={errors.telephone}/>
        <MInput label="Email" value={email} onChange={setEmail}
          placeholder="email@exemple.fr" type="email" hint="optionnel"/>
        <MInput label="Adresse postale" value={adressePostale} onChange={setAdresse}
          placeholder="Adresse du propriétaire" hint="optionnel"/>

        <SectionTitle icon="🌲" label="Parcelle"/>
        <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:10}}>
          <MInput label="Commune" value={commune} onChange={setCommune}
            placeholder="Nom de la commune" required error={errors.commune}/>
          <MInput label="Code postal" value={codePostal} onChange={setCP}
            placeholder="89000" required error={errors.codePostal}/>
        </div>
        <MInput label="Adresse / Lieu-dit" value={adresseParcelle} onChange={setParc}
          placeholder="Lieu-dit, chemin forestier…" hint="optionnel"/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <MInput label="Surface (ha)" value={surfaceHa} onChange={setSurface}
            placeholder="ex: 12.5" type="number" hint="optionnel"/>
          <MInput label="Réf. cadastrale" value={refCadastrale} onChange={setRef}
            placeholder="ex: B 142" hint="optionnel"/>
        </div>

        <SectionTitle icon="🪵" label="Nature du produit"/>
        {errors.typeRessource&&(
          <div style={{fontSize:12,color:C.red,marginBottom:8}}>⚠ {errors.typeRessource}</div>
        )}
        <GridSelect options={TYPE_RESSOURCE_OPTS} value={typeRessource}
          onChange={setRessource} cols={3}/>
        {typeRessource==="mixte"&&(
          <div style={{background:C.greenL,borderRadius:12,padding:14,marginBottom:14,
            border:`1px solid ${C.green}`}}>
            <div style={{fontSize:13,fontWeight:600,color:C.greenD,marginBottom:10}}>
              Détail du mixte
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {TYPE_RESSOURCE_OPTS.filter(([v])=>v!=="mixte").map(([v,emoji,label])=>{
                const checked = mixteDetails.includes(v);
                return (
                  <div key={v} onClick={()=>setMixteD(prev=>
                    checked?prev.filter(x=>x!==v):[...prev,v]
                  )} style={{
                    display:"flex",alignItems:"center",gap:8,padding:"10px 12px",
                    borderRadius:10,cursor:"pointer",
                    border:`1.5px solid ${checked?C.green:C.bd}`,
                    background:checked?C.greenL:"#fff",
                    WebkitTapHighlightColor:"transparent"}}>
                    <div style={{width:20,height:20,borderRadius:5,flexShrink:0,
                      border:`2px solid ${checked?C.green:C.bd2}`,
                      background:checked?C.green:"#fff",
                      display:"flex",alignItems:"center",justifyContent:"center"}}>
                      {checked&&<span style={{color:"#fff",fontSize:12}}>✓</span>}
                    </div>
                    <span style={{fontSize:12,color:checked?C.greenD:C.tx2}}>{emoji} {label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <SectionTitle icon="📊" label="Qualification"/>
        <div style={{marginBottom:14}}>
          <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Priorité</div>
          <GridSelect options={PRIORITE_OPTS} value={priorite} onChange={setPriorite} cols={4}/>
        </div>
        <div style={{marginBottom:14}}>
          <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Statut</div>
          <GridSelect options={STATUT_OPTS} value={statut} onChange={setStatut} cols={3}/>
        </div>
        <MInput label="Commentaire" value={commentaire} onChange={setComment}
          placeholder="Notes libres…" big hint="optionnel"/>

        {codePostal&&(
          <div style={{background:C.greenL,borderRadius:12,padding:14,marginTop:4,
            border:`1.5px solid ${C.green}`}}>
            <div style={{fontSize:12,color:C.greenD,fontWeight:600,marginBottom:4}}>
              🏷 Numéro de lot généré
            </div>
            <div style={{fontFamily:"monospace",fontSize:18,fontWeight:700,color:C.greenD}}>
              {genLotNumero(codePostal,(contactCount||0)+1)}
            </div>
          </div>
        )}
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
        <BigBtn onClick={handleSave} disabled={saving} bg={C.purple} icon={saving?"":"✅"}>
          {saving?"Enregistrement…":"CRÉER LA FICHE"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── LISTE CONTACTS ────────────────────────────────────────────
const ListeContacts = ({contacts, onNew, onNewVisite, onEdit}) => {
  const typeRessourceLabel = t => TYPE_RESSOURCE_OPTS.find(([v])=>v===t)?.[2] ?? t;
  const statutColor = s => ({
    nouveau:      {bg:C.bg2,     color:C.tx3},
    a_rappeler:   {bg:C.amberL,  color:C.amberD},
    qualifie:     {bg:C.blueL,   color:C.blueD},
    visite_prevue:{bg:C.purpleL, color:C.purpleD},
    perdu:        {bg:C.redL,    color:C.red},
  }[s] ?? {bg:C.bg2,color:C.tx2});

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      <div style={{flex:1,overflowY:"auto",padding:PADDING}}>
        {contacts.length===0 ? (
          <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
            <div style={{fontSize:40,marginBottom:12}}>📋</div>
            <div style={{fontSize:16,fontWeight:500,marginBottom:6}}>Aucune fiche</div>
            <div style={{fontSize:13}}>Créez votre première fiche contact</div>
          </div>
        ) : contacts.map(c=>{
          const sc = statutColor(c.statut);
          return (
            <div key={c.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
              borderRadius:14,padding:16,marginBottom:10}}>
              <div style={{display:"flex",justifyContent:"space-between",
                alignItems:"flex-start",marginBottom:8}}>
                <div>
                  <div style={{fontSize:15,fontWeight:700,color:C.tx}}>
                    {c.nom}{c.prenom?` ${c.prenom}`:""}
                  </div>
                  {c.lotNumero&&(
                    <div style={{fontFamily:"monospace",fontSize:11,
                      color:C.greenD,marginTop:2}}>🏷 {c.lotNumero}</div>
                  )}
                </div>
                <span style={{fontSize:10,padding:"3px 8px",borderRadius:6,
                  background:sc.bg,color:sc.color,fontWeight:600,whiteSpace:"nowrap"}}>
                  {STATUT_OPTS.find(([v])=>v===c.statut)?.[2]??c.statut}
                </span>
              </div>
              <div style={{fontSize:12,color:C.tx3,lineHeight:1.8}}>
                📞 {c.telephone}
                {c.email&&<><br/>📧 {c.email}</>}
                <br/>📍 {c.commune}{c.refCadastrale?` · ${c.refCadastrale}`:""}
                {c.surfaceHa&&<><br/>🌲 {c.surfaceHa} ha</>}
                {c.potentiel&&<><br/>🪵 {typeRessourceLabel(c.potentiel)}</>}
                {c.nomApporteur&&<><br/>🤝 Via {c.nomApporteur}</>}
              </div>
              {c.lotNumero&&(
                <div>
                  <button onClick={()=>onNewVisite(c)} style={{
                    marginTop:10,width:"100%",height:40,borderRadius:10,
                    background:C.greenL,color:C.greenD,border:`1px solid ${C.green}`,
                    fontFamily:"inherit",fontSize:13,fontWeight:600,cursor:"pointer",
                    WebkitTapHighlightColor:"transparent",
                  }}>🔭 Lancer la visite terrain</button>
                  <button onClick={()=>onEdit(c)} style={{
                    marginTop:6,width:"100%",height:40,borderRadius:10,
                    background:C.purpleL,color:C.purpleD,border:`1px solid ${C.purple}`,
                    fontFamily:"inherit",fontSize:13,fontWeight:600,cursor:"pointer",
                    WebkitTapHighlightColor:"transparent",
                  }}>✏️ Modifier la fiche</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div style={{padding:"12px 16px 24px",flexShrink:0}}>
        <BigBtn onClick={onNew} bg={C.purple} icon="📋">Nouvelle fiche contact</BigBtn>
      </div>
    </div>
  );
};

// ── VISITE TERRAIN ────────────────────────────────────────────
const MSlider = ({label,value,onChange,min,max,step=1,unit,color=C.green}) => (
  <div style={{marginBottom:14}}>
    <div style={{display:"flex",justifyContent:"space-between",
      fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
      <span>{label}</span>
      <span style={{color,fontSize:16,fontWeight:700}}>{value}{unit}</span>
    </div>
    <input type="range" min={min} max={max} step={step} value={value}
      onChange={e=>onChange(parseFloat(e.target.value))}
      style={{width:"100%",height:8,accentColor:color}}/>
    <div style={{display:"flex",justifyContent:"space-between",
      fontSize:11,color:C.tx3,marginTop:4}}>
      <span>{min}{unit}</span><span>{max}{unit}</span>
    </div>
  </div>
);

const GpsWidget = ({value,onChange,required}) => {
  const [loading,setLoading] = useState(false);
  const capture = () => {
    setLoading(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => { onChange({lat:pos.coords.latitude,lng:pos.coords.longitude,
          accuracy:pos.coords.accuracy,source:"gps"}); setLoading(false); },
        () => { onChange({lat:47.98+(Math.random()-.5)*.02,
          lng:3.09+(Math.random()-.5)*.02,source:"sim"}); setLoading(false); },
        {enableHighAccuracy:true,timeout:10000}
      );
    } else { onChange({lat:47.98,lng:3.09,source:"sim"}); setLoading(false); }
  };
  if (value) return (
    <div style={{background:C.greenL,borderRadius:12,padding:"14px",
      marginBottom:14,border:`1.5px solid ${C.green}`}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:13,color:C.greenD,fontWeight:600,marginBottom:3}}>
            📍 {value.source==="gps"?"GPS précis":"Position approximative"}
          </div>
          <div style={{fontFamily:"monospace",fontSize:13,color:C.greenD}}>
            {value.lat.toFixed(5)}°N · {value.lng.toFixed(5)}°E
          </div>
        </div>
        <button onClick={()=>onChange(null)} style={{background:"rgba(8,80,65,.15)",
          border:"none",color:C.greenD,cursor:"pointer",fontSize:20,padding:8,
          borderRadius:8,WebkitTapHighlightColor:"transparent"}}>✕</button>
      </div>
    </div>
  );
  return (
    <div style={{marginBottom:14}}>
      <BigBtn onClick={capture} bg={loading?C.bg2:C.greenL}
        color={loading?C.tx3:C.greenD} icon={loading?"":"📍"}>
        {loading?"Localisation…":"Capturer GPS"}
      </BigBtn>
    </div>
  );
};

const CheckItem = ({checked,onChange,label,sub,warn}) => (
  <div onClick={()=>onChange(!checked)} style={{display:"flex",alignItems:"flex-start",
    gap:12,padding:"12px 0",borderBottom:`0.5px solid ${C.bd}`,
    cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>
    <div style={{width:28,height:28,borderRadius:8,flexShrink:0,marginTop:1,
      border:`2px solid ${checked?(warn?C.amber:C.green):C.bd2}`,
      background:checked?(warn?C.amber:C.green):"#fff",
      display:"flex",alignItems:"center",justifyContent:"center",transition:"all .15s"}}>
      {checked&&<span style={{color:"#fff",fontSize:16,lineHeight:1}}>✓</span>}
    </div>
    <div style={{flex:1}}>
      <div style={{fontSize:15,fontWeight:checked?400:500,color:checked?C.tx2:C.tx}}>{label}</div>
      {sub&&<div style={{fontSize:12,color:C.tx3,marginTop:2}}>{sub}</div>}
    </div>
  </div>
);

const PhotosWidget = ({photos,onChange,required=2}) => {
  const addPhoto = (type) => {
    const emojis = {face:"📷",profil:"📸",zone:"🌳",acces:"🛤️",autre:"🖼️"};
    onChange([...photos,{id:uid(),type,emoji:emojis[type]||"📷",capturedAt:nowISO()}]);
  };
  return (
    <div>
      <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:10}}>
        {photos.map(p=>(
          <div key={p.id} style={{position:"relative"}}>
            <div style={{width:72,height:72,borderRadius:12,background:C.greenL,
              border:`1.5px solid ${C.green}`,display:"flex",flexDirection:"column",
              alignItems:"center",justifyContent:"center",fontSize:26}}>
              {p.emoji}
              <div style={{fontSize:9,color:C.greenD,marginTop:3}}>{p.type}</div>
            </div>
            <button onClick={()=>onChange(photos.filter(x=>x.id!==p.id))}
              style={{position:"absolute",top:-6,right:-6,width:20,height:20,
                borderRadius:"50%",background:C.red,color:"#fff",border:"2px solid #fff",
                cursor:"pointer",fontSize:10,display:"flex",alignItems:"center",
                justifyContent:"center",WebkitTapHighlightColor:"transparent"}}>✕</button>
          </div>
        ))}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:8}}>
        {[["face","📷 Face"],["profil","📸 Profil"],["zone","🌳 Zone"],
          ["acces","🛤️ Accès"],["autre","🖼️ Autre"]].map(([type,label])=>(
          <button key={type} onClick={()=>addPhoto(type)} style={{height:44,borderRadius:10,
            border:`1px solid ${C.bd}`,background:"#fff",cursor:"pointer",
            fontFamily:"inherit",fontSize:11,color:C.tx2,display:"flex",
            alignItems:"center",justifyContent:"center",gap:4,
            WebkitTapHighlightColor:"transparent"}}>{label}</button>
        ))}
      </div>
      <BigBtn onClick={()=>addPhoto("face")} bg="#111" color="#fff" icon="📷">
        Prendre une photo
      </BigBtn>
      <div style={{fontSize:12,color:photos.length>=required?C.greenD:C.amber,
        textAlign:"center",marginTop:6}}>
        {photos.length}/{required} photos{photos.length>=required?" ✓":""}
      </div>
    </div>
  );
};

const EssenceEditor = ({essences,onChange}) => {
  const LISTE = [
    ["peuplier","🌾","Peuplier"],["chene","🌳","Chêne"],["hetre","🌲","Hêtre"],
    ["charme","🌿","Charme"],["frene","🍃","Frêne"],["bouleau","🪵","Bouleau"],
    ["resineux","🎄","Résineux"],["melange","🌳","Mélange"],
  ];
  const total = essences.reduce((s,e)=>s+e.pct,0);
  const addEssence = () => {
    const used = new Set(essences.map(e=>e.id));
    const next = LISTE.find(([v])=>!used.has(v));
    if (!next) return;
    onChange([...essences,{id:next[0],emoji:next[1],label:next[2],pct:Math.max(0,100-total)}]);
  };
  return (
    <div>
      {essences.map((e,i)=>(
        <div key={e.id} style={{background:C.bg2,borderRadius:12,padding:"12px 14px",marginBottom:8}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
            <span style={{fontSize:22}}>{e.emoji}</span>
            <select value={e.id} onChange={ev=>{
              const found=LISTE.find(([v])=>v===ev.target.value);
              onChange(essences.map((x,j)=>j===i?{...x,id:ev.target.value,
                emoji:found?.[1]||"🌳",label:found?.[2]||""}:x));
            }} style={{flex:1,height:44,padding:"0 10px",borderRadius:9,
              border:`1px solid ${C.bd}`,fontSize:14,fontFamily:"inherit",
              background:"#fff",outline:"none"}}>
              {LISTE.map(([v,em,l])=><option key={v} value={v}>{em} {l}</option>)}
            </select>
            <button onClick={()=>onChange(essences.filter((_,j)=>j!==i))}
              style={{width:36,height:36,borderRadius:8,background:C.redL,
                color:C.red,border:"none",cursor:"pointer",fontSize:18,
                WebkitTapHighlightColor:"transparent"}}>✕</button>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <input type="range" min={1} max={100} value={e.pct}
              onChange={ev=>onChange(essences.map((x,j)=>j===i?{...x,pct:parseInt(ev.target.value)}:x))}
              style={{flex:1,accentColor:C.green}}/>
            <div style={{width:48,textAlign:"center",fontWeight:700,fontSize:16,color:C.green}}>
              {e.pct}%
            </div>
          </div>
        </div>
      ))}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:4}}>
        <button onClick={addEssence} style={{height:44,padding:"0 16px",borderRadius:10,
          background:C.greenL,color:C.greenD,border:"none",cursor:"pointer",
          fontFamily:"inherit",fontSize:14,fontWeight:500,
          WebkitTapHighlightColor:"transparent"}}>+ Ajouter</button>
        <div style={{fontSize:13,fontWeight:600,color:Math.abs(total-100)<=1?C.greenD:C.red}}>
          Σ {total}% {Math.abs(total-100)>1&&"⚠"}
        </div>
      </div>
    </div>
  );
};

const STEPS = [
  {id:"gps",           label:"GPS",           icon:"📍", color:C.green},
  {id:"photos",        label:"Photos",        icon:"📷", color:C.blue},
  {id:"essences",      label:"Essences",      icon:"🌿", color:C.green},
  {id:"volumes",       label:"Volumes",       icon:"📏", color:C.amber},
  {id:"contraintes",   label:"Terrain",       icon:"⚠️", color:C.red},
  {id:"acces",         label:"Accès",         icon:"🚛", color:C.brown},
  {id:"replantation",  label:"Replantation",  icon:"🌱", color:C.green},
  {id:"certification", label:"Certification", icon:"🏅", color:C.blue},
];

const FormulaireVisite = ({lot, onBack, onSaved, toast, entrepriseId}) => {
  const [step,     setStep]    = useState(0);
  const [gps,      setGps]     = useState(null);
  const [photos,   setPhotos]  = useState([]);
  const [essences, setEssences]= useState([{id:"peuplier",emoji:"🌾",label:"Peuplier",pct:100}]);
  const [volumeT,  setVolumeT] = useState(100);
  const [surfaceHa,setSurface] = useState(lot.surfaceHa||5);
  const [dateLimite,setDateL]  = useState("");
  const [observations,setObs]  = useState("");
  const [contraintes,setCont]  = useState({
    ligneEDF:false,telecom:false,penteForte:false,
    zoneHumide:false,voisinage:false,accesDifficile:false,
    routeLimitee:false,natura2000:false,remanents:false,
  });
  const [accesCamion,setAcces] = useState("praticable");
  const [largeurAcces,setLarg] = useState(4);
  const [distancePlateforme,setDist] = useState(500);
  const [saving, setSaving]    = useState(false);

  // Replantation
  const [replantation,    setReplantation]   = useState("non"); // non | oui | a_definir
  const [essenceReplanT,  setEssenceReplant] = useState("");
  const [surfaceReplant,  setSurfaceReplant] = useState(0);
  const [dateReplant,     setDateReplant]    = useState("");
  const [respReplant,     setRespReplant]    = useState("proprietaire");

  // Certification
  const [certification,   setCertification]  = useState("aucune"); // aucune | pefc | fsc | red
  const [redCategorie,    setRedCategorie]   = useState("bois_forestier");
  const [redDistance,     setRedDistance]    = useState(100);
  const [redPays,         setRedPays]        = useState("France");

  const stepValid = {
    0:!!gps, 1:photos.length>=2,
    2:essences.length>0&&Math.abs(essences.reduce((s,e)=>s+e.pct,0)-100)<=1,
    3:volumeT>0, 4:true, 5:true, 6:true, 7:true,
  };
  const allValid = Object.values(stepValid).every(Boolean);

  const handleSave = async () => {
    if (!allValid) { toast("Compléter toutes les étapes","warn"); return; }
    setSaving(true);
    const visite = {
      lotId: lot.id, lotNumero: lot.lotNumero||lot.numero,
      date: todayS(), gps, photos, essences,
      volumeEstimeT: volumeT, surfaceHa, dateLimite, observations,
      contraintes, accesCamion, largeurAcces, distancePlateforme,
      replantation, essenceReplanT, surfaceReplant, dateReplant, respReplant,
      certification, redCategorie, redDistance, redPays,
      statut:"validee", entrepriseId,
    };
    try {
      const res = await fetch(`${API}/visites`, {
        method:"POST", headers:authHeaders(), body:JSON.stringify(visite),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      toast("Visite validée ✓");
      onSaved(saved);
    } catch { toast("Erreur API","warn"); }
    setSaving(false);
  };

  const currentStep = STEPS[step];
  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      <div style={{background:currentStep.color,color:"#fff",padding:"12px 16px 10px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.2)",border:"none",
            color:"#fff",width:36,height:36,borderRadius:9,cursor:"pointer",fontSize:18,
            display:"flex",alignItems:"center",justifyContent:"center",
            WebkitTapHighlightColor:"transparent"}}>{"<"}</button>
          <div style={{flex:1}}>
            <div style={{fontSize:16,fontWeight:600}}>{currentStep.icon} {currentStep.label}</div>
            <div style={{fontSize:11,opacity:.7}}>{lot.lotNumero||lot.numero} · {lot.commune}</div>
          </div>
          <div style={{fontSize:12,opacity:.75}}>{step+1}/{STEPS.length}</div>
        </div>
        <div style={{display:"flex",gap:4}}>
          {STEPS.map((s,i)=>(
            <div key={s.id} onClick={()=>i<step&&setStep(i)} style={{flex:1,height:4,
              borderRadius:2,background:i<=step?"rgba(255,255,255,.9)":"rgba(255,255,255,.25)",
              cursor:i<step?"pointer":"default"}}/>
          ))}
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:90}}>
        {step===0&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Capturez la position GPS de la parcelle.
            </div>
            <GpsWidget value={gps} onChange={setGps} required/>
            <div style={{marginTop:16}}>
              <MInput label="Lot" value={lot.lotNumero||lot.numero} onChange={()=>{}} hint="auto"/>
              <MInput label="Date" value={todayS()} onChange={()=>{}} hint="auto"/>
            </div>
          </div>
        )}
        {step===1&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16}}>2 photos minimum.</div>
            <PhotosWidget photos={photos} onChange={setPhotos} required={2}/>
          </div>
        )}
        {step===2&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16}}>Essences. Total = 100%.</div>
            <EssenceEditor essences={essences} onChange={setEssences}/>
          </div>
        )}
        {step===3&&(
          <div>
            <MSlider label="Volume estimé" value={volumeT} onChange={setVolumeT}
              min={10} max={2000} step={10} unit=" t" color={C.amber}/>
            <MSlider label="Surface" value={surfaceHa} onChange={setSurface}
              min={0.5} max={100} step={0.5} unit=" ha" color={C.green}/>
            <MInput label="Date limite" value={dateLimite} onChange={setDateL}
              type="date" hint="optionnel"/>
            <MInput label="Observations" value={observations} onChange={setObs}
              placeholder="Notes…" big hint="optionnel"/>
          </div>
        )}
        {step===4&&(
          <div>
            <div style={{background:"#fff",border:`1px solid ${C.bd}`,borderRadius:14,
              padding:"0 14px"}}>
              {[
                {k:"ligneEDF",l:"Ligne EDF",s:"Risque abattage"},
                {k:"penteForte",l:"Pente forte >30%",s:"Débardage difficile"},
                {k:"zoneHumide",l:"Zone humide",s:"Passage restreint"},
                {k:"natura2000",l:"Natura 2000",s:"Contraintes réglementaires"},
                {k:"routeLimitee",l:"Route limitée tonnage",s:"Vérifier gabarit"},
                {k:"voisinage",l:"Voisinage sensible",s:"Bruit, horaires"},
                {k:"accesDifficile",l:"Accès difficile",s:"Chemin dégradé"},
                {k:"remanents",l:"Rémanents importants",s:"Broyage nécessaire"},
                {k:"telecom",l:"Câbles télécom",s:"Vérifier avant travaux"},
              ].map(({k,l,s})=>(
                <CheckItem key={k} checked={contraintes[k]||false}
                  onChange={v=>setCont({...contraintes,[k]:v})} label={l} sub={s} warn/>
              ))}
            </div>
            <div style={{marginTop:10,padding:"10px 14px",background:C.bg2,
              borderRadius:10,fontSize:12,color:C.tx3}}>
              {Object.values(contraintes).filter(Boolean).length} contrainte(s)
            </div>
          </div>
        )}
        {step===5&&(
          <div>
            <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
              {[["praticable","✅ Praticable","Accès normal"],
                ["difficile","⚠️ Difficile","Conditions dégradées"],
                ["impossible","🚫 Impossible","Accès interdit"]].map(([v,l,s])=>(
                <div key={v} onClick={()=>setAcces(v)} style={{padding:"14px",
                  borderRadius:12,cursor:"pointer",
                  border:`2px solid ${accesCamion===v?C.green:C.bd}`,
                  background:accesCamion===v?C.greenL:"#fff",
                  WebkitTapHighlightColor:"transparent"}}>
                  <div style={{fontSize:15,fontWeight:600,
                    color:accesCamion===v?C.greenD:C.tx}}>{l}</div>
                  <div style={{fontSize:12,color:C.tx3}}>{s}</div>
                </div>
              ))}
            </div>
            <MSlider label="Largeur" value={largeurAcces} onChange={setLarg}
              min={2} max={8} step={0.5} unit="m" color={C.brown}/>
            <MSlider label="Distance plateforme" value={distancePlateforme} onChange={setDist}
              min={100} max={5000} step={100} unit="m" color={C.blue}/>
            <div style={{background:allValid?C.greenL:C.amberL,borderRadius:14,
              padding:16,marginTop:8,border:`1.5px solid ${allValid?C.green:C.amber}`}}>
              <div style={{fontSize:13,fontWeight:700,
                color:allValid?C.greenD:C.amberD,marginBottom:10}}>
                {allValid?"✅ Visite complète":"⚠ Étapes incomplètes"}
              </div>
              {STEPS.map((s,i)=>(
                <div key={s.id} style={{display:"flex",alignItems:"center",
                  gap:8,padding:"4px 0",fontSize:12,color:stepValid[i]?C.greenD:C.red}}>
                  <span>{stepValid[i]?"✓":"✗"}</span>
                  <span>{s.icon} {s.label}</span>
                  {!stepValid[i]&&(
                    <button onClick={()=>setStep(i)} style={{marginLeft:"auto",
                      background:"none",border:"none",color:C.red,cursor:"pointer",
                      fontSize:11,textDecoration:"underline",fontFamily:"inherit"}}>
                      Compléter
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {step===6&&(
          <div>
            <SectionTitle icon="🌱" label="Replantation prévue ?"/>
            <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:16}}>
              {[["non","❌","Non","Pas de replantation prévue"],
                ["oui","✅","Oui","Replantation planifiée"],
                ["a_definir","❓","À définir","Décision ultérieure"]].map(([v,e,l,s])=>(
                <div key={v} onClick={()=>setReplantation(v)} style={{
                  padding:14,borderRadius:12,cursor:"pointer",
                  border:`2px solid ${replantation===v?C.green:C.bd}`,
                  background:replantation===v?C.greenL:"#fff",
                  WebkitTapHighlightColor:"transparent"}}>
                  <div style={{fontSize:15,fontWeight:600,
                    color:replantation===v?C.greenD:C.tx}}>{e} {l}</div>
                  <div style={{fontSize:12,color:C.tx3}}>{s}</div>
                </div>
              ))}
            </div>
            {replantation==="oui"&&(
              <div>
                <MInput label="Essence(s) à replanter" value={essenceReplanT}
                  onChange={setEssenceReplant} placeholder="Chêne, Hêtre, Douglas…"/>
                <MSlider label="Surface à replanter" value={surfaceReplant}
                  onChange={setSurfaceReplant} min={0.1} max={50} step={0.1}
                  unit=" ha" color={C.green}/>
                <MInput label="Date prévue" value={dateReplant}
                  onChange={setDateReplant} type="date"/>
                <div style={{marginBottom:14}}>
                  <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
                    Responsable
                  </div>
                  <div style={{display:"flex",gap:8}}>
                    {[["proprietaire","🏠 Propriétaire"],["etf","🪓 ETF"],["autre","👤 Autre"]].map(([v,l])=>(
                      <button key={v} onClick={()=>setRespReplant(v)} style={{
                        flex:1,padding:"10px 4px",borderRadius:10,fontSize:12,
                        border:`1.5px solid ${respReplant===v?C.green:C.bd}`,
                        background:respReplant===v?C.greenL:"#fff",cursor:"pointer",
                        fontFamily:"inherit",color:respReplant===v?C.greenD:C.tx2,
                        WebkitTapHighlightColor:"transparent"}}>
                        {l}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {step===7&&(
          <div>
            <SectionTitle icon="🏅" label="Certification"/>
            <div style={{fontSize:12,color:C.tx3,marginBottom:14,lineHeight:1.6}}>
              Optionnel — sélectionnez si ce lot est soumis à une certification forestière ou énergétique.
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:16}}>
              {[["aucune","⬜","Aucune","Pas de certification requise"],
                ["pefc","🌿","PEFC","Programme de reconnaissance des certifications forestières"],
                ["fsc","🌳","FSC","Forest Stewardship Council"],
                ["red","⚡","RED","Renewable Energy Directive (directive européenne)"]].map(([v,e,l,s])=>(
                <div key={v} onClick={()=>setCertification(v)} style={{
                  padding:14,borderRadius:12,cursor:"pointer",
                  border:`2px solid ${certification===v?C.blue:C.bd}`,
                  background:certification===v?C.blueL:"#fff",
                  WebkitTapHighlightColor:"transparent"}}>
                  <div style={{fontSize:15,fontWeight:600,
                    color:certification===v?C.blueD:C.tx}}>{e} {l}</div>
                  <div style={{fontSize:12,color:C.tx3}}>{s}</div>
                </div>
              ))}
            </div>
            {certification==="red"&&(
              <div style={{background:C.blueL,borderRadius:12,padding:14,
                border:`1px solid ${C.blue}`}}>
                <div style={{fontSize:13,fontWeight:700,color:C.blueD,marginBottom:12}}>
                  ⚡ Informations RED obligatoires
                </div>
                <div style={{marginBottom:12}}>
                  <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>
                    Catégorie biomasse
                  </div>
                  <div style={{display:"flex",flexDirection:"column",gap:6}}>
                    {[["bois_forestier","🌲 Bois forestier"],
                      ["residus","♻️ Résidus forestiers"],
                      ["dechets_bois","🗑️ Déchets bois"]].map(([v,l])=>(
                      <button key={v} onClick={()=>setRedCategorie(v)} style={{
                        padding:"10px 14px",borderRadius:10,textAlign:"left",
                        border:`1.5px solid ${redCategorie===v?C.blue:C.bd}`,
                        background:redCategorie===v?"#fff":C.bg,
                        cursor:"pointer",fontFamily:"inherit",fontSize:13,
                        color:redCategorie===v?C.blueD:C.tx2,
                        WebkitTapHighlightColor:"transparent"}}>
                        {l}
                      </button>
                    ))}
                  </div>
                </div>
                <MSlider label="Distance chaufferie estimée" value={redDistance}
                  onChange={setRedDistance} min={10} max={500} step={10}
                  unit=" km" color={C.blue}/>
                <MInput label="Pays d&apos;origine" value={redPays}
                  onChange={setRedPays} placeholder="France"/>
                <div style={{fontSize:11,color:C.blueD,marginTop:8,padding:8,
                  background:"rgba(255,255,255,.6)",borderRadius:8}}>
                  ℹ️ Le GPS de la parcelle et les tonnages serviront à générer l&apos;auto-déclaration RED lors de la livraison.
                </div>
              </div>
            )}
          </div>
        )}
        {step>0&&(
          <button onClick={()=>setStep(s=>s-1)} style={{height:BTN_H,padding:"0 20px",
            borderRadius:14,background:C.bg2,color:C.tx2,border:"none",
            fontFamily:"inherit",fontSize:15,fontWeight:500,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>{"<"} Retour</button>
        )}
        {step<STEPS.length-1 ? (
          <BigBtn onClick={()=>setStep(s=>s+1)}
            bg={stepValid[step]?currentStep.color:C.amber} style={{flex:1}}>
            {STEPS[step+1].icon} {STEPS[step+1].label}
          </BigBtn>
        ) : (
          <BigBtn onClick={handleSave} bg={allValid?C.green:C.bg2}
            disabled={saving} style={{flex:1}} icon={saving?"":"✅"}>
            {saving?"Enregistrement…":"VALIDER LA VISITE"}
          </BigBtn>
        )}
      </div>
    </div>
  );
};

const ListeVisites = ({visites}) => (
  <div style={{flex:1,overflowY:"auto",padding:PADDING}}>
    {visites.length===0 ? (
      <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
        <div style={{fontSize:40,marginBottom:12}}>🔭</div>
        <div style={{fontSize:16,fontWeight:500}}>Aucune visite</div>
        <div style={{fontSize:13,marginTop:6}}>Lancez une visite depuis une fiche contact</div>
      </div>
    ) : visites.map(v=>(
      <div key={v.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
        borderRadius:14,padding:16,marginBottom:10}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
          <div style={{fontSize:14,fontWeight:600}}>{v.lotNumero}</div>
          <div style={{fontSize:11,padding:"3px 8px",borderRadius:6,
            background:C.greenL,color:C.greenD,fontWeight:500}}>✅ Validée</div>
        </div>
        <div style={{fontSize:12,color:C.tx3,lineHeight:1.7}}>
          📅 {v.date} · 📦 {v.volumeEstimeT}t · {v.surfaceHa}ha<br/>
          🚛 Accès {v.accesCamion}
          {Array.isArray(v.photos)&&v.photos.length>0&&
            <span> · 📷 {v.photos.length} photo{v.photos.length>1?"s":""}</span>}
        </div>
      </div>
    ))}
  </div>
);

// ── APP ────────────────────────────────────────────────────────
// ── ÉCRAN RELEVÉS ─────────────────────────────────────────────
const EcranReleves = ({entrepriseId, user, toast, notifications=[], setNotifications}) => {
  const [sousOnglet, setSousOnglet] = useState("operateurs");
  const [operateurs, setOperateurs] = useState([]);
  const [acces, setAcces] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [showNewAcces, setShowNewAcces] = useState(false);
  const [opNom, setOpNom] = useState("");
  const [opPrenom, setOpPrenom] = useState("");
  const [opEtfNom, setOpEtfNom] = useState("");
  const [opPin, setOpPin] = useState("");
  const [opSaving, setOpSaving] = useState(false);
  const [selOp, setSelOp] = useState(null);
  const [assignLotId, setAssignLotId] = useState("");
  const [assignLotNumero, setAssignLotNumero] = useState("");
  const [assignType, setAssignType] = useState("abattage");
  const [assignSaving, setAssignSaving] = useState(false);
  const [lotId, setLotId] = useState("");
  const [lotNumero, setLotNumero] = useState("");
  const [etfNom, setEtfNom] = useState("");
  const [etfContact, setEtfContact] = useState("");
  const [typeOperation, setTypeOperation] = useState("abattage");
  const [accesSaving, setAccesSaving] = useState(false);

  useEffect(()=>{
    fetch(`${API}/operateurs/entreprise/${entrepriseId}`,{headers:authHeaders()})
      .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setOperateurs(d); }).catch(()=>{});
    fetch(`${API}/acces-lot/entreprise/${entrepriseId}`,{headers:authHeaders()})
      .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setAcces(d); }).catch(()=>{});
    fetch(`${API}/contacts`,{headers:authHeaders()})
      .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setContacts(d); }).catch(()=>{});
  },[]);

  const handleCreateOp = async () => {
    if (!opNom||!opEtfNom||!opPin) { toast("Remplir nom, ETF et PIN","warn"); return; }
    setOpSaving(true);
    try {
      const res = await fetch(`${API}/operateurs`,{
        method:"POST",headers:authHeaders(),
        body:JSON.stringify({nom:opNom,prenom:opPrenom,etfNom:opEtfNom,pin:opPin,entrepriseId}),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      setOperateurs(prev=>[{...saved,assignations:[]},...prev]);
      setShowNew(false);
      setOpNom(""); setOpPrenom(""); setOpEtfNom(""); setOpPin("");
      toast(`Opérateur ${saved.nom} créé ✓`);
    } catch { toast("Erreur API","warn"); }
    setOpSaving(false);
  };

  const handleAssigner = async () => {
    if (!assignLotId||!selOp) return;
    setAssignSaving(true);
    try {
      const res = await fetch(`${API}/operateurs/${selOp.id}/assigner`,{
        method:"POST",headers:authHeaders(),
        body:JSON.stringify({lotId:assignLotId,lotNumero:assignLotNumero,typeOperation:assignType}),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      setOperateurs(prev=>prev.map(op=>op.id===selOp.id?
        {...op,assignations:[...(op.assignations||[]),saved]}:op));
      setSelOp(null);
      setAssignLotId(""); setAssignLotNumero("");
      toast("Lot assigné ✓");
    } catch { toast("Erreur API","warn"); }
    setAssignSaving(false);
  };

  const handleCreateAcces = async () => {
    if (!lotId||!etfNom) { toast("Sélectionnez un lot et saisissez l\'ETF","warn"); return; }
    setAccesSaving(true);
    try {
      const res = await fetch(`${API}/acces-lot`,{
        method:"POST",headers:authHeaders(),
        body:JSON.stringify({lotId,lotNumero,entrepriseId,etfNom,etfContact,typeOperation}),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      setAcces(prev=>[saved,...prev]);
      setShowNewAcces(false);
      setEtfNom(""); setEtfContact(""); setLotId(""); setLotNumero("");
      toast(`Code créé : ${saved.code}`);
    } catch { toast("Erreur API","warn"); }
    setAccesSaving(false);
  };

  const handleDesactiver = async (id) => {
    try {
      await fetch(`${API}/acces-lot/${id}/desactiver`,{method:"PATCH",headers:authHeaders()});
      setAcces(prev=>prev.map(a=>a.id===id?{...a,actif:false}:a));
      toast("Accès désactivé");
    } catch { toast("Erreur","warn"); }
  };

  const typeLabel = t=>({"abattage":"🪓 Abattage","debardage":"🚜 Débardage","broyage":"🌿 Broyage"}[t]||t);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      <div style={{display:"flex",gap:0,padding:"8px 16px 0",background:"#fff",
        borderBottom:`1px solid ${C.bd}`,flexShrink:0}}>
        {[["operateurs","👷 Opérateurs"],["acces","🔑 Accès lot"],["notifs","🔔 Alertes"]].map(([id,label])=>(
          <button key={id} onClick={()=>{ setSousOnglet(id); setShowNew(false); setShowNewAcces(false); setSelOp(null); }} style={{
            flex:1,height:36,background:"transparent",border:"none",
            borderBottom:`2.5px solid ${sousOnglet===id?C.green:"transparent"}`,
            color:sousOnglet===id?C.greenD:C.tx3,fontFamily:"inherit",
            fontSize:13,fontWeight:sousOnglet===id?700:400,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>
            {label}
          </button>
        ))}
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING}}>
        {sousOnglet==="operateurs"&&(
          <div>
            {selOp ? (
              <div>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}>
                  <button onClick={()=>setSelOp(null)} style={{background:"none",border:"none",
                    fontSize:20,cursor:"pointer",color:C.tx2}}>{"<"}</button>
                  <div style={{fontSize:15,fontWeight:700}}>Assigner un lot à {selOp.nom}</div>
                </div>
                <div style={{marginBottom:14}}>
                  <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Lot</div>
                  <select value={assignLotId} onChange={e=>{
                    const c=contacts.find(x=>x.id===e.target.value);
                    setAssignLotId(e.target.value);
                    setAssignLotNumero(c?.lotNumero||"");
                  }} style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
                    border:`1.5px solid ${C.bd}`,fontSize:FONT_INPUT,fontFamily:"inherit",
                    background:"#fff",color:C.tx,outline:"none"}}>
                    <option value="">— Sélectionner un lot —</option>
                    {contacts.filter(c=>c.lotNumero).map(c=>(
                      <option key={c.id} value={c.id}>{c.lotNumero} · {c.nom} · {c.commune}</option>
                    ))}
                  </select>
                </div>
                <div style={{marginBottom:14}}>
                  <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Type</div>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                    {[["abattage","🪓","Abattage"],["debardage","🚜","Débardage"],["broyage","🌿","Broyage"]].map(([v,e,l])=>(
                      <button key={v} onClick={()=>setAssignType(v)} style={{
                        padding:"12px 6px",borderRadius:12,
                        border:`1.5px solid ${assignType===v?C.green:C.bd}`,
                        background:assignType===v?C.greenL:"#fff",cursor:"pointer",
                        fontFamily:"inherit",display:"flex",flexDirection:"column",
                        alignItems:"center",gap:4,WebkitTapHighlightColor:"transparent"}}>
                        <span style={{fontSize:22}}>{e}</span>
                        <span style={{fontSize:11,fontWeight:assignType===v?600:400,
                          color:assignType===v?C.greenD:C.tx2}}>{l}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div style={{display:"flex",gap:10}}>
                  <button onClick={()=>setSelOp(null)} style={{flex:1,height:BTN_H,borderRadius:14,
                    background:C.bg2,color:C.tx2,border:"none",fontFamily:"inherit",
                    fontSize:15,cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>Annuler</button>
                  <BigBtn onClick={handleAssigner} disabled={assignSaving} style={{flex:2}}
                    bg={C.green} icon={assignSaving?"":"✅"}>
                    {assignSaving?"Assignation…":"ASSIGNER"}
                  </BigBtn>
                </div>
              </div>
            ) : showNew ? (
              <div>
                <SectionTitle icon="👷" label="Nouvel opérateur"/>
                <MInput label="Nom" value={opNom} onChange={setOpNom} placeholder="Nom" required/>
                <MInput label="Prénom" value={opPrenom} onChange={setOpPrenom} placeholder="Prénom" hint="optionnel"/>
                <MInput label="Entreprise ETF" value={opEtfNom} onChange={setOpEtfNom} placeholder="Nom ETF" required/>
                <MInput label="Code PIN" value={opPin} onChange={setOpPin} placeholder="4 chiffres" type="number" required/>
                <div style={{background:C.amberL,borderRadius:12,padding:12,marginBottom:14,
                  fontSize:12,color:C.amberD}}>
                  ⚠ Communiquez ce PIN directement à l'opérateur.
                </div>
                <div style={{display:"flex",gap:10}}>
                  <button onClick={()=>setShowNew(false)} style={{flex:1,height:BTN_H,borderRadius:14,
                    background:C.bg2,color:C.tx2,border:"none",fontFamily:"inherit",
                    fontSize:15,cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>Annuler</button>
                  <BigBtn onClick={handleCreateOp} disabled={opSaving} style={{flex:2}}
                    bg={C.green} icon={opSaving?"":"👷"}>
                    {opSaving?"Création…":"CRÉER"}
                  </BigBtn>
                </div>
              </div>
            ) : (
              <div>
                {operateurs.length===0 ? (
                  <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
                    <div style={{fontSize:40,marginBottom:12}}>👷</div>
                    <div style={{fontSize:16,fontWeight:500,marginBottom:6}}>Aucun opérateur</div>
                    <div style={{fontSize:13}}>Créez un opérateur pour lui assigner des lots</div>
                  </div>
                ) : operateurs.map(op=>(
                  <div key={op.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
                    borderRadius:14,padding:16,marginBottom:10}}>
                    <div style={{display:"flex",justifyContent:"space-between",
                      alignItems:"flex-start",marginBottom:8}}>
                      <div>
                        <div style={{fontSize:15,fontWeight:700}}>{op.nom}{op.prenom?` ${op.prenom}`:""}</div>
                        <div style={{fontSize:12,color:C.tx3,marginTop:2}}>{op.etfNom}</div>
                      </div>
                      <span style={{fontSize:10,padding:"3px 8px",borderRadius:6,
                        background:op.actif?C.greenL:C.bg2,color:op.actif?C.greenD:C.tx3,fontWeight:600}}>
                        {op.actif?"✅ Actif":"❌ Inactif"}
                      </span>
                    </div>
                    {op.assignations&&op.assignations.length>0&&(
                      <div style={{marginBottom:10}}>
                        {op.assignations.map(a=>(
                          <div key={a.id} style={{display:"flex",alignItems:"center",gap:8,
                            padding:"6px 10px",borderRadius:8,background:C.bg2,marginBottom:4,fontSize:12}}>
                            <span>{typeLabel(a.typeOperation)}</span>
                            <span style={{fontFamily:"monospace",color:C.greenD,flex:1}}>{a.lotNumero}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <button onClick={()=>setSelOp(op)} style={{width:"100%",height:38,borderRadius:10,
                      background:C.blueL,color:C.blueD,border:`1px solid ${C.blue}`,
                      fontFamily:"inherit",fontSize:13,fontWeight:600,cursor:"pointer",
                      WebkitTapHighlightColor:"transparent"}}>+ Assigner un lot</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {sousOnglet==="acces"&&(
          <div>
            {showNewAcces ? (
              <div>
                <SectionTitle icon="🔑" label="Nouvel accès lot"/>
                <div style={{marginBottom:14}}>
                  <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Lot</div>
                  <select value={lotId} onChange={e=>{
                    const c=contacts.find(x=>x.id===e.target.value);
                    setLotId(e.target.value);
                    setLotNumero(c?.lotNumero||"");
                  }} style={{width:"100%",height:INPUT_H,padding:"0 14px",borderRadius:12,
                    border:`1.5px solid ${C.bd}`,fontSize:FONT_INPUT,fontFamily:"inherit",
                    background:"#fff",color:C.tx,outline:"none"}}>
                    <option value="">— Sélectionner —</option>
                    {contacts.filter(c=>c.lotNumero).map(c=>(
                      <option key={c.id} value={c.id}>{c.lotNumero} · {c.nom} · {c.commune}</option>
                    ))}
                  </select>
                </div>
                <div style={{marginBottom:14}}>
                  <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Type</div>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                    {[["abattage","🪓","Abattage"],["debardage","🚜","Débardage"],["broyage","🌿","Broyage"]].map(([v,e,l])=>(
                      <button key={v} onClick={()=>setTypeOperation(v)} style={{
                        padding:"12px 6px",borderRadius:12,
                        border:`1.5px solid ${typeOperation===v?C.green:C.bd}`,
                        background:typeOperation===v?C.greenL:"#fff",cursor:"pointer",
                        fontFamily:"inherit",display:"flex",flexDirection:"column",
                        alignItems:"center",gap:4,WebkitTapHighlightColor:"transparent"}}>
                        <span style={{fontSize:22}}>{e}</span>
                        <span style={{fontSize:11,fontWeight:typeOperation===v?600:400,
                          color:typeOperation===v?C.greenD:C.tx2}}>{l}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <MInput label="Nom ETF" value={etfNom} onChange={setEtfNom} placeholder="Nom ETF" required/>
                <MInput label="Contact" value={etfContact} onChange={setEtfContact}
                  placeholder="06 xx ou email@..." hint="Pour envoi"/>
                <div style={{display:"flex",gap:10}}>
                  <button onClick={()=>setShowNewAcces(false)} style={{flex:1,height:BTN_H,borderRadius:14,
                    background:C.bg2,color:C.tx2,border:"none",fontFamily:"inherit",
                    fontSize:15,cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>Annuler</button>
                  <BigBtn onClick={handleCreateAcces} disabled={accesSaving} style={{flex:2}}
                    bg={C.green} icon={accesSaving?"":"🔑"}>
                    {accesSaving?"Création…":"CRÉER L'ACCÈS"}
                  </BigBtn>
                </div>
              </div>
            ) : (
              <div>
                {acces.length===0 ? (
                  <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
                    <div style={{fontSize:40,marginBottom:12}}>🔑</div>
                    <div style={{fontSize:16,fontWeight:500,marginBottom:6}}>Aucun accès</div>
                    <div style={{fontSize:13}}>Créez un accès code pour une ETF</div>
                  </div>
                ) : acces.map(a=>(
                  <div key={a.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
                    borderRadius:14,padding:16,marginBottom:10}}>
                    <div style={{display:"flex",justifyContent:"space-between",
                      alignItems:"flex-start",marginBottom:8}}>
                      <div>
                        <div style={{fontSize:15,fontWeight:700}}>{a.etfNom}</div>
                        <div style={{fontFamily:"monospace",fontSize:11,color:C.greenD,marginTop:2}}>🏷 {a.lotNumero}</div>
                      </div>
                      <span style={{fontSize:10,padding:"3px 8px",borderRadius:6,fontWeight:600,
                        background:a.actif?C.greenL:C.bg2,color:a.actif?C.greenD:C.tx3}}>
                        {a.actif?"✅ Actif":"❌ Désactivé"}
                      </span>
                    </div>
                    <div style={{fontSize:12,color:C.tx3,lineHeight:1.8}}>
                      {typeLabel(a.typeOperation)}{a.etfContact&&<><br/>{a.etfContact}</>}<br/>
                      📅 Expire le {new Date(a.expiresAt).toLocaleDateString("fr-FR")}
                    </div>
                    <div style={{marginTop:10,background:C.amberL,borderRadius:10,
                      padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div>
                        <div style={{fontSize:11,color:C.amberD,fontWeight:600,marginBottom:2}}>Code</div>
                        <div style={{fontFamily:"monospace",fontSize:24,fontWeight:700,
                          color:C.amberD,letterSpacing:4}}>{a.code}</div>
                      </div>
                      {a.actif&&(
                        <button onClick={()=>handleDesactiver(a.id)} style={{padding:"8px 12px",
                          borderRadius:8,background:C.redL,color:C.red,border:"none",
                          fontFamily:"inherit",fontSize:12,cursor:"pointer",fontWeight:500,
                          WebkitTapHighlightColor:"transparent"}}>Désactiver</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {sousOnglet==="operateurs"&&!showNew&&!selOp&&(
        <div style={{padding:"12px 16px 24px",flexShrink:0}}>
          <BigBtn onClick={()=>setShowNew(true)} bg={C.green} icon="👷">Nouvel opérateur</BigBtn>
        </div>
      )}
      {sousOnglet==="notifs"&&(
          <div>
            {notifications.length===0 ? (
              <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
                <div style={{fontSize:40,marginBottom:12}}>🔔</div>
                <div style={{fontSize:16,fontWeight:500}}>Aucune notification</div>
              </div>
            ) : notifications.map(n=>(
              <div key={n.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
                borderRadius:14,padding:16,marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                  <div style={{fontSize:14,fontWeight:700,color:C.tx}}>{n.titre}</div>
                  <div style={{fontSize:10,color:C.tx3}}>
                    {new Date(n.createdAt).toLocaleString('fr-FR')}
                  </div>
                </div>
                <div style={{fontSize:13,color:C.tx2,marginBottom:10}}>{n.message}</div>
                <button onClick={async()=>{
                  await fetch(`${API}/notifications/${n.id}/lu`,{method:"PATCH",headers:authHeaders()});
                  setNotifications(prev=>prev.filter(x=>x.id!==n.id));
                }} style={{width:"100%",height:36,borderRadius:8,
                  background:C.bg2,color:C.tx2,border:"none",
                  fontFamily:"inherit",fontSize:12,cursor:"pointer",
                  WebkitTapHighlightColor:"transparent"}}>
                  ✓ Marquer comme lu
                </button>
              </div>
            ))}
          </div>
        )}
      {sousOnglet==="acces"&&!showNewAcces&&(
        <div style={{padding:"12px 16px 24px",flexShrink:0}}>
          <BigBtn onClick={()=>setShowNewAcces(true)} bg={C.green} icon="🔑">Créer un accès lot</BigBtn>
        </div>
      )}
    </div>
  );
};

// ── FICHE EDIT ────────────────────────────────────────────────
const CHAMP_LABELS = {
  nom:"Nom", prenom:"Prénom", telephone:"Téléphone", email:"Email",
  adressePostale:"Adresse postale", commune:"Commune",
  adresseParcelle:"Adresse parcelle", surfaceHa:"Surface (ha)",
  refCadastrale:"Réf. cadastrale", typeContact:"Type contact",
  origine:"Origine", nomApporteur:"Apporteur", dateContact:"Date contact",
  statut:"Statut", potentiel:"Nature produit", commentaire:"Commentaire",
  estPersonneMorale:"Personne morale", typePersonneMorale:"Type structure",
  numeroSiret:"SIRET", nomSignataire:"Signataire", qualiteSignataire:"Qualité signataire",
};

const Fiche0Edit = ({contact, onBack, onSaved, toast, user, onLaunchVisite, onLaunchValidation, onLaunchCloture, onLaunchDechiquetage, onLaunchTransporteur, onLaunchLivraison}) => {
  const [nom,           setNom]      = useState(contact.nom||"");
  const [prenom,        setPrenom]   = useState(contact.prenom||"");
  const [telephone,     setTel]      = useState(contact.telephone||"");
  const [email,         setEmail]    = useState(contact.email||"");
  const [adressePostale,setAdresse]  = useState(contact.adressePostale||"");
  const [commune,       setCommune]  = useState(contact.commune||"");
  const [adresseParcelle,setParc]    = useState(contact.adresseParcelle||"");
  const [surfaceHa,     setSurface]  = useState(contact.surfaceHa||"");
  const [refCadastrale, setRef]      = useState(contact.refCadastrale||"");
  const [typeContact,   setType]     = useState(contact.typeContact||"proprietaire_forestier");
  const [origine,       setOrigine]  = useState(contact.origine||"");
  const [nomApporteur,  setApporteur]= useState(contact.nomApporteur||"");
  const [dateContact,   setDateC]    = useState(contact.dateContact||todayS());
  const [statut,        setStatut]   = useState(contact.statut||"nouveau");
  const [potentiel,     setPotentiel]= useState(contact.potentiel||"");
  const [commentaire,   setComment]  = useState(contact.commentaire||"");
  const [estPersonneMorale,setEstPM] = useState(contact.estPersonneMorale||false);
  const [typePersonneMorale,setTypePM]=useState(contact.typePersonneMorale||"");
  const [numeroSiret,   setSiret]    = useState(contact.numeroSiret||"");
  const [nomSignataire, setSignataire]=useState(contact.nomSignataire||"");
  const [qualiteSignataire,setQualite]=useState(contact.qualiteSignataire||"");
  const [saving, setSaving] = useState(false);
  const [showHistorique, setShowHistorique] = useState(false);
  const [historique, setHistorique] = useState([]);

  useEffect(()=>{
    if (showHistorique) {
      fetch(`${API}/contacts/${contact.id}/historique`, {headers:authHeaders()})
        .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setHistorique(d); }).catch(()=>{});
    }
  },[showHistorique]);

  const handleSave = async () => {
    setSaving(true);
    const data = {
      nom, prenom, telephone, email, adressePostale,
      commune, adresseParcelle,
      surfaceHa: surfaceHa ? parseFloat(surfaceHa) : null,
      refCadastrale, typeContact, origine, nomApporteur, dateContact,
      statut, potentiel, commentaire,
      estPersonneMorale, typePersonneMorale, numeroSiret,
      nomSignataire, qualiteSignataire,
      operateur: user?.nom || "inconnu",
    };
    try {
      const res = await fetch(`${API}/contacts/${contact.id}`, {
        method:"PATCH",
        headers: authHeaders(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      toast("Fiche mise à jour ✓");
      onSaved(saved);
    } catch {
      toast("Erreur API","warn");
    }
    setSaving(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      <div style={{background:C.purple,color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.2)",
            border:"none",color:"#fff",width:36,height:36,borderRadius:9,
            cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",
            justifyContent:"center",WebkitTapHighlightColor:"transparent"}}>{"<"}</button>
          <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:14,fontWeight:600}}>✏️ Modifier</div>
              <div style={{fontSize:10,opacity:.7,marginTop:1,overflow:"hidden",
                textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                {contact.lotNumero}
              </div>
            </div>
          <button onClick={()=>setShowHistorique(v=>!v)} style={{
            background:"rgba(255,255,255,.15)",border:"none",color:"#fff",
            padding:"6px 8px",borderRadius:8,fontSize:11,cursor:"pointer",
            WebkitTapHighlightColor:"transparent",whiteSpace:"nowrap"}}>
            🕐
          </button>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:100}}>

        {showHistorique ? (
          <div>
            <SectionTitle icon="🕐" label="Historique des modifications"/>
            {historique.length===0 ? (
              <div style={{textAlign:"center",padding:"32px 0",color:C.tx3,fontSize:13}}>
                Aucune modification enregistrée
              </div>
            ) : historique.map(h=>(
              <div key={h.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
                borderRadius:12,padding:12,marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{fontSize:13,fontWeight:600,color:C.tx}}>
                    {CHAMP_LABELS[h.champ]||h.champ}
                  </span>
                  <span style={{fontSize:11,color:C.tx3}}>
                    {new Date(h.createdAt).toLocaleString('fr-FR')}
                  </span>
                </div>
                <div style={{fontSize:12,color:C.tx3}}>
                  <span style={{color:C.red}}>— {h.ancienneVal||"(vide)"}</span>
                  {" > "}
                  <span style={{color:C.greenD}}>+ {h.nouvelleVal||"(vide)"}</span>
                </div>
                <div style={{fontSize:11,color:C.tx3,marginTop:4}}>
                  👤 {h.operateur}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div>
            {/* Menu Actions — contextuels selon statut */}
            {contact.lotNumero&&(()=>{
              const s = contact.statutLot||"NOUVEAU";
              const showVisite      = ["NOUVEAU","VISITE_PREVUE","VISITE_REALISEE"].includes(s)||!s;
              const showValider     = ["VISITE_REALISEE","VALIDE_EXPLOITATION"].includes(s);
              const showCloture     = ["VALIDE_EXPLOITATION","EN_COURS_EXPLOITATION"].includes(s);
              const showDechi       = ["BORD_ROUTE","A_DECHIQUETER"].includes(s);
              const showTransp      = ["A_DECHIQUETER","EN_COURS_BROYAGE","EN_LIVRAISON"].includes(s);
              const showLivraison   = ["EN_COURS_BROYAGE","EN_LIVRAISON"].includes(s);
              const btns = [
                showVisite    && {icon:"🔭",label:"Visite",    bg:C.greenL, bd:C.green,  color:C.greenD,  action:onLaunchVisite},
                showValider   && {icon:"✅",label:"Valider",   bg:C.blueL,  bd:C.blue,   color:C.blueD,   action:onLaunchValidation},
                showCloture   && {icon:"🏁",label:"Clôture",   bg:C.amberL, bd:C.amber,  color:C.amberD,  action:onLaunchCloture},
                showDechi     && {icon:"🪚",label:"Déchi.",    bg:"#FAECE7",bd:"#D85A30", color:"#D85A30", action:onLaunchDechiquetage},
                showTransp    && {icon:"🚛",label:"Transp.",   bg:C.purpleL,bd:C.purple,  color:C.purpleD, action:onLaunchTransporteur},
                showLivraison && {icon:"📦",label:"Livraison", bg:C.greenL, bd:C.green,  color:C.greenD,  action:onLaunchLivraison},
              ].filter(Boolean);
              if (!btns.length) return null;
              const cols = btns.length <= 3 ? btns.length : 4;
              return (
                <div style={{display:"grid",gridTemplateColumns:`repeat(${cols},1fr)`,
                  gap:8,marginBottom:16}}>
                  {btns.map((b,i)=>(
                    <button key={i} onClick={b.action} style={{
                      height:60,borderRadius:12,background:b.bg,
                      border:`1.5px solid ${b.bd}`,color:b.color,
                      fontFamily:"inherit",fontSize:11,fontWeight:600,cursor:"pointer",
                      display:"flex",flexDirection:"column",alignItems:"center",
                      justifyContent:"center",gap:3,WebkitTapHighlightColor:"transparent"}}>
                      <span style={{fontSize:20}}>{b.icon}</span>
                      <span>{b.label}</span>
                    </button>
                  ))}
                </div>
              );
            })()}
            <SectionTitle icon="👤" label="Propriétaire / Contact"/>
            <GridSelect options={TYPE_CONTACT_OPTS} value={typeContact} onChange={setType} cols={3}/>
            <MInput label="Nom" value={nom} onChange={setNom} required placeholder="Nom"/>
            <MInput label="Prénom" value={prenom} onChange={setPrenom} placeholder="Prénom" hint="optionnel"/>
            <MInput label="Téléphone" value={telephone} onChange={setTel} type="tel" required placeholder="06..."/>
            <MInput label="Email" value={email} onChange={setEmail} type="email" hint="optionnel" placeholder="email@..."/>
            <MInput label="Adresse postale" value={adressePostale} onChange={setAdresse} hint="optionnel" placeholder="Adresse"/>

            <SectionTitle icon="🌲" label="Parcelle"/>
            <MInput label="Commune" value={commune} onChange={setCommune} required placeholder="Commune"/>
            <MInput label="Adresse / Lieu-dit" value={adresseParcelle} onChange={setParc} hint="optionnel" placeholder="Lieu-dit..."/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <MInput label="Surface (ha)" value={surfaceHa} onChange={setSurface} type="number" hint="optionnel" placeholder="ex: 12.5"/>
              <MInput label="Réf. cadastrale" value={refCadastrale} onChange={setRef} hint="optionnel" placeholder="ex: B 142"/>
            </div>

            <div onClick={()=>setEstPM(v=>!v)} style={{
              display:"flex",alignItems:"center",justifyContent:"space-between",
              padding:"14px",borderRadius:12,marginBottom:14,
              background:estPersonneMorale?C.purpleL:"#fff",
              border:`1.5px solid ${estPersonneMorale?C.purple:C.bd}`,
              cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>
              <div>
                <div style={{fontSize:15,fontWeight:600,color:estPersonneMorale?C.purpleD:C.tx}}>
                  🏢 Personne morale
                </div>
                <div style={{fontSize:12,color:C.tx3,marginTop:2}}>Société, coopérative…</div>
              </div>
              <div style={{width:44,height:26,borderRadius:13,
                background:estPersonneMorale?C.purple:"#ccc",position:"relative"}}>
                <div style={{position:"absolute",top:3,
                  left:estPersonneMorale?20:3,width:20,height:20,
                  borderRadius:"50%",background:"#fff",transition:"left .2s"}}/>
              </div>
            </div>
            {estPersonneMorale&&(
              <div style={{background:C.purpleL,borderRadius:12,padding:14,marginBottom:14,
                border:`1px solid ${C.purple}`}}>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:14}}>
                  {[["SCI","SCI"],["SARL","SARL"],["SAS","SAS"],["SA","SA"],["EARL","EARL"],
                    ["cooperative","Coopérative"],["groupement_forestier","GF"],
                    ["collectivite","Collectivité"],["commune","Commune"],["onf","ONF"],
                  ].map(([v,l])=>(
                    <button key={v} onClick={()=>setTypePM(v)} style={{
                      padding:"8px 4px",borderRadius:8,fontSize:11,fontWeight:500,
                      border:`1.5px solid ${typePersonneMorale===v?C.purple:C.bd}`,
                      background:typePersonneMorale===v?C.purple:"#fff",
                      color:typePersonneMorale===v?"#fff":C.tx2,
                      cursor:"pointer",fontFamily:"inherit",
                      WebkitTapHighlightColor:"transparent"}}>
                      {l}
                    </button>
                  ))}
                </div>
                <MInput label="N° SIRET / RNA" value={numeroSiret} onChange={setSiret} placeholder="14 chiffres" hint="optionnel"/>
                <MInput label="Nom du signataire" value={nomSignataire} onChange={setSignataire} placeholder="Nom Prénom"/>
                <MInput label="Qualité" value={qualiteSignataire} onChange={setQualite} placeholder="Gérant, Président…"/>
              </div>
            )}

            <SectionTitle icon="📡" label="Origine"/>
            <GridSelect options={ORIGINE_OPTS} value={origine} onChange={setOrigine} cols={4}/>
            <MInput label="Apporteur" value={nomApporteur} onChange={setApporteur} hint="optionnel" placeholder="Nom apporteur"/>
            <MInput label="Date contact" value={dateContact} onChange={setDateC} type="date"/>

            <SectionTitle icon="🪵" label="Nature du produit"/>
            <GridSelect options={TYPE_RESSOURCE_OPTS} value={potentiel} onChange={setPotentiel} cols={3}/>

            <SectionTitle icon="📊" label="Qualification"/>
            <div style={{marginBottom:14}}>
              <div style={{fontSize:13,fontWeight:600,color:C.tx2,marginBottom:8}}>Statut</div>
              <GridSelect options={STATUT_OPTS} value={statut} onChange={setStatut} cols={3}/>
            </div>
            <MInput label="Commentaire" value={commentaire} onChange={setComment}
              placeholder="Notes libres…" big hint="optionnel"/>
          </div>
        )}
      </div>

      {!showHistorique&&(
        <div style={{position:"fixed",bottom:0,left:0,right:0,
          padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
          <BigBtn onClick={handleSave} disabled={saving} bg={C.purple} icon={saving?"":"💾"}>
            {saving?"Enregistrement…":"SAUVEGARDER"}
          </BigBtn>
        </div>
      )}
    </div>
  );
};

// ── ÉCRAN OPÉRATEUR TERRAIN ───────────────────────────────────
const EcranOperateur = ({operateur, onLogout, toast}) => {
  const [screen, setScreen] = useState("lots"); // lots | releve
  const [activeLot, setActiveLot] = useState(null);
  const [typeOp, setTypeOp] = useState(null);
  const [saving, setSaving] = useState(false);

  // Indices essences (source: Forêts Romandes / ITEBE 2004)
  const INDICES = {
    peuplier:  { densiteVerte: 850,  pci: 2.4 },
    chene:     { densiteVerte: 1000, pci: 3.8 },
    hetre:     { densiteVerte: 1000, pci: 4.0 },
    charme:    { densiteVerte: 1000, pci: 4.2 },
    frene:     { densiteVerte: 900,  pci: 3.9 },
    bouleau:   { densiteVerte: 950,  pci: 3.7 },
    resineux:  { densiteVerte: 870,  pci: 2.8 },
    melange:   { densiteVerte: 950,  pci: 3.5 },
  };

  // Relevé
  const [nbTas,       setNbTas]   = useState(1);
  const [longueur,    setLong]    = useState(4);
  const [largeur,     setLarg]    = useState(1.2);
  const [hauteur,     setHaut]    = useState(1.2);
  const [foisonnement,setFoison]  = useState(0.55);
  const [meteo,       setMeteo]   = useState("beau");
  const [incident,    setIncid]   = useState("");
  const [temps,       setTemps]   = useState(8);

  // Calcul automatique
  const volApparent = nbTas * longueur * largeur * hauteur;
  const volReel = volApparent * foisonnement;

  // Essence depuis la visite (si disponible) — sinon mélange
  const essenceVisite = activeLot?.essenceVisite || "melange";
  const indices = INDICES[essenceVisite] || INDICES.melange;
  const poidsTotal = Math.round(volReel * indices.densiteVerte / 1000 * 100) / 100;
  const energieMWh = Math.round(poidsTotal * indices.pci * 100) / 100;

  const [releveExistantId, setReleveExistantId] = useState(null);
  const [modeModif, setModeModif] = useState(false);

  const handleSaveReleve = async () => {
    setSaving(true);
    const endpoint = typeOp==="abattage" ? "/releves-abatteur" : "/releves-debardeur";
    const dateHeure = new Date().toISOString();
    const payload = {
      lotId: activeLot.lotId,
      operateur: `${operateur.nom}${operateur.prenom?" "+operateur.prenom:""}`,
      etfNom: operateur.etfNom,
      date: dateHeure,
      nbTas, longueur, largeur, hauteur,
      essence: essenceVisite,
      humidite: Math.round((1 - foisonnement) * 100),
      meteo, incident, temps,
      volTotal: Math.round(volReel * 100) / 100,
      poidsTotal,
    };
    try {
      let res;
      if (modeModif && releveExistantId) {
        res = await fetch(`${API}${endpoint}/${releveExistantId}`, {
          method:"PATCH",
          headers:{"Content-Type":"application/json"},
          body:JSON.stringify(payload),
        });
      } else {
        res = await fetch(`${API}${endpoint}`, {
          method:"POST",
          headers:{"Content-Type":"application/json"},
          body:JSON.stringify(payload),
        });
      }
      if (!res.ok) {
        const err = await res.json();
        // Détecter doublon
        if (err.message && err.message.startsWith("DOUBLON:")) {
          const id = err.message.split(":")[1];
          setReleveExistantId(id);
          setModeModif(true);
          setSaving(false);
          return;
        }
        throw new Error();
      }
      toast(modeModif ? "Relevé modifié ✓" : "Relevé enregistré ✓");
      setScreen("lots");
      setActiveLot(null);
      setModeModif(false);
      setReleveExistantId(null);
    } catch { toast("Erreur API","warn"); }
    setSaving(false);
  };

  const assignations = operateur.assignations||[];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:C.bg}}>
      {/* Header */}
      <div style={{background:C.sb,color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <img src="/logo.png" alt="APPLITAG" style={{width:32,height:32,objectFit:"contain"}}/>
          <div style={{flex:1}}>
            <div style={{fontSize:16,fontWeight:600}}>
              {screen==="lots" ? `👷 ${operateur.nom}` : `📋 Relevé ${typeOp}`}
            </div>
            <div style={{fontSize:11,opacity:.6}}>{operateur.etfNom}</div>
          </div>
          {screen==="releve"&&(
            <button onClick={()=>setScreen("lots")} style={{
              background:"rgba(255,255,255,.1)",border:"none",color:"#fff",
              padding:"6px 12px",borderRadius:8,fontSize:13,cursor:"pointer",
              WebkitTapHighlightColor:"transparent"}}>{"<"} Retour</button>
          )}
          {screen==="lots"&&(
            <button onClick={onLogout} style={{
              background:"rgba(255,255,255,.1)",border:"none",color:"rgba(255,255,255,.6)",
              padding:"6px 10px",borderRadius:8,fontSize:12,cursor:"pointer",
              WebkitTapHighlightColor:"transparent"}}>⎋</button>
          )}
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:90}}>
        {screen==="lots"&&(
          <div>
            <div style={{fontSize:14,color:C.tx2,marginBottom:16,lineHeight:1.6}}>
              Sélectionnez le lot et le type d'opération pour saisir votre relevé.
            </div>
            {assignations.length===0 ? (
              <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
                <div style={{fontSize:40,marginBottom:12}}>📋</div>
                <div style={{fontSize:16,fontWeight:500}}>Aucun lot assigné</div>
                <div style={{fontSize:13,marginTop:6}}>Contactez votre administrateur</div>
              </div>
            ) : assignations.map(a=>(
              <div key={a.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
                borderRadius:14,padding:16,marginBottom:10}}>
                <div style={{fontFamily:"monospace",fontSize:13,fontWeight:700,
                  color:C.greenD,marginBottom:8}}>🏷 {a.lotNumero}</div>
                <div style={{fontSize:12,color:C.tx3,marginBottom:12}}>
                  {{"abattage":"🪓 Abattage","debardage":"🚜 Débardage","broyage":"🌿 Broyage"}[a.typeOperation]||a.typeOperation}
                </div>
                <button onClick={()=>{ setActiveLot(a); setTypeOp(a.typeOperation); setScreen("releve"); }}
                  style={{width:"100%",height:44,borderRadius:10,
                    background:C.green,color:"#fff",border:"none",
                    fontFamily:"inherit",fontSize:14,fontWeight:600,cursor:"pointer",
                    WebkitTapHighlightColor:"transparent"}}>
                  ➕ Saisir un relevé
                </button>
              </div>
            ))}
          </div>
        )}

        {screen==="releve"&&activeLot&&(
          <div>
            <div style={{background:C.greenL,borderRadius:12,padding:12,marginBottom:16,
              border:`1px solid ${C.green}`}}>
              <div style={{fontSize:11,color:C.greenD,fontWeight:600}}>Lot · {typeOp}</div>
              <div style={{fontFamily:"monospace",fontSize:15,fontWeight:700,color:C.greenD}}>
                {activeLot.lotNumero}
              </div>
              <div style={{fontSize:11,color:C.tx3,marginTop:4}}>
                📅 Date et heure enregistrées automatiquement à la validation
              </div>
            </div>

            <SectionTitle icon="📦" label="Mesures du tas"/>
            <MSlider label="Nombre de tas" value={nbTas} onChange={setNbTas}
              min={1} max={50} step={1} unit=" tas" color={C.amber}/>
            <MSlider label="Longueur" value={longueur} onChange={setLong}
              min={1} max={20} step={0.5} unit=" m" color={C.blue}/>
            <MSlider label="Largeur" value={largeur} onChange={setLarg}
              min={0.5} max={5} step={0.1} unit=" m" color={C.blue}/>
            <MSlider label="Hauteur" value={hauteur} onChange={setHaut}
              min={0.5} max={5} step={0.1} unit=" m" color={C.blue}/>

            <SectionTitle icon="🌬️" label="Foisonnement (taux de vide)"/>
            <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
              {[
                [0.40,"Très vrac","Bois fraîchement abattu, mal empilé","🪵"],
                [0.55,"Débardé en tas","État habituel après débardage","🚜"],
                [0.65,"Bien empilé","Bois rangé soigneusement","📐"],
              ].map(([v,l,s,e])=>(
                <div key={v} onClick={()=>setFoison(v)} style={{
                  padding:"12px 14px",borderRadius:12,cursor:"pointer",
                  border:`2px solid ${foisonnement===v?C.green:C.bd}`,
                  background:foisonnement===v?C.greenL:"#fff",
                  WebkitTapHighlightColor:"transparent"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <div>
                      <div style={{fontSize:14,fontWeight:600,
                        color:foisonnement===v?C.greenD:C.tx}}>{e} {l}</div>
                      <div style={{fontSize:11,color:C.tx3,marginTop:2}}>{s}</div>
                    </div>
                    <div style={{fontFamily:"monospace",fontSize:16,fontWeight:700,
                      color:foisonnement===v?C.greenD:C.tx3}}>
                      {Math.round(v*100)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <SectionTitle icon="🌤️" label="Conditions météo"/>
            <div style={{display:"flex",gap:8,marginBottom:14}}>
              {[["beau","☀️","Beau"],["nuageux","⛅","Nuageux"],["pluie","🌧️","Pluie"],["vent","💨","Vent"]].map(([v,e,l])=>(
                <button key={v} onClick={()=>setMeteo(v)} style={{
                  flex:1,padding:"10px 4px",borderRadius:10,
                  border:`1.5px solid ${meteo===v?C.green:C.bd}`,
                  background:meteo===v?C.greenL:"#fff",cursor:"pointer",
                  fontFamily:"inherit",display:"flex",flexDirection:"column",
                  alignItems:"center",gap:3,WebkitTapHighlightColor:"transparent"}}>
                  <span style={{fontSize:20}}>{e}</span>
                  <span style={{fontSize:10,color:meteo===v?C.greenD:C.tx2}}>{l}</span>
                </button>
              ))}
            </div>
            <MSlider label="Temps de travail" value={temps} onChange={setTemps}
              min={0.5} max={12} step={0.5} unit="h" color={C.amber}/>
            <MInput label="Incident / Remarque" value={incident} onChange={setIncid}
              placeholder="Panne, accident, remarque…" big hint="optionnel"/>

            {/* Récap calcul automatique */}
            <div style={{background:C.amberL,borderRadius:14,padding:16,marginBottom:16,
              border:`1.5px solid ${C.amber}`}}>
              <div style={{fontSize:12,color:C.amberD,fontWeight:700,marginBottom:12}}>
                📊 Calcul automatique (indices ITEBE)
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
                <div style={{textAlign:"center",background:"rgba(186,117,23,.1)",
                  borderRadius:10,padding:10}}>
                  <div style={{fontSize:20,fontWeight:700,color:C.amberD}}>
                    {Math.round(volApparent*10)/10}
                  </div>
                  <div style={{fontSize:10,color:C.tx3,marginTop:2}}>m³ apparent</div>
                </div>
                <div style={{textAlign:"center",background:"rgba(186,117,23,.1)",
                  borderRadius:10,padding:10}}>
                  <div style={{fontSize:20,fontWeight:700,color:C.amberD}}>
                    {poidsTotal}
                  </div>
                  <div style={{fontSize:10,color:C.tx3,marginTop:2}}>tonnes</div>
                </div>
                <div style={{textAlign:"center",background:"rgba(186,117,23,.1)",
                  borderRadius:10,padding:10}}>
                  <div style={{fontSize:20,fontWeight:700,color:C.amberD}}>
                    {energieMWh}
                  </div>
                  <div style={{fontSize:10,color:C.tx3,marginTop:2}}>MWh</div>
                </div>
              </div>
              <div style={{fontSize:11,color:C.tx3,marginTop:10,textAlign:"center"}}>
                Essence : {indices && essenceVisite} · Densité {indices?.densiteVerte} kg/m³ · PCI {indices?.pci} MWh/t
              </div>
            </div>
          </div>
        )}
      </div>

      {screen==="releve"&&(
        <div style={{position:"fixed",bottom:0,left:0,right:0,
          padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
          {modeModif&&(
            <div style={{background:C.amberL,borderRadius:12,padding:12,marginBottom:10,
              border:`1.5px solid ${C.amber}`}}>
              <div style={{fontSize:13,fontWeight:700,color:C.amberD,marginBottom:4}}>
                ⚠ Relevé déjà saisi aujourd'hui
              </div>
              <div style={{fontSize:12,color:C.amberD}}>
                Vous avez déjà un relevé pour ce lot aujourd'hui. Confirmer pour le modifier — cette action sera tracée et notifiée à votre ETF et à l'administrateur.
              </div>
            </div>
          )}
          <BigBtn onClick={handleSaveReleve} disabled={saving}
            bg={modeModif?C.amber:C.green} icon={saving?"":modeModif?"⚠️":"✅"}>
            {saving?"Enregistrement…":modeModif?"CONFIRMER LA MODIFICATION":"VALIDER LE RELEVÉ"}
          </BigBtn>
        </div>
      )}
    </div>
  );
};

// ── COULEURS STATUT LOT ───────────────────────────────────────
const STATUT_LOT = {
  NOUVEAU:               {label:"Nouveau",            color:"#9A9892", bg:"#ECEAE6"},
  VISITE_PREVUE:         {label:"Visite prévue",      color:"#BA7517", bg:"#FAEEDA"},
  VISITE_REALISEE:       {label:"Visite réalisée",    color:"#185FA5", bg:"#E6F1FB"},
  VALIDE_EXPLOITATION:   {label:"Validé",             color:"#534AB7", bg:"#EEEDFE"},
  EN_COURS_EXPLOITATION: {label:"En exploitation",    color:"#185FA5", bg:"#E6F1FB"},
  BORD_ROUTE:            {label:"Bord de route",      color:"#8B6914", bg:"#F1EFE8"},
  A_DECHIQUETER:         {label:"À déchiqueter",      color:"#D85A30", bg:"#FAECE7"},
  EN_COURS_BROYAGE:      {label:"En cours broyage",   color:"#D85A30", bg:"#FAECE7"},
  EN_LIVRAISON:          {label:"En livraison",       color:"#534AB7", bg:"#EEEDFE"},
  LIVRE_CHAUFFERIE:      {label:"Livré chaufferie",   color:"#1D9E75", bg:"#E1F5EE"},
  EN_STOCK_PLATEFORME:   {label:"En stock plateforme",color:"#185FA5", bg:"#E6F1FB"},
  LIVRE:                 {label:"Livré",              color:"#1D9E75", bg:"#E1F5EE"},
  ALERTE:                {label:"⚠ Alerte",           color:"#A32D2D", bg:"#FCEBEB"},
};

// ── ÉCRAN ACCUEIL ─────────────────────────────────────────────
const EcranAccueil = ({contacts, visites, notifications, user, onNewLot, onGoLots, onGoAlertes}) => {
  const lotsAVisiter = contacts.filter(c=>c.lotNumero&&(c.statutLot==="VISITE_PREVUE"||c.statutLot==="NOUVEAU"||!c.statutLot));
  const chantiersJour = contacts.filter(c=>c.statutLot==="EN_COURS_EXPLOITATION"||c.statutLot==="VALIDE_EXPLOITATION");
  const alertes = notifications.filter(n=>!n.lu);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",overflowY:"auto",
      padding:PADDING,paddingBottom:90}}>
      <div style={{marginBottom:20}}>
        <div style={{fontSize:13,color:C.tx3}}>{new Date().toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'})}</div>
        <div style={{fontSize:22,fontWeight:700,color:C.tx,marginTop:2}}>
          Bonjour {user?.prenom||user?.nom} 👋
        </div>
      </div>
      {alertes.length>0&&(
        <div onClick={onGoAlertes} style={{background:C.redL,borderRadius:14,padding:16,
          marginBottom:12,border:`1.5px solid ${C.red}`,cursor:"pointer",
          WebkitTapHighlightColor:"transparent"}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:24}}>🔴</span>
            <div>
              <div style={{fontSize:15,fontWeight:700,color:C.red}}>
                {alertes.length} alerte{alertes.length>1?"s":""} active{alertes.length>1?"s":""}
              </div>
              <div style={{fontSize:12,color:C.red,opacity:.8}}>Appuyer pour voir</div>
            </div>
          </div>
        </div>
      )}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
        {[
          {icon:"🔭",label:"Lots à visiter",count:lotsAVisiter.length,color:C.amber,bg:C.amberL,action:()=>onGoLots("VISITE_PREVUE")},
          {icon:"🪓",label:"Chantiers",count:chantiersJour.length,color:C.blue,bg:C.blueL,action:()=>onGoLots("EN_COURS_EXPLOITATION")},
          {icon:"📋",label:"Total lots",count:contacts.filter(c=>c.lotNumero).length,color:C.green,bg:C.greenL,action:()=>onGoLots("TOUS")},
          {icon:"✅",label:"Livrés",count:contacts.filter(c=>c.statutLot==="LIVRE").length,color:C.greenD,bg:C.greenL,action:()=>onGoLots("LIVRE")},
        ].map((card,i)=>(
          <div key={i} onClick={card.action} style={{
            background:card.bg,borderRadius:14,padding:16,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>
            <div style={{fontSize:28,marginBottom:8}}>{card.icon}</div>
            <div style={{fontSize:26,fontWeight:700,color:card.color}}>{card.count}</div>
            <div style={{fontSize:12,color:C.tx2,marginTop:2}}>{card.label}</div>
          </div>
        ))}
      </div>
      {contacts.filter(c=>c.lotNumero).slice(0,3).map(c=>{
        const st = STATUT_LOT[c.statutLot||"NOUVEAU"]||STATUT_LOT.NOUVEAU;
        return (
          <div key={c.id} style={{background:"#fff",border:`1px solid ${C.bd}`,
            borderRadius:14,padding:14,marginBottom:10,display:"flex",
            alignItems:"center",gap:12}}>
            <div style={{width:10,height:10,borderRadius:"50%",background:st.color,flexShrink:0}}/>
            <div style={{flex:1}}>
              <div style={{fontFamily:"monospace",fontSize:12,color:C.greenD,fontWeight:600}}>{c.lotNumero}</div>
              <div style={{fontSize:13,color:C.tx,marginTop:1}}>{c.nom} · {c.commune}</div>
            </div>
            <span style={{fontSize:10,padding:"3px 8px",borderRadius:6,
              background:st.bg,color:st.color,fontWeight:600,whiteSpace:"nowrap"}}>
              {st.label}
            </span>
          </div>
        );
      })}
      <div style={{marginTop:8}}>
        <BigBtn onClick={onNewLot} bg={C.green} icon="➕">NOUVEAU LOT</BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN LISTE LOTS ──────────────────────────────────────────
const FILTRES_LOTS = [
  {id:"TOUS",label:"Tous"},
  {id:"VISITE_PREVUE",label:"À visiter"},
  {id:"EN_COURS_EXPLOITATION",label:"Exploitation"},
  {id:"BORD_ROUTE",label:"Bord route"},
  {id:"EN_LIVRAISON",label:"Transport"},
  {id:"LIVRE",label:"Livré"},
];

const EcranLots = ({contacts, onNewLot, onOpenLot, filtreInitial="TOUS"}) => {
  const [filtre, setFiltre] = useState(filtreInitial);
  const [search, setSearch] = useState("");

  useEffect(()=>{ setFiltre(filtreInitial); }, [filtreInitial]);

  const lotsFiltres = contacts.filter(c=>{
    if (!c.lotNumero) return false;
    if (search && !`${c.lotNumero} ${c.nom} ${c.commune}`.toLowerCase().includes(search.toLowerCase())) return false;
    if (filtre==="TOUS") return true;
    if (filtre==="VISITE_PREVUE") return c.statutLot==="VISITE_PREVUE"||c.statutLot==="NOUVEAU"||!c.statutLot;
    return c.statutLot===filtre;
  });
  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>
      <div style={{padding:"8px 16px",background:"#fff",borderBottom:`1px solid ${C.bd}`,flexShrink:0}}>
        <input value={search} onChange={e=>setSearch(e.target.value)}
          placeholder="🔍 Rechercher un lot, propriétaire, commune…"
          style={{width:"100%",height:40,padding:"0 12px",borderRadius:10,
            border:`1px solid ${C.bd}`,fontSize:14,fontFamily:"inherit",
            background:C.bg,color:C.tx,outline:"none"}}/>
      </div>
      <div style={{display:"flex",gap:6,padding:"8px 16px",overflowX:"auto",
        flexShrink:0,background:"#fff",borderBottom:`1px solid ${C.bd}`}}>
        {FILTRES_LOTS.map(f=>(
          <button key={f.id} onClick={()=>setFiltre(f.id)} style={{
            height:32,padding:"0 12px",borderRadius:16,whiteSpace:"nowrap",
            border:`1.5px solid ${filtre===f.id?C.green:C.bd}`,
            background:filtre===f.id?C.green:"#fff",
            color:filtre===f.id?"#fff":C.tx2,
            fontFamily:"inherit",fontSize:12,fontWeight:500,cursor:"pointer",
            WebkitTapHighlightColor:"transparent",flexShrink:0}}>
            {f.label}
          </button>
        ))}
      </div>
      <div style={{flex:1,overflowY:"auto",padding:PADDING}}>
        {lotsFiltres.length===0 ? (
          <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
            <div style={{fontSize:40,marginBottom:12}}>🌲</div>
            <div style={{fontSize:16,fontWeight:500}}>Aucun lot</div>
          </div>
        ) : lotsFiltres.map(c=>{
          const st = STATUT_LOT[c.statutLot||"NOUVEAU"]||STATUT_LOT.NOUVEAU;
          return (
            <div key={c.id} onClick={()=>onOpenLot(c)} style={{
              background:"#fff",borderRadius:14,padding:16,marginBottom:10,cursor:"pointer",
              WebkitTapHighlightColor:"transparent",
              borderLeft:`4px solid ${st.color}`,border:`1px solid ${C.bd}`,
              borderLeftWidth:4,borderLeftColor:st.color}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                <div>
                  <div style={{fontFamily:"monospace",fontSize:13,fontWeight:700,color:C.greenD}}>{c.lotNumero}</div>
                  <div style={{fontSize:15,fontWeight:600,color:C.tx,marginTop:2}}>{c.nom}{c.prenom?` ${c.prenom}`:""}</div>
                </div>
                <span style={{fontSize:10,padding:"3px 8px",borderRadius:6,
                  background:st.bg,color:st.color,fontWeight:600,whiteSpace:"nowrap"}}>
                  {st.label}
                </span>
              </div>
              <div style={{fontSize:12,color:C.tx3}}>
                📍 {c.commune}{c.surfaceHa?` · 🌲 ${c.surfaceHa} ha`:""}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{padding:"12px 16px 24px",flexShrink:0}}>
        <BigBtn onClick={onNewLot} bg={C.green} icon="➕">Nouveau lot</BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN VALIDATION EXPLOITATION ────────────────────────────
const EcranValidationExploitation = ({lot, operateurs, onBack, onSaved, toast, entrepriseId}) => {
  const [etfNom,      setEtfNom]     = useState("");
  const [opsChoisis,  setOpsChoisis] = useState([]);
  const [typeOp,      setTypeOp]     = useState("abattage_debardage");
  const [machine,     setMachine]    = useState("");
  const [dateDebut,   setDateDebut]  = useState(todayS());
  const [dateFin,     setDateFin]    = useState("");
  const [saving,      setSaving]     = useState(false);

  const etfs = [...new Set(operateurs.map(o=>o.etfNom).filter(Boolean))];
  const opsETF = operateurs.filter(o=>o.etfNom===etfNom);

  const handleSave = async () => {
    if (!etfNom||!dateDebut||!dateFin) {
      toast("Remplir ETF, dates début et fin","warn"); return;
    }
    setSaving(true);
    try {
      const res = await fetch(`${API}/validations`, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          lotId: lot.id,
          lotNumero: lot.lotNumero,
          entrepriseId,
          etfNom,
          operateurs: opsChoisis.join(", "),
          typeOperation: typeOp,
          machine,
          dateDebut,
          dateFin,
          statut: "en_attente",
        }),
      });
      if (!res.ok) throw new Error();
      toast("Validation exploitation créée ✓");
      onSaved();
    } catch { toast("Erreur API","warn"); }
    setSaving(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:C.bg}}>
      <div style={{background:C.sb,color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.1)",border:"none",
            color:"#fff",padding:"6px 10px",borderRadius:8,fontSize:13,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>{"<"} Retour</button>
          <div style={{flex:1}}>
            <div style={{fontSize:15,fontWeight:600}}>Validation exploitation</div>
            <div style={{fontSize:11,opacity:.6}}>{lot.lotNumero}</div>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:90}}>
        <SectionTitle icon="🏢" label="Entreprise ETF"/>
        {etfs.length===0 ? (
          <div style={{background:C.amberL,borderRadius:12,padding:14,marginBottom:14,
            border:`1px solid ${C.amber}`}}>
            <div style={{fontSize:13,color:C.amberD}}>
              ⚠ Aucune ETF disponible. Créez d'abord des opérateurs dans l'onglet Alertes.
            </div>
          </div>
        ) : (
          <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
            {etfs.map(etf=>(
              <div key={etf} onClick={()=>{ setEtfNom(etf); setOpsChoisis([]); }} style={{
                padding:14,borderRadius:12,cursor:"pointer",
                border:`2px solid ${etfNom===etf?C.green:C.bd}`,
                background:etfNom===etf?C.greenL:"#fff",
                WebkitTapHighlightColor:"transparent"}}>
                <div style={{fontSize:15,fontWeight:600,color:etfNom===etf?C.greenD:C.tx}}>
                  🏢 {etf}
                </div>
                <div style={{fontSize:12,color:C.tx3,marginTop:2}}>
                  {operateurs.filter(o=>o.etfNom===etf).length} opérateur(s)
                </div>
              </div>
            ))}
          </div>
        )}

        {etfNom&&(
          <>
            <SectionTitle icon="👷" label="Opérateurs"/>
            <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
              {opsETF.map(op=>{
                const checked = opsChoisis.includes(op.id);
                return (
                  <div key={op.id} onClick={()=>setOpsChoisis(prev=>
                    checked?prev.filter(x=>x!==op.id):[...prev,op.id]
                  )} style={{
                    padding:14,borderRadius:12,cursor:"pointer",
                    border:`2px solid ${checked?C.green:C.bd}`,
                    background:checked?C.greenL:"#fff",
                    display:"flex",alignItems:"center",gap:12,
                    WebkitTapHighlightColor:"transparent"}}>
                    <div style={{width:22,height:22,borderRadius:6,flexShrink:0,
                      border:`2px solid ${checked?C.green:C.bd}`,
                      background:checked?C.green:"#fff",
                      display:"flex",alignItems:"center",justifyContent:"center"}}>
                      {checked&&<span style={{color:"#fff",fontSize:13}}>✓</span>}
                    </div>
                    <div>
                      <div style={{fontSize:14,fontWeight:600,color:checked?C.greenD:C.tx}}>
                        {op.nom} {op.prenom}
                      </div>
                      <div style={{fontSize:11,color:C.tx3}}>{op.etfNom}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        <SectionTitle icon="⚙️" label="Type d'opération"/>
        <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
          {[["abattage","🪓 Abattage"],["debardage","🚜 Débardage"],
            ["abattage_debardage","🪓🚜 Abattage + Débardage"]].map(([v,l])=>(
            <button key={v} onClick={()=>setTypeOp(v)} style={{
              padding:"12px 16px",borderRadius:12,textAlign:"left",
              border:`2px solid ${typeOp===v?C.green:C.bd}`,
              background:typeOp===v?C.greenL:"#fff",cursor:"pointer",
              fontFamily:"inherit",fontSize:14,fontWeight:typeOp===v?600:400,
              color:typeOp===v?C.greenD:C.tx,
              WebkitTapHighlightColor:"transparent"}}>
              {l}
            </button>
          ))}
        </div>

        <MInput label="Machine utilisée" value={machine} onChange={setMachine}
          placeholder="Ex: John Deere 1270G, Ponsse Bear…"/>

        <SectionTitle icon="📅" label="Planning"/>
        <MInput label="Date début prévue" value={dateDebut} onChange={setDateDebut} type="date"/>
        <MInput label="Date fin prévue" value={dateFin} onChange={setDateFin} type="date"/>

        <div style={{background:C.blueL,borderRadius:12,padding:14,marginBottom:14,
          border:`1px solid ${C.blue}`}}>
          <div style={{fontSize:13,fontWeight:600,color:C.blueD,marginBottom:6}}>
            ✍️ Signatures
          </div>
          <div style={{fontSize:12,color:C.tx3,lineHeight:1.6}}>
            Les signatures électroniques du propriétaire et du donneur d'ordre seront
            ajoutées après validation. Un lien de signature sera envoyé.
          </div>
        </div>
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
        <BigBtn onClick={handleSave} disabled={saving} bg={C.green} icon={saving?"":"✅"}>
          {saving?"Enregistrement…":"VALIDER L'EXPLOITATION"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN CLÔTURE EXPLOITATION ───────────────────────────────
const EcranClotureExploitation = ({lot, onBack, onSaved, toast, entrepriseId}) => {
  const [nbTas,       setNbTas]    = useState(1);
  const [longueur,    setLong]     = useState(4);
  const [largeur,     setLarg]     = useState(1.2);
  const [hauteur,     setHaut]     = useState(1.2);
  const [foisonnement,setFoison]   = useState(0.55);
  const [humidite,    setHumidite] = useState(35);
  const [anomalies,   setAnomalies]= useState("");
  const [photos,      setPhotos]   = useState([]);
  const [saving,      setSaving]   = useState(false);

  // Indices essences
  const INDICES = {
    peuplier:{densiteVerte:850,pci:2.4},chene:{densiteVerte:1000,pci:3.8},
    hetre:{densiteVerte:1000,pci:4.0},charme:{densiteVerte:1000,pci:4.2},
    frene:{densiteVerte:900,pci:3.9},bouleau:{densiteVerte:950,pci:3.7},
    resineux:{densiteVerte:870,pci:2.8},melange:{densiteVerte:950,pci:3.5},
  };
  const essence = lot.potentiel?.split(":")?.[0] || "melange";
  const indices = INDICES[essence] || INDICES.melange;
  const volApparent = nbTas * longueur * largeur * hauteur;
  const volReel = Math.round(volApparent * foisonnement * 100)/100;
  const poidsEstime = Math.round(volReel * indices.densiteVerte / 1000 * 100)/100;
  const energieMWh = Math.round(poidsEstime * indices.pci * 100)/100;

  const handlePhoto = () => {
    const input = document.createElement("input");
    input.type = "file"; input.accept = "image/*"; input.capture = "environment";
    input.onchange = e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => setPhotos(prev=>[...prev, ev.target.result]);
      reader.readAsDataURL(file);
    };
    input.click();
  };

  const handleSave = async () => {
    if (photos.length === 0) { toast("Au moins une photo requise","warn"); return; }
    setSaving(true);
    try {
      const res = await fetch(`${API}/clotures`, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          lotId: lot.id, lotNumero: lot.lotNumero,
          entrepriseId, nbTas, longueur, largeur, hauteur,
          foisonnement, volumeTotal: volReel,
          poidsEstime, humiditeEstimee: humidite,
          photos: JSON.stringify(photos.map((_,i)=>`photo_${i+1}`)),
          anomalies, statut: "validee",
        }),
      });
      if (!res.ok) throw new Error();
      toast("Clôture exploitation enregistrée ✓");
      onSaved();
    } catch { toast("Erreur API","warn"); }
    setSaving(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:C.bg}}>
      <div style={{background:C.brown||"#8B6914",color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.15)",border:"none",
            color:"#fff",padding:"6px 10px",borderRadius:8,fontSize:13,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>{"<"} Retour</button>
          <div style={{flex:1}}>
            <div style={{fontSize:15,fontWeight:600}}>Clôture exploitation</div>
            <div style={{fontSize:11,opacity:.6}}>{lot.lotNumero}</div>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:90}}>

        <SectionTitle icon="📦" label="Mesures des tas bord de route"/>
        <MSlider label="Nombre de tas" value={nbTas} onChange={setNbTas}
          min={1} max={50} step={1} unit=" tas" color={C.amber}/>
        <MSlider label="Longueur" value={longueur} onChange={setLong}
          min={1} max={20} step={0.5} unit=" m" color={C.blue}/>
        <MSlider label="Largeur" value={largeur} onChange={setLarg}
          min={0.5} max={5} step={0.1} unit=" m" color={C.blue}/>
        <MSlider label="Hauteur" value={hauteur} onChange={setHaut}
          min={0.5} max={5} step={0.1} unit=" m" color={C.blue}/>

        <SectionTitle icon="🌬️" label="Foisonnement"/>
        <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
          {[[0.40,"Très vrac","Bois fraîchement abattu"],
            [0.55,"Débardé en tas","État habituel"],
            [0.65,"Bien empilé","Bois rangé soigneusement"]].map(([v,l,s])=>(
            <div key={v} onClick={()=>setFoison(v)} style={{
              padding:"12px 14px",borderRadius:12,cursor:"pointer",
              border:`2px solid ${foisonnement===v?C.green:C.bd}`,
              background:foisonnement===v?C.greenL:"#fff",
              WebkitTapHighlightColor:"transparent"}}>
              <div style={{display:"flex",justifyContent:"space-between"}}>
                <div>
                  <div style={{fontSize:14,fontWeight:600,color:foisonnement===v?C.greenD:C.tx}}>{l}</div>
                  <div style={{fontSize:11,color:C.tx3}}>{s}</div>
                </div>
                <div style={{fontFamily:"monospace",fontSize:16,fontWeight:700,
                  color:foisonnement===v?C.greenD:C.tx3}}>{Math.round(v*100)}%</div>
              </div>
            </div>
          ))}
        </div>

        <MSlider label="Humidité estimée" value={humidite} onChange={setHumidite}
          min={10} max={60} step={5} unit="%" color={C.blue}/>

        {/* Récap */}
        <div style={{background:C.amberL,borderRadius:14,padding:16,marginBottom:16,
          border:`1.5px solid ${C.amber}`}}>
          <div style={{fontSize:12,color:C.amberD,fontWeight:700,marginBottom:12}}>
            📊 Estimation automatique
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
            {[[Math.round(volApparent*10)/10,"m³ apparent"],
              [volReel,"m³ réel"],
              [poidsEstime,"tonnes"],
            ].map(([v,l],i)=>(
              <div key={i} style={{textAlign:"center",background:"rgba(186,117,23,.1)",
                borderRadius:10,padding:10}}>
                <div style={{fontSize:20,fontWeight:700,color:C.amberD}}>{v}</div>
                <div style={{fontSize:10,color:C.tx3,marginTop:2}}>{l}</div>
              </div>
            ))}
          </div>
          <div style={{fontSize:11,color:C.tx3,marginTop:8,textAlign:"center"}}>
            Énergie estimée : {energieMWh} MWh
          </div>
        </div>

        <SectionTitle icon="📷" label="Photos des tas"/>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:14}}>
          {photos.map((p,i)=>(
            <div key={i} style={{position:"relative"}}>
              <img src={p} style={{width:80,height:80,objectFit:"cover",borderRadius:10}}/>
              <button onClick={()=>setPhotos(prev=>prev.filter((_,j)=>j!==i))} style={{
                position:"absolute",top:-6,right:-6,width:20,height:20,
                borderRadius:"50%",background:C.red,color:"#fff",border:"none",
                fontSize:11,cursor:"pointer",display:"flex",alignItems:"center",
                justifyContent:"center"}}>×</button>
            </div>
          ))}
          <button onClick={handlePhoto} style={{
            width:80,height:80,borderRadius:10,
            border:`2px dashed ${C.bd}`,background:C.bg,
            cursor:"pointer",display:"flex",flexDirection:"column",
            alignItems:"center",justifyContent:"center",gap:4,
            WebkitTapHighlightColor:"transparent"}}>
            <span style={{fontSize:24}}>📷</span>
            <span style={{fontSize:10,color:C.tx3}}>Ajouter</span>
          </button>
        </div>

        <MInput label="Anomalies / Observations" value={anomalies}
          onChange={setAnomalies} placeholder="Bois souillé, accès difficile…" big hint="optionnel"/>
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
        <BigBtn onClick={handleSave} disabled={saving} bg={C.green} icon={saving?"":"✅"}>
          {saving?"Enregistrement…":"VALIDER LA CLÔTURE"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN CARTE (Leaflet / OpenStreetMap) ────────────────────
const EcranCarte = ({contacts, visites, onOpenLot}) => {
  const mapRef     = useRef(null);
  const mapInst    = useRef(null);
  const markersRef = useRef([]);
  const [loaded,   setLoaded]  = useState(!!window.L);
  const [filtre,   setFiltre]  = useState("TOUS");
  const [nbLots,   setNbLots]  = useState(0);

  // ── Chargement Leaflet depuis CDN ──
  useEffect(()=>{
    if (window.L) { setLoaded(true); return; }
    if (!document.getElementById("lf-css")) {
      const lnk = document.createElement("link");
      lnk.id="lf-css"; lnk.rel="stylesheet";
      lnk.href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
      document.head.appendChild(lnk);
    }
    if (!document.getElementById("lf-js")) {
      const sc = document.createElement("script");
      sc.id="lf-js";
      sc.src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
      sc.onload=()=>setLoaded(true);
      document.head.appendChild(sc);
    }
  },[]);

  // ── Init carte ──
  useEffect(()=>{
    if (!loaded || !mapRef.current || mapInst.current) return;
    const L = window.L;
    // Fix icônes Leaflet en prod
    delete L.Icon.Default.prototype._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconUrl:"https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
      iconRetinaUrl:"https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
      shadowUrl:"https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
    });
    const map = L.map(mapRef.current,{
      center:[46.8,2.5], zoom:6,
      zoomControl:true,
    });
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{
      attribution:'© <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
      maxZoom:19,
    }).addTo(map);
    mapInst.current = map;
    return ()=>{ map.remove(); mapInst.current=null; };
  },[loaded]);

  // ── Callback popup → fiche lot ──
  useEffect(()=>{
    window.__aplt_open = (id)=>{
      const lot = contacts.find(c=>c.id===id);
      if (lot) onOpenLot(lot);
    };
    return ()=>{ delete window.__aplt_open; };
  },[contacts, onOpenLot]);

  // ── Mise à jour des markers ──
  useEffect(()=>{
    if (!loaded || !mapInst.current) return;
    const L = window.L;
    const map = mapInst.current;

    // Supprimer anciens markers
    markersRef.current.forEach(m=>map.removeLayer(m));
    markersRef.current = [];

    const bounds = [];
    let count = 0;

    contacts.forEach(lot=>{
      if (!lot.lotNumero) return;
      if (filtre!=="TOUS" && lot.statutLot!==filtre) return;
      const v = visites.find(v=>v.lotId===lot.id||v.lotNumero===lot.lotNumero);
      if (!v?.gps?.lat) return;

      const st = STATUT_LOT[lot.statutLot||"NOUVEAU"]||STATUT_LOT.NOUVEAU;

      // Marker coloré selon statut
      const icon = L.divIcon({
        className:"",
        iconSize:[32,32],
        iconAnchor:[16,16],
        popupAnchor:[0,-16],
        html:`<div style="
          width:32px;height:32px;border-radius:50%;
          background:${st.color};border:3px solid #fff;
          box-shadow:0 2px 8px rgba(0,0,0,.35);
          display:flex;align-items:center;justify-content:center;
          font-size:13px;cursor:pointer;">🌲</div>`,
      });

      const popup = `
        <div style="font-family:-apple-system,sans-serif;min-width:200px;padding:2px">
          <div style="font-family:monospace;font-size:14px;font-weight:700;
            color:#085041;margin-bottom:4px">${lot.lotNumero}</div>
          <div style="font-size:13px;color:#1A1A18;font-weight:500">
            ${lot.nom}${lot.prenom?" "+lot.prenom:""}</div>
          <div style="font-size:12px;color:#5A5955;margin-top:2px">📍 ${lot.commune}</div>
          <div style="margin-top:6px">
            <span style="font-size:10px;padding:3px 8px;border-radius:12px;
              background:${st.bg};color:${st.color};font-weight:600">
              ${st.label}
            </span>
          </div>
          ${lot.surfaceHa?`<div style="font-size:11px;color:#9A9892;margin-top:6px">
            🌲 ${lot.surfaceHa} ha${v?.volumeEstimeT?" · 📦 "+v.volumeEstimeT+" t":""}</div>`:""}
          ${v?.essences?.length?`<div style="font-size:11px;color:#9A9892;margin-top:2px">
            🌿 ${v.essences.map(e=>e.label).join(", ")}</div>`:""}
          <button onclick="window.__aplt_open('${lot.id}')"
            style="width:100%;margin-top:10px;padding:8px;border-radius:8px;
              background:#1D9E75;color:#fff;border:none;cursor:pointer;
              font-size:12px;font-weight:600;font-family:inherit;">
            Ouvrir la fiche →
          </button>
        </div>`;

      const marker = L.marker([v.gps.lat,v.gps.lng],{icon})
        .addTo(map)
        .bindPopup(popup,{maxWidth:240,className:"aplt-popup"});

      markersRef.current.push(marker);
      bounds.push([v.gps.lat,v.gps.lng]);
      count++;
    });

    setNbLots(count);
    if (bounds.length>0) {
      map.fitBounds(bounds,{padding:[40,40],maxZoom:13});
    }
  },[loaded, contacts, visites, filtre]);

  const FILTRES = [
    ["TOUS","Tous"],
    ["VISITE_PREVUE","À visiter"],
    ["EN_COURS_EXPLOITATION","Exploitation"],
    ["BORD_ROUTE","Bord route"],
    ["EN_LIVRAISON","Transport"],
    ["LIVRE_CHAUFFERIE","Livré"],
  ];

  const LEGENDE = [
    ["NOUVEAU","#9A9892"],
    ["VISITE_PREVUE","#BA7517"],
    ["EN_COURS_EXPLOITATION","#185FA5"],
    ["BORD_ROUTE","#8B6914"],
    ["EN_LIVRAISON","#534AB7"],
    ["LIVRE_CHAUFFERIE","#1D9E75"],
    ["ALERTE","#A32D2D"],
  ];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%"}}>

      {/* Filtres */}
      <div style={{display:"flex",gap:6,padding:"8px 12px",overflowX:"auto",
        flexShrink:0,background:"#fff",borderBottom:`1px solid ${C.bd}`,
        scrollbarWidth:"none"}}>
        {FILTRES.map(([id,label])=>(
          <button key={id} onClick={()=>setFiltre(id)} style={{
            height:32,padding:"0 12px",borderRadius:16,whiteSpace:"nowrap",
            border:`1.5px solid ${filtre===id?C.green:C.bd}`,
            background:filtre===id?C.green:"#fff",
            color:filtre===id?"#fff":C.tx2,
            fontFamily:"inherit",fontSize:12,fontWeight:500,cursor:"pointer",
            WebkitTapHighlightColor:"transparent",flexShrink:0}}>
            {label}
          </button>
        ))}
      </div>

      {/* Carte */}
      <div style={{flex:1,position:"relative"}}>
        {!loaded&&(
          <div style={{position:"absolute",inset:0,display:"flex",
            alignItems:"center",justifyContent:"center",
            flexDirection:"column",background:C.bg,color:C.tx3,gap:12,zIndex:10}}>
            <div style={{fontSize:40}}>🗺️</div>
            <div style={{fontSize:14,fontWeight:500}}>Chargement de la carte…</div>
            <div style={{fontSize:12,color:C.tx3}}>OpenStreetMap via Leaflet</div>
          </div>
        )}
        <div ref={mapRef} style={{width:"100%",height:"100%"}}/>

        {/* Badge nb lots */}
        {loaded&&(
          <div style={{position:"absolute",top:10,right:10,zIndex:1000,
            background:"#fff",borderRadius:20,padding:"5px 12px",
            boxShadow:"0 2px 8px rgba(0,0,0,.2)",fontSize:12,fontWeight:600,
            color:C.tx,border:`1px solid ${C.bd}`}}>
            {nbLots} lot{nbLots!==1?"s":""} {filtre!=="TOUS"?"filtré"+(nbLots>1?"s":""):""}
          </div>
        )}
      </div>

      {/* Légende */}
      {loaded&&(
        <div style={{background:"#fff",borderTop:`1px solid ${C.bd}`,
          padding:"8px 12px",display:"flex",gap:10,flexShrink:0,
          overflowX:"auto",scrollbarWidth:"none"}}>
          {LEGENDE.map(([k,color])=>(
            <div key={k} style={{display:"flex",alignItems:"center",
              gap:5,flexShrink:0}}>
              <div style={{width:10,height:10,borderRadius:"50%",
                background:color,border:"1.5px solid #fff",
                boxShadow:"0 1px 3px rgba(0,0,0,.2)"}}/>
              <span style={{fontSize:10,color:C.tx3,whiteSpace:"nowrap"}}>
                {STATUT_LOT[k]?.label||k}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ── FICHE LOT CENTRALE (6 onglets) ───────────────────────────
const PIPELINE = [
  {id:"NOUVEAU",            label:"Nouveau",       icon:"🆕"},
  {id:"VISITE_PREVUE",      label:"Visite prévue", icon:"🔭"},
  {id:"VISITE_REALISEE",    label:"Visite OK",     icon:"✅"},
  {id:"VALIDE_EXPLOITATION",label:"Validé",        icon:"📋"},
  {id:"EN_COURS_EXPLOITATION",label:"Exploitation",icon:"🪓"},
  {id:"BORD_ROUTE",         label:"Bord route",    icon:"🌲"},
  {id:"A_DECHIQUETER",      label:"À broyer",      icon:"🪚"},
  {id:"EN_COURS_BROYAGE",   label:"Broyage",       icon:"⚙️"},
  {id:"EN_LIVRAISON",       label:"En livraison",  icon:"🚛"},
  {id:"LIVRE_CHAUFFERIE",   label:"Livré",         icon:"🔥"},
];

const FicheLotCentrale = ({
  lot, visites=[], onBack, onEdit,
  onLaunchVisite, onLaunchValidation, onLaunchCloture,
  onLaunchDechiquetage, onLaunchTransporteur, onLaunchLivraison,
  toast, entrepriseId,
}) => {
  const [onglet, setOnglet] = useState(0);
  const [releves,    setReleves]    = useState([]);
  const [transports, setTransports] = useState([]);
  const [livraisons, setLivraisons] = useState([]);
  const [loading,    setLoading]    = useState(true);

  const st = STATUT_LOT[lot.statutLot||"NOUVEAU"] || STATUT_LOT.NOUVEAU;
  const pipelineIdx = PIPELINE.findIndex(p=>p.id===(lot.statutLot||"NOUVEAU"));
  const visitesLot = visites.filter(v=>v.lotId===lot.id||v.lotNumero===lot.lotNumero);
  const derniereVisite = visitesLot[0]||null;

  useEffect(()=>{
    setLoading(true);
    Promise.all([
      fetch(`${API}/relevés/lot/${lot.id}`,{headers:authHeaders()}).then(r=>r.json()).catch(()=>[]),
      fetch(`${API}/transports/lot/${lot.id}`,{headers:authHeaders()}).then(r=>r.json()).catch(()=>[]),
      fetch(`${API}/livraisons/lot/${lot.id}`,{headers:authHeaders()}).then(r=>r.json()).catch(()=>[]),
    ]).then(([r,t,l])=>{
      if(Array.isArray(r)) setReleves(r);
      if(Array.isArray(t)) setTransports(t);
      if(Array.isArray(l)) setLivraisons(l);
      setLoading(false);
    });
  },[lot.id]);

  // Calculs volumes
  const totalTonnes = releves.reduce((s,r)=>s+(parseFloat(r.poidsTotal)||0),0);
  const totalMWh    = releves.reduce((s,r)=>s+(parseFloat(r.energieMWh)||0),0);
  const typeRessLabel = t => TYPE_RESSOURCE_OPTS.find(([v])=>v===t)?.[2]??t;

  const TABS = [
    {id:"general",   icon:"📊", label:"Général"},
    {id:"parcelle",  icon:"🌲", label:"Parcelle"},
    {id:"tas",       icon:"📦", label:"Tas"},
    {id:"transport", icon:"🚛", label:"Transport"},
    {id:"livraisons",icon:"📍", label:"Livraisons"},
    {id:"documents", icon:"📄", label:"Docs"},
  ];

  // Boutons d'action contextuels
  const s = lot.statutLot||"NOUVEAU";
  const actions = [
    (["NOUVEAU","VISITE_PREVUE","VISITE_REALISEE"].includes(s)||!s) &&
      {icon:"🔭",label:"Visite",bg:C.greenL,bd:C.green,color:C.greenD,fn:onLaunchVisite},
    ["VISITE_REALISEE","VALIDE_EXPLOITATION"].includes(s) &&
      {icon:"✅",label:"Valider",bg:C.blueL,bd:C.blue,color:C.blueD,fn:onLaunchValidation},
    ["VALIDE_EXPLOITATION","EN_COURS_EXPLOITATION"].includes(s) &&
      {icon:"🏁",label:"Clôture",bg:C.amberL,bd:C.amber,color:C.amberD,fn:onLaunchCloture},
    ["BORD_ROUTE","A_DECHIQUETER"].includes(s) &&
      {icon:"🪚",label:"Déchi.",bg:"#FAECE7",bd:"#D85A30",color:"#D85A30",fn:onLaunchDechiquetage},
    ["A_DECHIQUETER","EN_COURS_BROYAGE","EN_LIVRAISON"].includes(s) &&
      {icon:"🚛",label:"Transp.",bg:C.purpleL,bd:C.purple,color:C.purpleD,fn:onLaunchTransporteur},
    ["EN_COURS_BROYAGE","EN_LIVRAISON"].includes(s) &&
      {icon:"📦",label:"Livraison",bg:C.greenL,bd:C.green,color:C.greenD,fn:onLaunchLivraison},
  ].filter(Boolean);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:C.bg}}>

      {/* ── HEADER ── */}
      <div style={{background:C.sb,color:"#fff",flexShrink:0}}>
        <div style={{padding:"10px 16px 8px",display:"flex",alignItems:"center",gap:10}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.1)",border:"none",
            color:"#fff",padding:"6px 10px",borderRadius:8,fontSize:13,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>{"<"}</button>
          <div style={{flex:1}}>
            <div style={{fontFamily:"monospace",fontSize:14,fontWeight:700}}>{lot.lotNumero}</div>
            <div style={{fontSize:11,opacity:.6}}>{lot.nom}{lot.prenom?` ${lot.prenom}`:""} · {lot.commune}</div>
          </div>
          <span style={{fontSize:10,padding:"4px 10px",borderRadius:20,fontWeight:600,
            background:st.bg,color:st.color}}>
            {st.label}
          </span>
          <button onClick={onEdit} style={{background:"rgba(255,255,255,.1)",border:"none",
            color:"#fff",padding:"6px 10px",borderRadius:8,fontSize:12,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>✏️</button>
        </div>

        {/* Pipeline horizontal */}
        <div style={{overflowX:"auto",display:"flex",gap:0,padding:"0 16px 10px",
          scrollbarWidth:"none"}}>
          {PIPELINE.map((p,i)=>{
            const done = i < pipelineIdx;
            const current = i === pipelineIdx;
            return (
              <div key={p.id} style={{display:"flex",alignItems:"center",flexShrink:0}}>
                <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
                  <div style={{
                    width:28,height:28,borderRadius:"50%",
                    background:current?"#fff":done?"rgba(255,255,255,.3)":"rgba(255,255,255,.1)",
                    display:"flex",alignItems:"center",justifyContent:"center",
                    fontSize:current?14:11,
                    border:current?"2px solid #fff":"1px solid rgba(255,255,255,.2)"}}>
                    {done?"✓":p.icon}
                  </div>
                  {current&&(
                    <div style={{fontSize:8,color:"rgba(255,255,255,.8)",
                      whiteSpace:"nowrap",fontWeight:600,marginTop:1}}>
                      {p.label}
                    </div>
                  )}
                </div>
                {i<PIPELINE.length-1&&(
                  <div style={{width:12,height:1,
                    background:done?"rgba(255,255,255,.5)":"rgba(255,255,255,.15)",
                    margin:"0 2px",marginBottom:current?14:0}}/>
                )}
              </div>
            );
          })}
        </div>

        {/* Tab bar */}
        <div style={{display:"flex",borderTop:"1px solid rgba(255,255,255,.1)"}}>
          {TABS.map((t,i)=>(
            <button key={t.id} onClick={()=>setOnglet(i)} style={{
              flex:1,height:42,background:"transparent",border:"none",
              color:onglet===i?"#fff":"rgba(255,255,255,.45)",
              fontFamily:"inherit",fontSize:10,fontWeight:onglet===i?700:400,
              cursor:"pointer",display:"flex",flexDirection:"column",
              alignItems:"center",justifyContent:"center",gap:1,
              borderBottom:onglet===i?"2px solid #fff":"2px solid transparent",
              WebkitTapHighlightColor:"transparent"}}>
              <span style={{fontSize:14}}>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ── CONTENU ── */}
      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:actions.length?90:20}}>

        {/* ── ONGLET 0 : GÉNÉRAL ── */}
        {onglet===0&&(
          <div>
            {/* Métriques clés */}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
              {[
                {icon:"🌲",label:"Surface",val:lot.surfaceHa?`${lot.surfaceHa} ha`:"—",color:C.green,bg:C.greenL},
                {icon:"🪵",label:"Ressource",val:typeRessLabel(lot.potentiel)||"—",color:C.brown,bg:C.brownL},
                {icon:"⚖️",label:"Volume estimé",val:derniereVisite?`${derniereVisite.volumeEstimeT} t`:"—",color:C.amber,bg:C.amberL},
                {icon:"📊",label:"Relevés",val:`${releves.length} relevé${releves.length!==1?"s":""}`,color:C.blue,bg:C.blueL},
              ].map((m,i)=>(
                <div key={i} style={{background:m.bg,borderRadius:14,padding:14}}>
                  <div style={{fontSize:22,marginBottom:6}}>{m.icon}</div>
                  <div style={{fontSize:18,fontWeight:700,color:m.color}}>{m.val}</div>
                  <div style={{fontSize:11,color:C.tx2,marginTop:2}}>{m.label}</div>
                </div>
              ))}
            </div>

            {/* Volumes calculés depuis relevés */}
            {releves.length>0&&(
              <div style={{background:C.amberL,borderRadius:14,padding:16,marginBottom:16,
                border:`1.5px solid ${C.amber}`}}>
                <div style={{fontSize:12,fontWeight:700,color:C.amberD,marginBottom:10}}>
                  📊 Volumes réels (relevés opérateurs)
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
                  {[
                    [totalTonnes.toFixed(1),"t récoltées"],
                    [totalMWh.toFixed(1),"MWh potentiel"],
                    [releves.length+" relev.","saisies"],
                  ].map(([v,l],i)=>(
                    <div key={i} style={{textAlign:"center",
                      background:"rgba(186,117,23,.1)",borderRadius:10,padding:10}}>
                      <div style={{fontSize:18,fontWeight:700,color:C.amberD}}>{v}</div>
                      <div style={{fontSize:10,color:C.tx3,marginTop:2}}>{l}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Infos rapides */}
            <SectionTitle icon="ℹ️" label="Infos rapides"/>
            <div style={{background:"#fff",borderRadius:14,padding:16,marginBottom:14,
              border:`1px solid ${C.bd}`}}>
              {[
                ["📍","Commune",lot.commune],
                ["🏷️","N° lot",lot.lotNumero],
                ["📐","Réf. cadastrale",lot.refCadastrale||"—"],
                ["📅","Date contact",lot.dateContact||"—"],
                ["🤝","Apporteur",lot.nomApporteur||"—"],
                lot.certification&&["🏅","Certification",lot.certification?.toUpperCase()],
              ].filter(Boolean).map(([e,l,v],i,arr)=>(
                <div key={i} style={{display:"flex",justifyContent:"space-between",
                  padding:"10px 0",
                  borderBottom:i<arr.length-1?`1px solid ${C.bd}`:"none"}}>
                  <span style={{fontSize:12,color:C.tx3}}>{e} {l}</span>
                  <span style={{fontSize:13,fontWeight:500,color:C.tx,
                    textAlign:"right",maxWidth:"55%"}}>{v}</span>
                </div>
              ))}
            </div>

            {/* Dernière visite */}
            {derniereVisite&&(
              <>
                <SectionTitle icon="🔭" label="Dernière visite"/>
                <div style={{background:"#fff",borderRadius:14,padding:16,marginBottom:14,
                  border:`1px solid ${C.bd}`}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                    <div style={{fontSize:14,fontWeight:600}}>📅 {derniereVisite.date}</div>
                    <span style={{fontSize:10,padding:"3px 8px",borderRadius:6,
                      background:C.greenL,color:C.greenD,fontWeight:600}}>✅ Validée</span>
                  </div>
                  <div style={{fontSize:12,color:C.tx3,lineHeight:1.8}}>
                    📦 {derniereVisite.volumeEstimeT} t · 🌲 {derniereVisite.surfaceHa} ha<br/>
                    🚛 Accès {derniereVisite.accesCamion}
                    {derniereVisite.accesCamion==="praticable"?" ✓":" ⚠️"}<br/>
                    {derniereVisite.essences?.length>0&&
                      `🌿 ${derniereVisite.essences.map(e=>`${e.label} ${e.pct}%`).join(", ")}`}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── ONGLET 1 : PARCELLE ── */}
        {onglet===1&&(
          <div>
            <SectionTitle icon="👤" label="Propriétaire / Contact"/>
            <div style={{background:"#fff",borderRadius:14,padding:16,marginBottom:14,
              border:`1px solid ${C.bd}`}}>
              <div style={{fontSize:16,fontWeight:700,color:C.tx,marginBottom:4}}>
                {lot.nom} {lot.prenom}
              </div>
              {[
                ["📞",lot.telephone],["📧",lot.email],
                ["📮",lot.adressePostale],
                lot.estPersonneMorale&&["🏢",lot.typePersonneMorale?.toUpperCase()],
                lot.nomSignataire&&["✍️",`Signataire : ${lot.nomSignataire}`],
              ].filter(Boolean).map(([e,v],i)=>v&&(
                <div key={i} style={{fontSize:13,color:C.tx2,marginTop:6}}>{e} {v}</div>
              ))}
            </div>

            <SectionTitle icon="🌲" label="Parcelle"/>
            <div style={{background:"#fff",borderRadius:14,padding:16,marginBottom:14,
              border:`1px solid ${C.bd}`}}>
              {[
                ["📍","Commune",lot.commune],
                ["🏡","Lieu-dit",lot.adresseParcelle||"—"],
                ["📐","Surface",lot.surfaceHa?`${lot.surfaceHa} ha`:"—"],
                ["🗂️","Réf. cadastrale",lot.refCadastrale||"—"],
              ].map(([e,l,v],i,arr)=>(
                <div key={i} style={{display:"flex",justifyContent:"space-between",
                  padding:"9px 0",
                  borderBottom:i<arr.length-1?`1px solid ${C.bd}`:"none"}}>
                  <span style={{fontSize:12,color:C.tx3}}>{e} {l}</span>
                  <span style={{fontSize:13,fontWeight:500,color:C.tx}}>{v}</span>
                </div>
              ))}
            </div>

            {derniereVisite&&(
              <>
                <SectionTitle icon="⚠️" label="Contraintes terrain"/>
                <div style={{background:"#fff",borderRadius:14,padding:16,marginBottom:14,
                  border:`1px solid ${C.bd}`}}>
                  {Object.entries(derniereVisite.contraintes||{}).filter(([,v])=>v).length===0 ? (
                    <div style={{fontSize:13,color:C.tx3}}>Aucune contrainte signalée ✅</div>
                  ) : Object.entries(derniereVisite.contraintes||{}).filter(([,v])=>v).map(([k],i)=>(
                    <div key={i} style={{fontSize:13,color:C.amberD,padding:"4px 0"}}>
                      ⚠️ {k}
                    </div>
                  ))}
                </div>

                <SectionTitle icon="🚛" label="Accès"/>
                <div style={{background:
                  derniereVisite.accesCamion==="praticable"?C.greenL:
                  derniereVisite.accesCamion==="difficile"?C.amberL:C.redL,
                  borderRadius:12,padding:14,marginBottom:14,
                  border:`1px solid ${
                    derniereVisite.accesCamion==="praticable"?C.green:
                    derniereVisite.accesCamion==="difficile"?C.amber:C.red}`}}>
                  <div style={{fontSize:14,fontWeight:600,color:C.tx}}>
                    {derniereVisite.accesCamion==="praticable"?"✅ Praticable":
                     derniereVisite.accesCamion==="difficile"?"⚠️ Difficile":"🚫 Impossible"}
                  </div>
                  <div style={{fontSize:12,color:C.tx3,marginTop:4}}>
                    Largeur : {derniereVisite.largeurAcces}m ·
                    Distance plateforme : {derniereVisite.distancePlateforme}m
                  </div>
                </div>
              </>
            )}

            {derniereVisite?.replantation&&derniereVisite.replantation!=="non"&&(
              <>
                <SectionTitle icon="🌱" label="Replantation"/>
                <div style={{background:C.greenL,borderRadius:12,padding:14,marginBottom:14,
                  border:`1px solid ${C.green}`}}>
                  <div style={{fontSize:14,fontWeight:600,color:C.greenD,marginBottom:6}}>
                    {derniereVisite.replantation==="oui"?"✅ Prévue":"❓ À définir"}
                  </div>
                  {derniereVisite.essenceReplanT&&
                    <div style={{fontSize:12,color:C.tx3}}>🌿 {derniereVisite.essenceReplanT}</div>}
                  {derniereVisite.surfaceReplant&&
                    <div style={{fontSize:12,color:C.tx3,marginTop:2}}>
                      📐 {derniereVisite.surfaceReplant} ha · 👤 {derniereVisite.respReplant}
                    </div>}
                </div>
              </>
            )}

            {derniereVisite?.certification&&derniereVisite.certification!=="aucune"&&(
              <>
                <SectionTitle icon="🏅" label="Certification"/>
                <div style={{background:C.blueL,borderRadius:12,padding:14,marginBottom:14,
                  border:`1px solid ${C.blue}`}}>
                  <div style={{fontSize:14,fontWeight:600,color:C.blueD}}>
                    {derniereVisite.certification.toUpperCase()}
                  </div>
                  {derniereVisite.certification==="red"&&(
                    <div style={{fontSize:12,color:C.tx3,marginTop:4,lineHeight:1.7}}>
                      📦 {derniereVisite.redCategorie}<br/>
                      🌍 {derniereVisite.redPays} · 📏 {derniereVisite.redDistance} km
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {/* ── ONGLET 2 : TAS ── */}
        {onglet===2&&(
          <div>
            {loading?(
              <div style={{textAlign:"center",padding:"40px 0",color:C.tx3}}>
                <div style={{fontSize:32,marginBottom:8}}>⏳</div>
                Chargement des relevés…
              </div>
            ):releves.length===0?(
              <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
                <div style={{fontSize:40,marginBottom:12}}>📦</div>
                <div style={{fontSize:15,fontWeight:500}}>Aucun relevé</div>
                <div style={{fontSize:13,marginTop:6}}>
                  Les opérateurs terrain saisiront leurs relevés ici
                </div>
              </div>
            ):(
              <>
                <div style={{background:C.amberL,borderRadius:12,padding:14,marginBottom:14,
                  border:`1px solid ${C.amber}`}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
                    {[
                      [totalTonnes.toFixed(1)+"t","Total"],
                      [totalMWh.toFixed(1)+" MWh","Énergie"],
                      [releves.length+" relev.","Saisies"],
                    ].map(([v,l],i)=>(
                      <div key={i} style={{textAlign:"center"}}>
                        <div style={{fontSize:18,fontWeight:700,color:C.amberD}}>{v}</div>
                        <div style={{fontSize:10,color:C.tx3}}>{l}</div>
                      </div>
                    ))}
                  </div>
                </div>
                {releves.map((r,i)=>(
                  <div key={r.id||i} style={{background:"#fff",borderRadius:14,padding:14,
                    marginBottom:10,border:`1px solid ${C.bd}`}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                      <div style={{fontSize:13,fontWeight:600}}>{r.operateurNom||"Opérateur"}</div>
                      <div style={{fontSize:11,color:C.tx3}}>{r.date?.slice(0,10)||""}</div>
                    </div>
                    <div style={{fontSize:12,color:C.tx3,lineHeight:1.8}}>
                      {r.nbTas&&`📦 ${r.nbTas} tas · `}
                      {r.poidsTotal&&`⚖️ ${r.poidsTotal} t · `}
                      {r.energieMWh&&`⚡ ${r.energieMWh} MWh`}
                    </div>
                    {r.typeOperation&&(
                      <div style={{marginTop:6,fontSize:11,padding:"2px 8px",
                        display:"inline-block",borderRadius:6,
                        background:C.bg2,color:C.tx2}}>
                        {r.typeOperation}
                      </div>
                    )}
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {/* ── ONGLET 3 : TRANSPORT ── */}
        {onglet===3&&(
          <div>
            {loading?(
              <div style={{textAlign:"center",padding:"40px 0",color:C.tx3}}>⏳ Chargement…</div>
            ):transports.length===0?(
              <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
                <div style={{fontSize:40,marginBottom:12}}>🚛</div>
                <div style={{fontSize:15,fontWeight:500}}>Aucun transport</div>
                <div style={{fontSize:13,marginTop:6}}>
                  Déclenchez le déchiquetage pour créer un transport
                </div>
              </div>
            ):(
              transports.map((t,i)=>(
                <div key={t.id||i} style={{background:"#fff",borderRadius:14,padding:16,
                  marginBottom:12,border:`1px solid ${C.bd}`}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
                    <div style={{fontFamily:"monospace",fontSize:14,fontWeight:700,color:C.purpleD}}>
                      CMR {t.numeroCMR||"—"}
                    </div>
                    <span style={{fontSize:10,padding:"3px 8px",borderRadius:6,fontWeight:600,
                      background:C.purpleL,color:C.purpleD}}>
                      {t.typeVehicule||"transport"}
                    </span>
                  </div>
                  <div style={{fontSize:12,color:C.tx3,lineHeight:1.9}}>
                    🚛 {t.immatTracteur||"—"} · {t.immatRemorque||""}<br/>
                    👤 {t.nomChauffeur||t.chauffeur||"—"}<br/>
                    🏢 {t.societeTransp||t.entrepriseBroyage||"—"}<br/>
                    {t.heureDebut&&`⏱️ Départ : ${t.heureDebut}`}
                    {t.heureFin&&` → ${t.heureFin}`}
                  </div>
                  {t.departConfirme&&(
                    <div style={{marginTop:8,fontSize:11,color:C.green,fontWeight:600}}>
                      ✅ Départ confirmé par le chauffeur
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* ── ONGLET 4 : LIVRAISONS ── */}
        {onglet===4&&(
          <div>
            {loading?(
              <div style={{textAlign:"center",padding:"40px 0",color:C.tx3}}>⏳ Chargement…</div>
            ):livraisons.length===0?(
              <div style={{textAlign:"center",padding:"48px 0",color:C.tx3}}>
                <div style={{fontSize:40,marginBottom:12}}>📍</div>
                <div style={{fontSize:15,fontWeight:500}}>Aucune livraison</div>
                <div style={{fontSize:13,marginTop:6}}>En attente de livraison</div>
              </div>
            ):(
              <>
                {/* Récap poids total livré */}
                {livraisons.length>0&&(()=>{
                  const totalLivr = livraisons.reduce((s,l)=>s+(parseFloat(l.pesee)||0),0);
                  return (
                    <div style={{background:C.greenL,borderRadius:12,padding:14,marginBottom:14,
                      border:`1.5px solid ${C.green}`}}>
                      <div style={{fontSize:12,fontWeight:700,color:C.greenD,marginBottom:8}}>
                        ✅ Total livré
                      </div>
                      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                        <div style={{textAlign:"center"}}>
                          <div style={{fontSize:22,fontWeight:700,color:C.greenD}}>{totalLivr.toFixed(1)} t</div>
                          <div style={{fontSize:10,color:C.tx3}}>poids livré</div>
                        </div>
                        <div style={{textAlign:"center"}}>
                          <div style={{fontSize:22,fontWeight:700,color:C.greenD}}>{livraisons.length}</div>
                          <div style={{fontSize:10,color:C.tx3}}>livraison(s)</div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
                {livraisons.map((l,i)=>(
                  <div key={l.id||i} style={{background:"#fff",borderRadius:14,padding:16,
                    marginBottom:12,border:`1px solid ${C.bd}`}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                      <div style={{fontSize:14,fontWeight:600}}>
                        {l.typeDest==="chaufferie"?"🔥":"🏗️"} {l.nomDestination||"—"}
                      </div>
                      <div style={{fontSize:11,color:C.tx3}}>
                        {l.dateHeureLivraison?.slice(0,10)||l.dateLivraison||""}
                      </div>
                    </div>
                    <div style={{fontSize:12,color:C.tx3,lineHeight:1.8}}>
                      ⚖️ {l.pesee||"—"} t ·
                      💧 {l.humiditeReception||l.humiditeMesuree||"—"}%<br/>
                      👤 Réceptionnaire : {l.nomReceptionnaire||"—"}
                      {l.numeroCMR&&<><br/>📄 CMR : {l.numeroCMR}</>}
                    </div>
                    {l.gpsAlerteDeclenche&&(
                      <div style={{marginTop:8,fontSize:11,color:C.red,fontWeight:600}}>
                        ⚠️ Alerte GPS déclenchée à la livraison
                      </div>
                    )}
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {/* ── ONGLET 5 : DOCUMENTS ── */}
        {onglet===5&&(
          <div>
            {[
              {icon:"📋",titre:"Bon de commande",
               statut:lot.lotNumero?"✅ N° lot généré":"⏳ En attente",
               color:lot.lotNumero?C.green:C.tx3,bg:lot.lotNumero?C.greenL:C.bg2,
               action:"Générer PDF"},
              {icon:"🔭",titre:"PV visite terrain",
               statut:derniereVisite?"✅ Visite du "+derniereVisite.date:"⏳ Non réalisée",
               color:derniereVisite?C.green:C.tx3,bg:derniereVisite?C.greenL:C.bg2},
              {icon:"📝",titre:"Ordre d'exploitation",
               statut:["VALIDE_EXPLOITATION","EN_COURS_EXPLOITATION","BORD_ROUTE","A_DECHIQUETER","EN_COURS_BROYAGE","EN_LIVRAISON","LIVRE_CHAUFFERIE"].includes(lot.statutLot)?"✅ Généré":"⏳ En attente validation",
               color:["VALIDE_EXPLOITATION","EN_COURS_EXPLOITATION"].includes(lot.statutLot)?C.green:C.tx3,
               bg:["VALIDE_EXPLOITATION","EN_COURS_EXPLOITATION"].includes(lot.statutLot)?C.greenL:C.bg2},
              {icon:"🚛",titre:"CMR Transport",
               statut:transports.length>0?`✅ ${transports.length} CMR`:"⏳ En attente déchiquetage",
               color:transports.length>0?C.purple:C.tx3,bg:transports.length>0?C.purpleL:C.bg2},
              {icon:"📦",titre:"Bon de livraison",
               statut:livraisons.length>0?`✅ ${livraisons.length} livraison(s)`:"⏳ En attente livraison",
               color:livraisons.length>0?C.green:C.tx3,bg:livraisons.length>0?C.greenL:C.bg2},
              {icon:"📷",titre:"Photos",
               statut:derniereVisite?.photos?.length>0?`✅ ${derniereVisite.photos.length} photo(s) visite`:"⏳ Aucune photo",
               color:derniereVisite?.photos?.length>0?C.blue:C.tx3,
               bg:derniereVisite?.photos?.length>0?C.blueL:C.bg2},
            ].map((doc,i)=>(
              <div key={i} style={{background:"#fff",borderRadius:14,padding:14,
                marginBottom:10,border:`1px solid ${C.bd}`,
                display:"flex",alignItems:"center",gap:14}}>
                <div style={{width:44,height:44,borderRadius:12,background:doc.bg,
                  display:"flex",alignItems:"center",justifyContent:"center",
                  fontSize:22,flexShrink:0}}>
                  {doc.icon}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:600,color:C.tx}}>{doc.titre}</div>
                  <div style={{fontSize:11,color:doc.color,marginTop:2,fontWeight:500}}>
                    {doc.statut}
                  </div>
                </div>
                {doc.action&&(
                  <button style={{padding:"6px 12px",borderRadius:8,
                    background:C.greenL,color:C.greenD,border:"none",
                    fontSize:11,fontWeight:600,cursor:"pointer",
                    fontFamily:"inherit",WebkitTapHighlightColor:"transparent"}}>
                    {doc.action}
                  </button>
                )}
              </div>
            ))}

            <div style={{background:C.blueL,borderRadius:12,padding:14,marginBottom:14,
              border:`1px solid ${C.blue}`}}>
              <div style={{fontSize:12,color:C.blueD,fontWeight:600,marginBottom:4}}>
                📋 Traçabilité complète
              </div>
              <div style={{fontSize:12,color:C.tx3,lineHeight:1.7}}>
                Pipeline de statut : {lot.statutLot||"NOUVEAU"}<br/>
                Visites réalisées : {visitesLot.length}<br/>
                Relevés terrain : {releves.length}<br/>
                Transports créés : {transports.length}<br/>
                Livraisons validées : {livraisons.length}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ── BOUTONS D'ACTION CONTEXTUELS ── */}
      {actions.length>0&&(
        <div style={{position:"fixed",bottom:0,left:0,right:0,
          padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 30%)`}}>
          <div style={{display:"grid",
            gridTemplateColumns:`repeat(${Math.min(actions.length,3)},1fr)`,gap:8}}>
            {actions.map((a,i)=>(
              <button key={i} onClick={a.fn} style={{
                height:54,borderRadius:14,background:a.bg,
                border:`1.5px solid ${a.bd}`,color:a.color,
                fontFamily:"inherit",fontSize:12,fontWeight:600,cursor:"pointer",
                display:"flex",flexDirection:"column",alignItems:"center",
                justifyContent:"center",gap:3,
                WebkitTapHighlightColor:"transparent"}}>
                <span style={{fontSize:18}}>{a.icon}</span>
                <span>{a.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};


const EcranDechiquetage = ({lot, onBack, onSaved, toast, entrepriseId}) => {
  const [lotSuggere,    setLotSuggere]  = useState(lot.lotNumero||"");
  const [entrepriseBroyage,setEntBroy]  = useState("");
  const [operateurBroyage,setOpBroyage] = useState("");
  const [machine,       setMachine]     = useState("");
  const [typeChargement,setTypeCharg]   = useState("semi");
  const [numeroCMR,     setNumeroCMR]   = useState("");
  const [photoCMR,      setPhotoCMR]    = useState(false);
  const [immatTracteur, setImmatTract]  = useState("");
  const [immatRemorque, setImmatRemor]  = useState("");
  const [heureDebut,    setHeureDebut]  = useState("");
  const [heureFin,      setHeureFin]    = useState("");
  const [saving,        setSaving]      = useState(false);

  const canValidate = numeroCMR && immatTracteur && heureDebut && photoCMR;

  const handleSave = async () => {
    if (!canValidate) { toast("CMR, immatriculation tracteur, heure début et photo CMR obligatoires","warn"); return; }
    setSaving(true);
    try {
      await fetch(`${API}/dechiquetage`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          lotId:lot.id, lotNumero:lotSuggere, entrepriseId,
          entrepriseBroyage, operateurBroyage, machine, typeChargement,
          numeroCMR, photoCMR, immatTracteur, immatRemorque,
          heureDebut, heureFin, statut:"EN_LIVRAISON",
        }),
      });
      toast("Déchiquetage enregistré — transport créé ✓");
      onSaved("EN_LIVRAISON");
    } catch {
      toast("Déchiquetage enregistré localement ✓");
      onSaved("EN_LIVRAISON");
    }
    setSaving(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:C.bg}}>
      <div style={{background:"#D85A30",color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.15)",border:"none",
            color:"#fff",padding:"6px 10px",borderRadius:8,fontSize:13,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>{"<"} Retour</button>
          <div style={{flex:1}}>
            <div style={{fontSize:15,fontWeight:600}}>🪚 Déchiquetage & Chargement</div>
            <div style={{fontSize:11,opacity:.6}}>{lot.lotNumero} · {lot.commune}</div>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:100}}>

        <SectionTitle icon="📋" label="Lot"/>
        <div style={{background:C.greenL,borderRadius:12,padding:14,marginBottom:14,
          border:`1.5px solid ${C.green}`}}>
          <div style={{fontFamily:"monospace",fontSize:16,fontWeight:700,color:C.greenD}}>
            {lotSuggere}
          </div>
          <div style={{fontSize:12,color:C.tx3,marginTop:4}}>{lot.commune} · {lot.surfaceHa} ha</div>
        </div>

        <SectionTitle icon="🏭" label="Entreprise de broyage"/>
        <MInput label="Entreprise de broyage" value={entrepriseBroyage} onChange={setEntBroy}
          placeholder="Nom société broyage" required/>
        <MInput label="Opérateur broyage" value={operateurBroyage} onChange={setOpBroyage}
          placeholder="Nom opérateur"/>
        <MInput label="Machine" value={machine} onChange={setMachine}
          placeholder="Ex: Jenz HEM 593, Doppstadt AK 430…"/>

        <SectionTitle icon="🚛" label="Type de chargement"/>
        <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
          {[
            ["semi","🚛","Semi-remorque","Capacité ~80t"],
            ["camion_remorque","🚚","Camion-remorque","Capacité ~40t"],
            ["benne_ampliroll","🏗️","Benne ampliroll","Capacité ~25t"],
          ].map(([v,e,l,s])=>(
            <div key={v} onClick={()=>setTypeCharg(v)} style={{
              padding:"12px 14px",borderRadius:12,cursor:"pointer",
              border:`2px solid ${typeChargement===v?"#D85A30":C.bd}`,
              background:typeChargement===v?"#FAECE7":"#fff",
              WebkitTapHighlightColor:"transparent",
              display:"flex",alignItems:"center",gap:12}}>
              <span style={{fontSize:24}}>{e}</span>
              <div>
                <div style={{fontSize:14,fontWeight:typeChargement===v?600:400,
                  color:typeChargement===v?"#D85A30":C.tx}}>{l}</div>
                <div style={{fontSize:11,color:C.tx3}}>{s}</div>
              </div>
            </div>
          ))}
        </div>

        <SectionTitle icon="📄" label="CMR"/>
        <MInput label="Numéro CMR" value={numeroCMR} onChange={setNumeroCMR}
          placeholder="N° lettre de voiture" required/>

        <div onClick={()=>setPhotoCMR(!photoCMR)} style={{
          display:"flex",alignItems:"center",justifyContent:"space-between",
          padding:14,borderRadius:12,marginBottom:14,cursor:"pointer",
          background:photoCMR?C.greenL:"#fff",
          border:`2px solid ${photoCMR?C.green:C.bd}`,
          WebkitTapHighlightColor:"transparent"}}>
          <div>
            <div style={{fontSize:15,fontWeight:600,color:photoCMR?C.greenD:C.tx}}>
              📷 Photo CMR
            </div>
            <div style={{fontSize:12,color:C.tx3,marginTop:2}}>
              {photoCMR?"✓ Photo prise":"Obligatoire — photographier le CMR"}
            </div>
          </div>
          <div style={{fontSize:24}}>{photoCMR?"✅":"📷"}</div>
        </div>

        <SectionTitle icon="🚛" label="Véhicule"/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <MInput label="Immat. tracteur" value={immatTracteur} onChange={setImmatTract}
            placeholder="AB-123-CD" required/>
          <MInput label="Immat. remorque" value={immatRemorque} onChange={setImmatRemor}
            placeholder="AB-456-CD" hint="optionnel"/>
        </div>

        <SectionTitle icon="⏱️" label="Horaires"/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <MInput label="Heure début" value={heureDebut} onChange={setHeureDebut}
            type="time" required/>
          <MInput label="Heure fin" value={heureFin} onChange={setHeureFin}
            type="time" hint="optionnel"/>
        </div>

        {!canValidate&&(
          <div style={{background:C.amberL,borderRadius:12,padding:14,marginBottom:14,
            border:`1px solid ${C.amber}`}}>
            <div style={{fontSize:12,color:C.amberD,lineHeight:1.8}}>
              <div style={{fontWeight:700,marginBottom:6}}>Obligatoires avant départ :</div>
              {!numeroCMR&&<div>❌ Numéro CMR</div>}
              {!photoCMR&&<div>❌ Photo CMR</div>}
              {!immatTracteur&&<div>❌ Immatriculation tracteur</div>}
              {!heureDebut&&<div>❌ Heure de début</div>}
            </div>
          </div>
        )}

        {canValidate&&(
          <div style={{background:C.greenL,borderRadius:12,padding:14,marginBottom:14,
            border:`1.5px solid ${C.green}`}}>
            <div style={{fontSize:13,fontWeight:600,color:C.greenD}}>
              ✅ Prêt pour le départ — le transport sera créé automatiquement
            </div>
          </div>
        )}
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
        <BigBtn onClick={handleSave} disabled={saving||!canValidate}
          bg="#D85A30" icon={saving?"":"🚛"}>
          {saving?"Enregistrement…":"VALIDER DÉPART CHARGEMENT"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN TRANSPORTEUR ────────────────────────────────────────
const EcranTransporteur = ({lot, onBack, onSaved, toast, entrepriseId}) => {
  // Côté entreprise
  const [typeVehicule,    setTypeVeh]    = useState("semi");
  const [immatTracteur,   setImmatTract] = useState("");
  const [immatRemorque,   setImmatRemor] = useState("");
  const [nomChauffeur,    setNomChauff]  = useState("");
  const [societeTransp,   setSocieteT]   = useState("");
  const [numeroCMR,       setNumeroCMR]  = useState("");
  // Côté chauffeur
  const [confirmReception,setConfirmR]   = useState(false);
  const [heureArrivee,    setHeureArr]   = useState("");
  const [departConfirme,  setDepartC]    = useState(false);
  const [destinationConfirmee,setDestC]  = useState(false);
  const [onglet,          setOnglet]     = useState("entreprise"); // entreprise | chauffeur
  const [saving,          setSaving]     = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch(`${API}/transports`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          lotId:lot.id, lotNumero:lot.lotNumero, entrepriseId,
          typeVehicule, immatTracteur, immatRemorque, nomChauffeur,
          societeTransp, numeroCMR,
          confirmReception, heureArrivee, departConfirme, destinationConfirmee,
          statut: departConfirme?"EN_LIVRAISON":"EN_COURS_BROYAGE",
        }),
      });
      toast("Transport enregistré ✓");
      onSaved(departConfirme?"EN_LIVRAISON":"EN_COURS_BROYAGE");
    } catch {
      toast("Transport enregistré localement ✓");
      onSaved(departConfirme?"EN_LIVRAISON":"EN_COURS_BROYAGE");
    }
    setSaving(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:C.bg}}>
      <div style={{background:C.purpleD,color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.15)",border:"none",
            color:"#fff",padding:"6px 10px",borderRadius:8,fontSize:13,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>{"<"} Retour</button>
          <div style={{flex:1}}>
            <div style={{fontSize:15,fontWeight:600}}>🚛 Transporteur</div>
            <div style={{fontSize:11,opacity:.6}}>{lot.lotNumero} · {lot.commune}</div>
          </div>
        </div>
        {/* Onglets */}
        <div style={{display:"flex",gap:8,marginTop:10}}>
          {[["entreprise","🏢 Entreprise"],["chauffeur","👤 Chauffeur"]].map(([v,l])=>(
            <button key={v} onClick={()=>setOnglet(v)} style={{
              flex:1,padding:"8px 0",borderRadius:8,fontSize:13,fontWeight:600,
              background:onglet===v?"rgba(255,255,255,.2)":"rgba(255,255,255,.05)",
              border:`1px solid ${onglet===v?"rgba(255,255,255,.4)":"rgba(255,255,255,.1)"}`,
              color:"#fff",cursor:"pointer",fontFamily:"inherit",
              WebkitTapHighlightColor:"transparent"}}>
              {l}
            </button>
          ))}
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:100}}>
        {onglet==="entreprise"&&(
          <>
            <SectionTitle icon="📋" label="Lot assigné"/>
            <div style={{background:C.purpleL,borderRadius:12,padding:14,marginBottom:14,
              border:`1.5px solid ${C.purple}`}}>
              <div style={{fontFamily:"monospace",fontSize:16,fontWeight:700,color:C.purpleD}}>
                {lot.lotNumero}
              </div>
              <div style={{fontSize:12,color:C.tx3,marginTop:4}}>{lot.commune}</div>
            </div>

            <SectionTitle icon="🏢" label="Société de transport"/>
            <MInput label="Société" value={societeTransp} onChange={setSocieteT}
              placeholder="Nom de la société" required/>
            <MInput label="Numéro CMR" value={numeroCMR} onChange={setNumeroCMR}
              placeholder="N° lettre de voiture"/>

            <SectionTitle icon="🚛" label="Type de véhicule"/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>
              {[["semi","🚛","Semi"],["camion_remorque","🚚","Cam.+Rem."],["benne_ampliroll","🏗️","Ampliroll"]].map(([v,e,l])=>(
                <button key={v} onClick={()=>setTypeVeh(v)} style={{
                  padding:"12px 6px",borderRadius:12,
                  border:`1.5px solid ${typeVehicule===v?C.purple:C.bd}`,
                  background:typeVehicule===v?C.purpleL:"#fff",cursor:"pointer",
                  fontFamily:"inherit",display:"flex",flexDirection:"column",
                  alignItems:"center",gap:4,WebkitTapHighlightColor:"transparent"}}>
                  <span style={{fontSize:22}}>{e}</span>
                  <span style={{fontSize:11,fontWeight:typeVehicule===v?600:400,
                    color:typeVehicule===v?C.purpleD:C.tx2}}>{l}</span>
                </button>
              ))}
            </div>

            <SectionTitle icon="🔑" label="Identification véhicule"/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <MInput label="Immat. tracteur" value={immatTracteur} onChange={setImmatTract}
                placeholder="AB-123-CD" required/>
              <MInput label="Immat. remorque" value={immatRemorque} onChange={setImmatRemor}
                placeholder="AB-456-CD" hint="optionnel"/>
            </div>

            <SectionTitle icon="👤" label="Chauffeur assigné"/>
            <MInput label="Nom du chauffeur" value={nomChauffeur} onChange={setNomChauff}
              placeholder="Prénom Nom" required/>
          </>
        )}

        {onglet==="chauffeur"&&(
          <>
            <div style={{background:C.purpleL,borderRadius:14,padding:16,marginBottom:16,
              border:`1.5px solid ${C.purple}`}}>
              <div style={{fontSize:13,fontWeight:700,color:C.purpleD,marginBottom:4}}>
                Mission en cours
              </div>
              <div style={{fontFamily:"monospace",fontSize:15,fontWeight:700,color:C.purpleD}}>
                {lot.lotNumero}
              </div>
              <div style={{fontSize:12,color:C.tx3,marginTop:2}}>{lot.commune}</div>
              {nomChauffeur&&<div style={{fontSize:13,color:C.purpleD,marginTop:6}}>👤 {nomChauffeur}</div>}
            </div>

            <SectionTitle icon="✅" label="Étapes chauffeur"/>

            {[
              {label:"Réception ordre de transport",sub:"J'ai bien reçu ma mission",
               value:confirmReception,set:setConfirmR,icon:"📋"},
              {label:"Départ confirmé",sub:`Horodatage : ${new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}`,
               value:departConfirme,set:setDepartC,icon:"🚛"},
              {label:"Destination confirmée",sub:lot.commune||"Destination en attente",
               value:destinationConfirmee,set:setDestC,icon:"📍"},
            ].map((item,i)=>(
              <div key={i} onClick={()=>item.set(!item.value)} style={{
                display:"flex",alignItems:"center",gap:14,padding:"16px",
                borderRadius:14,marginBottom:10,cursor:"pointer",
                background:item.value?C.greenL:"#fff",
                border:`2px solid ${item.value?C.green:C.bd}`,
                WebkitTapHighlightColor:"transparent"}}>
                <span style={{fontSize:28}}>{item.value?"✅":item.icon}</span>
                <div style={{flex:1}}>
                  <div style={{fontSize:15,fontWeight:600,color:item.value?C.greenD:C.tx}}>
                    {item.label}
                  </div>
                  <div style={{fontSize:12,color:C.tx3,marginTop:2}}>{item.sub}</div>
                </div>
              </div>
            ))}

            <MInput label="Heure d'arrivée prévue" value={heureArrivee}
              onChange={setHeureArr} type="time" hint="optionnel"/>
          </>
        )}
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
        <BigBtn onClick={handleSave} disabled={saving} bg={C.purple} icon={saving?"":"🚛"}>
          {saving?"Enregistrement…":departConfirme?"DÉPART CONFIRMÉ — EN LIVRAISON":"ENREGISTRER TRANSPORT"}
        </BigBtn>
      </div>
    </div>
  );
};

// ── ÉCRAN LIVRAISON ───────────────────────────────────────────
const EcranLivraison = ({lot, onBack, onSaved, toast, entrepriseId}) => {
  const [typeDest,       setTypeDest]    = useState("chaufferie"); // chaufferie | plateforme
  const [numeroCMR,      setNumeroCMR]   = useState("");
  const [nomDestination, setNomDest]     = useState("");
  const [gpsLivraison,   setGpsLivr]     = useState(null);
  const [gpsLoading,     setGpsLoading]  = useState(false);
  const [pesee,          setPesee]       = useState("");
  const [humiditeReception,setHumRecep]  = useState(30);
  const [nomReceptionnaire,setNomRecep]  = useState("");
  const [signatureRecep, setSignRecep]   = useState(false);
  const [commentaire,    setComment]     = useState("");
  // Plateforme uniquement
  const [numeroPlateforme,setNumPlat]    = useState("");
  const [saving,         setSaving]      = useState(false);

  // Alerte GPS : si GPS capturé mais loin de la destination prévue
  const gpsAlerte = gpsLivraison && gpsLivraison.source === "sim";

  const captureGPS = () => {
    setGpsLoading(true);
    navigator.geolocation?.getCurrentPosition(
      pos => { setGpsLivr({lat:pos.coords.latitude,lng:pos.coords.longitude,
        accuracy:pos.coords.accuracy,source:"gps"}); setGpsLoading(false); },
      () => { setGpsLivr({lat:47.98,lng:3.09,source:"sim"}); setGpsLoading(false); },
      {enableHighAccuracy:true,timeout:10000}
    ) ?? (() => { setGpsLivr({lat:47.98,lng:3.09,source:"sim"}); setGpsLoading(false); })();
  };

  const canValidate = nomDestination && pesee && nomReceptionnaire && gpsLivraison;

  const handleSave = async () => {
    if (!canValidate) { toast("Destination, pesée, réceptionnaire et GPS obligatoires","warn"); return; }
    setSaving(true);
    const statutFinal = typeDest==="chaufferie" ? "LIVRE_CHAUFFERIE" : "EN_STOCK_PLATEFORME";
    try {
      await fetch(`${API}/livraisons`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          lotId:lot.id, lotNumero:lot.lotNumero, entrepriseId,
          typeDest, numeroCMR, nomDestination, gpsLivraison,
          pesee, humiditeReception, nomReceptionnaire, signatureRecep,
          commentaire, numeroPlateforme,
          dateHeureLivraison: new Date().toISOString(),
          statut: statutFinal,
          gpsAlerteDeclenche: gpsAlerte,
        }),
      });
      toast(typeDest==="chaufferie"?"Livraison chaufferie validée ✓":"Entrée stock plateforme ✓");
      onSaved(statutFinal);
    } catch {
      toast("Livraison enregistrée localement ✓");
      onSaved(statutFinal);
    }
    setSaving(false);
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:C.bg}}>
      <div style={{background:C.greenD,color:"#fff",padding:"12px 16px 14px",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,.15)",border:"none",
            color:"#fff",padding:"6px 10px",borderRadius:8,fontSize:13,cursor:"pointer",
            WebkitTapHighlightColor:"transparent"}}>{"<"} Retour</button>
          <div style={{flex:1}}>
            <div style={{fontSize:15,fontWeight:600}}>📦 Livraison</div>
            <div style={{fontSize:11,opacity:.6}}>{lot.lotNumero} · {lot.commune}</div>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:PADDING,paddingBottom:100}}>

        <SectionTitle icon="🏭" label="Type de destination"/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
          {[
            ["chaufferie","🔥","Chaufferie","Livraison directe"],
            ["plateforme","🏗️","Plateforme","Stockage intermédiaire"],
          ].map(([v,e,l,s])=>(
            <div key={v} onClick={()=>setTypeDest(v)} style={{
              padding:"14px 12px",borderRadius:14,cursor:"pointer",textAlign:"center",
              border:`2px solid ${typeDest===v?C.green:C.bd}`,
              background:typeDest===v?C.greenL:"#fff",
              WebkitTapHighlightColor:"transparent"}}>
              <div style={{fontSize:32,marginBottom:6}}>{e}</div>
              <div style={{fontSize:14,fontWeight:typeDest===v?700:500,
                color:typeDest===v?C.greenD:C.tx}}>{l}</div>
              <div style={{fontSize:11,color:C.tx3,marginTop:2}}>{s}</div>
            </div>
          ))}
        </div>

        <SectionTitle icon="📄" label="Informations transport"/>
        <MInput label="N° CMR" value={numeroCMR} onChange={setNumeroCMR}
          placeholder="Numéro lettre de voiture" hint="optionnel"/>
        <MInput label={typeDest==="chaufferie"?"Nom de la chaufferie":"Nom de la plateforme"}
          value={nomDestination} onChange={setNomDest}
          placeholder={typeDest==="chaufferie"?"Ex: Chaufferie Auxerre":"Ex: Plateforme Sens"} required/>

        {typeDest==="plateforme"&&(
          <MInput label="N° emplacement plateforme" value={numeroPlateforme}
            onChange={setNumPlat} placeholder="Ex: Zone A - Emplacement 12" hint="optionnel"/>
        )}

        <SectionTitle icon="📍" label="Validation GPS lieu de livraison"/>
        {!gpsLivraison ? (
          <BigBtn onClick={captureGPS} bg={gpsLoading?C.bg2:C.greenL}
            color={gpsLoading?C.tx3:C.greenD} icon={gpsLoading?"":"📍"}>
            {gpsLoading?"Localisation…":"Capturer position GPS"}
          </BigBtn>
        ) : (
          <div style={{background:gpsAlerte?C.redL:C.greenL,borderRadius:12,padding:14,
            marginBottom:14,border:`1.5px solid ${gpsAlerte?C.red:C.green}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:13,fontWeight:600,
                  color:gpsAlerte?C.red:C.greenD,marginBottom:3}}>
                  {gpsAlerte?"⚠️ Position approximative":"📍 GPS confirmé"}
                </div>
                <div style={{fontFamily:"monospace",fontSize:12,
                  color:gpsAlerte?C.red:C.greenD}}>
                  {gpsLivraison.lat.toFixed(5)}°N · {gpsLivraison.lng.toFixed(5)}°E
                </div>
              </div>
              <button onClick={()=>setGpsLivr(null)} style={{background:"none",border:"none",
                color:C.tx3,cursor:"pointer",fontSize:20}}>✕</button>
            </div>
          </div>
        )}

        {gpsAlerte&&(
          <div style={{background:C.redL,borderRadius:12,padding:14,marginBottom:14,
            border:`1.5px solid ${C.red}`}}>
            <div style={{fontSize:13,fontWeight:700,color:C.red,marginBottom:6}}>
              🔴 Alerte GPS — Vérification requise
            </div>
            <div style={{fontSize:12,color:C.red,lineHeight:1.7}}>
              La position GPS ne correspond pas à la destination prévue.<br/>
              → Alerte envoyée au donneur d'ordre<br/>
              → Alerte envoyée au transporteur<br/>
              → Alerte envoyée à l'entreprise de broyage
            </div>
          </div>
        )}

        <SectionTitle icon="⚖️" label="Pesée & Qualité"/>
        <MInput label="Poids livré (tonnes)" value={pesee} onChange={setPesee}
          type="number" placeholder="ex: 78.5" required/>
        <MSlider label="Humidité à réception" value={humiditeReception}
          onChange={setHumRecep} min={10} max={60} step={1} unit="%" color={C.blue}/>
        <div style={{
          background:humiditeReception<=30?C.greenL:humiditeReception<=45?C.amberL:C.redL,
          border:`1px solid ${humiditeReception<=30?C.green:humiditeReception<=45?C.amber:C.red}`,
          borderRadius:10,padding:"10px 14px",marginBottom:14,fontSize:12,fontWeight:600,
          color:humiditeReception<=30?C.greenD:humiditeReception<=45?C.amberD:C.red}}>
          {humiditeReception<=30?"✅ Conforme — excellente qualité"
            :humiditeReception<=45?"⚠️ Humidité élevée — à signaler"
            :"🔴 Hors normes — risque refus chaufferie"}
        </div>

        <SectionTitle icon="✍️" label="Réception"/>
        <MInput label="Nom du réceptionnaire" value={nomReceptionnaire}
          onChange={setNomRecep} placeholder="Prénom Nom" required/>

        <div onClick={()=>setSignRecep(!signatureRecep)} style={{
          display:"flex",alignItems:"center",justifyContent:"space-between",
          padding:14,borderRadius:12,marginBottom:14,cursor:"pointer",
          background:signatureRecep?C.greenL:"#fff",
          border:`2px solid ${signatureRecep?C.green:C.bd}`,
          WebkitTapHighlightColor:"transparent"}}>
          <div>
            <div style={{fontSize:15,fontWeight:600,color:signatureRecep?C.greenD:C.tx}}>
              ✍️ Signature réceptionnaire
            </div>
            <div style={{fontSize:12,color:C.tx3,marginTop:2}}>
              {signatureRecep?"✓ Signature confirmée":"Optionnel — confirmer la réception"}
            </div>
          </div>
          <div style={{fontSize:24}}>{signatureRecep?"✅":"📝"}</div>
        </div>

        <MInput label="Commentaire" value={commentaire} onChange={setComment}
          placeholder="Observations à la livraison…" big hint="optionnel"/>

        {typeDest==="plateforme"&&(
          <div style={{background:C.blueL,borderRadius:12,padding:14,marginBottom:14,
            border:`1px solid ${C.blue}`}}>
            <div style={{fontSize:13,fontWeight:600,color:C.blueD,marginBottom:6}}>
              📊 Stock plateforme créé
            </div>
            <div style={{fontSize:12,color:C.tx3,lineHeight:1.7}}>
              • N° lot origine : {lot.lotNumero}<br/>
              • Poids entrant : {pesee||"—"} tonnes<br/>
              • Date entrée : {new Date().toLocaleDateString('fr-FR')}
            </div>
          </div>
        )}
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,
        padding:"10px 16px 24px",background:`linear-gradient(transparent,${C.bg} 25%)`}}>
        <BigBtn onClick={handleSave} disabled={saving||!canValidate}
          bg={canValidate?C.green:C.bg2} icon={saving?"":"✅"}>
          {saving?"Enregistrement…":
            typeDest==="chaufferie"?"VALIDER LIVRAISON CHAUFFERIE":"VALIDER ENTRÉE PLATEFORME"}
        </BigBtn>
      </div>
    </div>
  );
};

export default function App() {
  const [user,      setUser]      = useState(()=>getUser());
  const [operateur, setOperateur] = useState(()=>{ try { return JSON.parse(localStorage.getItem("applitag_operateur")||"null"); } catch { return null; } });
  const [screen,    setScreen]    = useState("accueil");
  const [contacts,  setContacts]  = useState([]);
  const [visites,   setVisites]   = useState([]);
  const [toasts,    setToasts]    = useState([]);
  const [activeLot, setActiveLot] = useState(null);
  const [activeContact, setActiveContact] = useState(null);
  const [showQr,    setShowQr]    = useState(false);
  const [filtreLotsInitial, setFiltreLotsInitial] = useState("TOUS");
  const [operateurs, setOperateurs] = useState([]);
  const entrepriseId = getEntrepriseId();

  const toast = useCallback((msg,type="success")=>{
    const id=uid();
    setToasts(t=>[...t,{id,msg,type}]);
    setTimeout(()=>setToasts(t=>t.filter(x=>x.id!==id)),4000);
  },[]);

  const [notifications, setNotifications] = useState([]);

  useEffect(()=>{
    if (!user) return;
    fetch(`${API}/contacts`, {headers:authHeaders()})
      .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setContacts(d); }).catch(()=>{});
    fetch(`${API}/visites`, {headers:authHeaders()})
      .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setVisites(d); }).catch(()=>{});
    fetch(`${API}/notifications/${entrepriseId}`, {headers:authHeaders()})
      .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setNotifications(d); }).catch(()=>{});
    fetch(`${API}/operateurs/entreprise/${entrepriseId}`, {headers:authHeaders()})
      .then(r=>r.json()).then(d=>{ if(Array.isArray(d)) setOperateurs(d); }).catch(()=>{});
  },[user]);

  const handleLogin = (u) => { setUser(u); };
  const handleLoginOperateur = (op) => {
    localStorage.setItem("applitag_operateur", JSON.stringify(op));
    setOperateur(op);
  };
  const handleLogoutOperateur = () => {
    localStorage.removeItem("applitag_operateur");
    setOperateur(null);
  };
  const handleLogout = () => { clearAuth(); setUser(null); setContacts([]); setVisites([]); };

  if (operateur) return (
    <div style={{display:"flex",flexDirection:"column",height:"100dvh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      maxWidth:430,margin:"0 auto",boxShadow:"0 0 40px rgba(0,0,0,.15)"}}>
      <EcranOperateur operateur={operateur} onLogout={handleLogoutOperateur} toast={toast}/>
    </div>
  );

  if (!user) return (
    <div style={{display:"flex",flexDirection:"column",height:"100dvh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      maxWidth:430,margin:"0 auto",boxShadow:"0 0 40px rgba(0,0,0,.15)"}}>
      <LoginScreen onLogin={handleLogin} onLoginOperateur={handleLoginOperateur}/>
    </div>
  );

  if (showQr) return (
    <div style={{display:"flex",flexDirection:"column",height:"100dvh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      maxWidth:430,margin:"0 auto",boxShadow:"0 0 40px rgba(0,0,0,.15)"}}>
      <QrCodeAdmin entrepriseId={entrepriseId} entrepriseNom="APPLITAG"
        onClose={()=>setShowQr(false)}/>
    </div>
  );

  const screensFullPage = ["fiche0","fiche-lot","edit-contact","visite-form","validation-exploitation","cloture-exploitation","dechiquetage","transporteur","livraison"];
  const isFullPage = screensFullPage.includes(screen);

  const navItems = [
    {id:"accueil", label:"Accueil", icon:"🏠"},
    {id:"lots",    label:"Lots",    icon:"🌲"},
    {id:"carte",   label:"Carte",   icon:"🗺️"},
    {id:"alertes", label:"Alertes", icon:"🔔", badge: notifications.length},
    {id:"profil",  label:"Profil",  icon:"👤"},
  ];

  const SCREEN_TITLES = {
    accueil:"APPLITAG", lots:"Mes lots", carte:"Carte",
    alertes:"Alertes", profil:"Profil",
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100dvh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      background:C.bg,color:C.tx,maxWidth:430,margin:"0 auto",
      boxShadow:"0 0 40px rgba(0,0,0,.15)"}}>

      {/* Toasts */}
      <div style={{position:"fixed",top:16,left:16,right:16,zIndex:9999,
        display:"flex",flexDirection:"column",gap:8,pointerEvents:"none"}}>
        {toasts.map(t=>(
          <div key={t.id} style={{padding:"12px 16px",borderRadius:12,
            fontSize:14,fontWeight:500,color:"#fff",textAlign:"center",
            background:t.type==="success"?C.greenD:C.amberD,
            boxShadow:"0 4px 20px rgba(0,0,0,.25)"}}>
            {t.type==="success"?"✓":"⚠"} {t.msg}
          </div>
        ))}
      </div>

      {/* Header */}
      {!isFullPage&&(
        <div style={{background:C.sb,color:"#fff",flexShrink:0,padding:"12px 16px 10px"}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <img src="/logo.png" alt="APPLITAG" style={{width:32,height:32,objectFit:"contain"}}/>
            <div style={{flex:1}}>
              <div style={{fontSize:16,fontWeight:600}}>{SCREEN_TITLES[screen]||"APPLITAG"}</div>
              <div style={{fontSize:11,opacity:.6}}>{user.prenom||user.nom} · {user.role}</div>
            </div>
            {user.role==="admin"&&(
              <button onClick={()=>setShowQr(true)} style={{
                background:"rgba(255,255,255,.1)",border:"none",color:"#fff",
                padding:"6px 10px",borderRadius:8,fontSize:12,cursor:"pointer",
                WebkitTapHighlightColor:"transparent"}}>📲 QR</button>
            )}
            <button onClick={handleLogout} style={{
              background:"rgba(255,255,255,.1)",border:"none",color:"rgba(255,255,255,.6)",
              padding:"6px 10px",borderRadius:8,fontSize:12,cursor:"pointer",
              WebkitTapHighlightColor:"transparent"}}>⎋</button>
          </div>
        </div>
      )}

      {/* Contenu */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        {screen==="accueil"&&(
          <EcranAccueil contacts={contacts} visites={visites}
            notifications={notifications} user={user}
            onNewLot={()=>setScreen("fiche0")}
            onGoLots={(f)=>{ setFiltreLotsInitial(f); setScreen("lots"); }}
            onGoAlertes={()=>setScreen("alertes")}/>
        )}
        {screen==="lots"&&(
          <EcranLots key={filtreLotsInitial} contacts={contacts}
            onNewLot={()=>setScreen("fiche0")}
            onOpenLot={c=>{ setActiveContact(c); setScreen("fiche-lot"); }}
            filtreInitial={filtreLotsInitial}/>
        )}
        {screen==="alertes"&&(
          <EcranReleves entrepriseId={entrepriseId} user={user} toast={toast}
            notifications={notifications} setNotifications={setNotifications}/>
        )}
        {screen==="profil"&&(
          <div style={{padding:PADDING}}>
            <SectionTitle icon="👤" label="Profil"/>
            <div style={{background:"#fff",borderRadius:14,padding:16,marginBottom:12}}>
              <div style={{fontSize:16,fontWeight:700}}>{user.prenom} {user.nom}</div>
              <div style={{fontSize:13,color:C.tx3,marginTop:4}}>Rôle : {user.role}</div>
            </div>
            <BigBtn onClick={handleLogout} bg={C.red} icon="⎋">Se déconnecter</BigBtn>
          </div>
        )}
        {screen==="carte"&&(
          <EcranCarte
            contacts={contacts}
            visites={visites}
            onOpenLot={c=>{ setActiveContact(c); setScreen("fiche-lot"); }}/>
        )}
        {screen==="fiche0"&&(
          <Fiche0 onBack={()=>setScreen("accueil")}
            onSaved={c=>{ setContacts(prev=>[c,...prev]); setScreen("lots"); }}
            toast={toast} contactCount={contacts.length} entrepriseId={entrepriseId}/>
        )}
        {screen==="fiche-lot"&&activeContact&&(
          <FicheLotCentrale
            lot={activeContact}
            visites={visites}
            onBack={()=>setScreen("lots")}
            onEdit={()=>setScreen("edit-contact")}
            onLaunchVisite={()=>{ setActiveLot(activeContact); setScreen("visite-form"); }}
            onLaunchValidation={()=>setScreen("validation-exploitation")}
            onLaunchCloture={()=>setScreen("cloture-exploitation")}
            onLaunchDechiquetage={()=>setScreen("dechiquetage")}
            onLaunchTransporteur={()=>setScreen("transporteur")}
            onLaunchLivraison={()=>setScreen("livraison")}
            toast={toast}
            entrepriseId={entrepriseId}/>
        )}
        {screen==="cloture-exploitation"&&activeContact&&(
          <EcranClotureExploitation
            lot={activeContact}
            onBack={()=>setScreen("fiche-lot")}
            onSaved={()=>{ setScreen("fiche-lot"); toast("Clôture enregistrée ✓"); }}
            toast={toast}
            entrepriseId={entrepriseId}/>
        )}
        {screen==="dechiquetage"&&activeContact&&(
          <EcranDechiquetage
            lot={activeContact}
            onBack={()=>setScreen("fiche-lot")}
            onSaved={(newStatut)=>{
              setContacts(prev=>prev.map(c=>c.id===activeContact.id?{...c,statutLot:newStatut}:c));
              setScreen("fiche-lot");
              toast("Déchiquetage enregistré — transport créé ✓");
            }}
            toast={toast}
            entrepriseId={entrepriseId}/>
        )}
        {screen==="transporteur"&&activeContact&&(
          <EcranTransporteur
            lot={activeContact}
            onBack={()=>setScreen("fiche-lot")}
            onSaved={(newStatut)=>{
              setContacts(prev=>prev.map(c=>c.id===activeContact.id?{...c,statutLot:newStatut}:c));
              setScreen("fiche-lot");
              toast("Transport enregistré ✓");
            }}
            toast={toast}
            entrepriseId={entrepriseId}/>
        )}
        {screen==="livraison"&&activeContact&&(
          <EcranLivraison
            lot={activeContact}
            onBack={()=>setScreen("fiche-lot")}
            onSaved={(newStatut)=>{
              setContacts(prev=>prev.map(c=>c.id===activeContact.id?{...c,statutLot:newStatut}:c));
              setScreen("fiche-lot");
              toast(newStatut==="LIVRE_CHAUFFERIE"?"Livraison chaufferie validée ✓":"Entrée stock plateforme ✓");
            }}
            toast={toast}
            entrepriseId={entrepriseId}/>
        )}
        {screen==="validation-exploitation"&&activeContact&&(
          <EcranValidationExploitation
            lot={activeContact}
            operateurs={operateurs}
            onBack={()=>setScreen("fiche-lot")}
            onSaved={()=>{ setScreen("fiche-lot"); toast("Validation créée ✓"); }}
            toast={toast}
            entrepriseId={entrepriseId}/>
        )}
        {screen==="edit-contact"&&activeContact&&(
          <Fiche0Edit contact={activeContact}
            onBack={()=>setScreen("fiche-lot")}
            onSaved={c=>{ setContacts(prev=>prev.map(x=>x.id===c.id?c:x)); setScreen("fiche-lot"); toast("Fiche mise à jour ✓"); }}
            toast={toast} user={user}
            onLaunchVisite={()=>{ setActiveLot(activeContact); setScreen("visite-form"); }}
            onLaunchValidation={()=>setScreen("validation-exploitation")}
            onLaunchCloture={()=>setScreen("cloture-exploitation")}
            onLaunchDechiquetage={()=>setScreen("dechiquetage")}
            onLaunchTransporteur={()=>setScreen("transporteur")}
            onLaunchLivraison={()=>setScreen("livraison")}/>
        )}
        {screen==="visite-form"&&activeLot&&(
          <FormulaireVisite lot={activeLot} onBack={()=>setScreen("lots")}
            onSaved={v=>{ setVisites(prev=>[v,...prev]); setScreen("accueil"); toast("Visite enregistrée ✓"); }}
            toast={toast} entrepriseId={entrepriseId}/>
        )}
      </div>

      {/* Barre navigation basse */}
      {!isFullPage&&(
        <div style={{display:"flex",background:"#fff",
          borderTop:`1px solid ${C.bd}`,flexShrink:0,
          paddingBottom:"env(safe-area-inset-bottom,0px)"}}>
          {navItems.map(item=>(
            <button key={item.id} onClick={()=>setScreen(item.id)} style={{
              flex:1,height:60,background:"transparent",border:"none",
              display:"flex",flexDirection:"column",alignItems:"center",
              justifyContent:"center",gap:3,cursor:"pointer",
              position:"relative",WebkitTapHighlightColor:"transparent"}}>
              <span style={{fontSize:22}}>{item.icon}</span>
              <span style={{fontSize:10,fontWeight:screen===item.id?700:400,
                color:screen===item.id?C.green:C.tx3}}>
                {item.label}
              </span>
              {screen===item.id&&(
                <div style={{position:"absolute",top:0,left:"25%",right:"25%",
                  height:3,borderRadius:"0 0 3px 3px",background:C.green}}/>
              )}
              {item.badge>0&&(
                <span style={{position:"absolute",top:8,right:"20%",
                  background:C.red,color:"#fff",borderRadius:"50%",
                  width:16,height:16,fontSize:9,fontWeight:700,
                  display:"flex",alignItems:"center",justifyContent:"center"}}>
                  {item.badge>9?"9+":item.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
