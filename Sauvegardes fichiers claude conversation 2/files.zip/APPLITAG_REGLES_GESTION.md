# APPLITAG — Règles de gestion
*Version 1.0 — 17 juin 2026*

---

## Pipeline des statuts

```
NOUVEAU
→ VISITE_PREVUE → VISITE_REALISEE
→ VALIDE_EXPLOITATION → EN_COURS_EXPLOITATION
→ BORD_ROUTE → A_DECHIQUETER
→ EN_COURS_BROYAGE → EN_LIVRAISON
→ LIVRE_CHAUFFERIE | EN_STOCK_PLATEFORME → LIVRE
```

---

## 1. RÈGLES LOT

**RG-LOT-001** — Chaque lot possède : numéro unique, statut unique, historique complet.

**RG-LOT-002** — Un lot ne peut être supprimé après : création chantier, création transport, ajout document officiel.

**RG-LOT-003** — Le statut évolue automatiquement selon les actions :
- Visite validée → VISITE_REALISEE
- Premier chantier démarré → EN_EXPLOITATION
- Tous les tas validés → BORD_ROUTE

---

## 2. RÈGLES VISITE TERRAIN

**RG-VISITE-001** — Obligatoire : GPS, au moins une photo, estimation volume, essence principale.

**RG-VISITE-002** — Visite validée = non modifiable sauf administrateur ou exploitant principal.

**RG-VISITE-003** — Validation visite peut générer : bon d'achat PDF, ordre exploitation, notification donneur d'ordre.

---

## 3. RÈGLES EXPLOITATION

**RG-EXP-001** — Chantier ne peut démarrer que si : lot validé, opérateurs affectés, autorisations présentes.

**RG-EXP-002** — Chaque opérateur doit saisir : production, tas, horaires, anomalies.

**RG-EXP-003** — Si aucune saisie opérateur : rappel automatique H+12, second rappel employeur H+24.

**RG-EXP-004** — Chaque tas doit être géolocalisé.

---

## 4. RÈGLES TAS

**RG-TAS-001** — Chaque tas appartient à : un lot, une opération, un emplacement GPS.

**RG-TAS-002** — Un tas ne peut être déchiqueté si : volume vide, géolocalisation absente, état non validé.

**RG-TAS-003** — Volume total des tas met à jour automatiquement le volume réel du lot.

---

## 5. RÈGLES DÉCHIQUETAGE

**RG-DECH-001** — Nécessite : lot validé, tas disponible, transport planifié.

**RG-DECH-002** — Chargement doit contenir : véhicule, chauffeur, CMR, heure départ.

**RG-DECH-003** — Validation départ déclenche : création transport, notification chauffeur, changement statut lot.

---

## 6. RÈGLES TRANSPORT

**RG-TRANS-001** — Chaque transport possède : chauffeur, véhicule, destination, CMR.

**RG-TRANS-002** — Chauffeur doit confirmer : prise mission, départ, arrivée.

**RG-TRANS-003** — GPS chauffeur comparé au lieu prévu et trajet attendu.

---

## 7. RÈGLES LIVRAISON

**RG-LIV-001** — Doit contenir : heure, lieu, poids, réceptionnaire.

**RG-LIV-002** — GPS livraison hors zone → alerte critique.

**RG-LIV-003** — Pesée met à jour : stock, tonnage livré, tonnage restant.

**RG-LIV-004** — Livraison peut être partielle ou complète.

---

## 8. RÈGLES HUMIDITÉ

**RG-HUM-001** — Taux d'humidité peut être : estimé, mesuré, importé depuis analyse.

**RG-HUM-002** — Si humidité > seuil contrat → alerte qualité.

---

## 9. RÈGLES DOCUMENTS

**RG-DOC-001** — Documents horodatés automatiquement.

**RG-DOC-002** — Documents obligatoires selon statut :

| Statut | Documents obligatoires |
|--------|----------------------|
| VISITE_REALISEE | Photo |
| EN_TRANSPORT | CMR |
| LIVRE | Pesée |

---

## 10. RÈGLES ALERTES

**Types :** GPS, retard, humidité, document manquant, incohérence volume, livraison non conforme.

**Niveaux :**
- INFO
- WARNING
- CRITIQUE

---

## 11. RÈGLES HISTORIQUE

**RG-HIST-001** — Chaque modification importante est historisée : utilisateur, ancienne valeur, nouvelle valeur, date.

---

## Écrans à développer

| Écran | Statut |
|-------|--------|
| Fiche 0 (contact) | ✅ Fait |
| Visite terrain | ✅ Fait |
| Relevés opérateur | ✅ Fait |
| Notifications | ✅ Fait |
| Validation exploitation | 🔲 À faire |
| Clôture exploitation | 🔲 À faire |
| Déchiquetage / Chargement | 🔲 À faire |
| Transporteur | 🔲 À faire |
| Livraison | 🔲 À faire |
| Fiche lot (vue centrale) | 🔲 À faire |
| Carte | 🔲 À faire |
| Documents | 🔲 À faire |
| Bon de commande PDF | 🔲 À faire |
| Signatures électroniques | 🔲 À faire |
| Analyse humidité | 🔲 À faire |
| Dashboard / synthèse | 🔲 À faire |
