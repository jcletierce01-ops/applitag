import { Injectable, ConflictException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class RelevesService {
  constructor(private prisma: PrismaService) {}

  async createAbatteur(data: any) {
    const dateJour = new Date(data.date).toISOString().slice(0,10);
    const existant = await (this.prisma as any).releveAbatteur.findFirst({
      where: {
        lotId: data.lotId,
        operateur: data.operateur,
        date: { startsWith: dateJour },
      },
    });
    if (existant) {
      throw new ConflictException(`DOUBLON:${existant.id}`);
    }
    await (this.prisma as any).notification.create({
      data: {
        entrepriseId: data.entrepriseId || "c1b035b8-c2d5-4b84-a07e-2a3d503fb96c",
        type: "nouveau_releve",
        titre: "Nouveau relevé abatteur",
        message: `${data.operateur} — ${data.lotId} — ${Math.round(data.volTotal*10)/10} m³`,
        lien: data.lotId,
      },
    });
    return (this.prisma as any).releveAbatteur.create({ data });
  }

  async updateAbatteur(id: string, data: any, operateur: string, etfNom: string) {
    const ancien = await (this.prisma as any).releveAbatteur.findUnique({ where: { id } });
    if (!ancien) throw new Error('Relevé introuvable');
    const champs = ['nbTas','longueur','largeur','hauteur','meteo','incident','temps','volTotal','poidsTotal'];
    for (const champ of champs) {
      if (data[champ] !== undefined && String(data[champ]) !== String((ancien as any)[champ]||'')) {
        await (this.prisma as any).modificationReleve.create({
          data: {
            releveId: id,
            typeReleve: 'abatteur',
            lotId: ancien.lotId,
            lotNumero: data.lotNumero || ancien.lotId,
            operateur,
            etfNom,
            champ,
            ancienneVal: String((ancien as any)[champ] ?? ''),
            nouvelleVal: String(data[champ] ?? ''),
          },
        });
      }
    }
    await (this.prisma as any).notification.create({
      data: {
        entrepriseId: data.entrepriseId || "c1b035b8-c2d5-4b84-a07e-2a3d503fb96c",
        type: "modification_releve",
        titre: "⚠ Relevé modifié",
        message: `${operateur} (${etfNom}) a modifié son relevé du lot ${ancien.lotId}`,
        lien: ancien.lotId,
      },
    });
    return (this.prisma as any).releveAbatteur.update({
      where: { id },
      data: {
        nbTas: data.nbTas,
        longueur: data.longueur,
        largeur: data.largeur,
        hauteur: data.hauteur,
        meteo: data.meteo,
        incident: data.incident,
        temps: data.temps,
        volTotal: data.volTotal,
        poidsTotal: data.poidsTotal,
      },
    });
  }

  async createDebardeur(data: any) {
    const dateJour = new Date(data.date).toISOString().slice(0,10);
    const existant = await (this.prisma as any).releveDebardeur.findFirst({
      where: {
        lotId: data.lotId,
        operateur: data.operateur,
        date: { startsWith: dateJour },
      },
    });
    if (existant) {
      throw new ConflictException(`DOUBLON:${existant.id}`);
    }
    await (this.prisma as any).notification.create({
      data: {
        entrepriseId: data.entrepriseId || "c1b035b8-c2d5-4b84-a07e-2a3d503fb96c",
        type: "nouveau_releve",
        titre: "Nouveau relevé débardeur",
        message: `${data.operateur} — ${data.lotId} — ${Math.round(data.volTotal*10)/10} m³`,
        lien: data.lotId,
      },
    });
    return (this.prisma as any).releveDebardeur.create({ data });
  }

  findAbatteurByLot(lotId: string) {
    return (this.prisma as any).releveAbatteur.findMany({
      where: { lotId },
      orderBy: { createdAt: 'desc' },
    });
  }

  findDebardeurByLot(lotId: string) {
    return (this.prisma as any).releveDebardeur.findMany({
      where: { lotId },
      orderBy: { createdAt: 'desc' },
    });
  }

  findNotifications(entrepriseId: string) {
    return (this.prisma as any).notification.findMany({
      where: { entrepriseId, lu: false },
      orderBy: { createdAt: 'desc' },
    });
  }

  async marquerLu(id: string) {
    return (this.prisma as any).notification.update({
      where: { id },
      data: { lu: true },
    });
  }
}
