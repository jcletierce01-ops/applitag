# APPLITAG — Cahier des charges UX/UI
*Version 1.0 — 17 juin 2026*

---

## Règle absolue
> Simplicité terrain + rapidité d'exécution + lisibilité opérationnelle

### Contexte d'usage
- En forêt
- Dans des engins
- Au téléphone avec des gants
- Parfois sans réseau
- Souvent sous pression opérationnelle

### Principes UX
- Très gros boutons (min 56px)
- Peu de saisie clavier
- Menus simples
- Logique verticale
- Accès rapide caméra/GPS
- Maximum 3 clics pour toute action terrain
- Fonctionnement hors ligne

---

## Deux applications

| Application | Utilisateurs | Fonctions |
|-------------|-------------|-----------|
| **MOBILE** | Opérateurs, ETF, Chauffeurs, Broyage, Terrain | Actions terrain, relevés, transport |
| **WEB** | Exploitants, Supervision, Admin, Reporting | Cartographie, analytics, gestion |

---

## UX MOBILE

### Barre de navigation basse
```
[ Accueil ] [ Lots ] [ Carte ] [ Alertes ] [ Profil ]
```

---

### 1. Écran Accueil
**Objectif :** Vue immédiate des actions à faire

Cartes visibles :
- Lots à visiter
- Chantiers du jour
- Transports en cours
- Livraisons attendues
- Alertes critiques

Bouton principal : **+ NOUVEAU LOT**

---

### 2. Écran Liste Lots

**Filtres rapides :**
Tous | À visiter | Exploitation | Bord route | Transport | Livré

**Carte lot affiche :**
- Numéro lot
- Commune
- Statut (couleur)
- Volume
- Humidité
- Progression
- Date

**Couleurs statut :**

| Statut | Couleur |
|--------|---------|
| À visiter | 🟠 Orange |
| Exploitation | 🔵 Bleu |
| Bord route | 🟤 Marron |
| Transport | 🟣 Violet |
| Livré | 🟢 Vert |
| Alerte | 🔴 Rouge |

---

### 3. Écran Fiche Lot ⭐ (écran le plus important)

**En-tête :**
```
LOT FR-89-2026-0154
EN EXPLOITATION
```

**Infos rapides :** commune, propriétaire, volume, humidité, GPS, certification

**Onglets :**
1. **Vue générale** — progression chantier, timeline, carte, alertes
2. **Parcelles** — cartes GPS, accès, contraintes
3. **Tas** — liste tas, volumes, photos
4. **Transport** — camions, chauffeurs, CMR
5. **Livraisons** — chaufferie, pesées, humidité
6. **Documents** — PDF, photos, signatures

---

### 4. Écran Visite Terrain

**GPS :** Bouton → CAPTURER POSITION

**Photos :** Bouton énorme → PRENDRE PHOTO

**Essences :** Choix rapide — chêne / hêtre / résineux / mélange / autre

**Volume :** Slider ou pavé numérique

**Contraintes :** Cases à cocher — pente / ligne EDF / accès difficile / zone humide / voisinage

**Validation :** Bouton fixe bas écran → **VALIDER VISITE**

---

### 5. Écran Suivi Chantier

**Action rapide :** + AJOUTER TAS

**Carte TAS :** photo, GPS, volume, essence, humidité

**Boutons rapides :** INCIDENT | FIN DE SERVICE

---

### 6. Écran Déchiquetage

**Étapes visuelles :**
1. Sélection lot
2. Sélection tas
3. Camion
4. CMR
5. Validation départ

**Actions caméra :** scan CMR / photo camion / photo chargement

---

### 7. Écran Chauffeur (ultra minimaliste)

```
LOT : FR-89-2026-0154
DESTINATION : Chaufferie Auxerre
```

Boutons :
- **ACCEPTER MISSION**
- **DÉPART**
- **ARRIVÉ SUR SITE**

---

### 8. Écran Livraison

**Informations visibles :** destination, GPS attendu, chauffeur, CMR

**Saisie :** poids, humidité, commentaire

**Validation :** → **VALIDER LIVRAISON**

---

## UX WEB — Backoffice

### Tableau de bord
Widgets :
- Tonnage du jour
- Transports en cours
- Humidité moyenne
- Taux livraison
- Alertes ouvertes
- Carte temps réel

### Carte centrale
Affichage : lots / tas / camions / livraisons / plateformes / chaufferies

### Timeline lot
```
Création → Visite → Exploitation → Tas validés
→ Déchiquetage → Transport → Livraison → Clôture
```

---

## État d'avancement

| Écran Mobile | Statut |
|-------------|--------|
| Login QR + PIN | ✅ Fait |
| Fiche 0 contact | ✅ Fait |
| Visite terrain (6 étapes) | ✅ Fait |
| Relevés opérateur | ✅ Fait |
| Notifications/Alertes | ✅ Fait |
| Accueil (dashboard) | 🔲 À faire |
| Liste lots + filtres | 🔲 À faire |
| Fiche lot (onglets) | 🔲 À faire |
| Validation exploitation | 🔲 À faire |
| Clôture exploitation | 🔲 À faire |
| Déchiquetage | 🔲 À faire |
| Chauffeur | 🔲 À faire |
| Livraison | 🔲 À faire |
| Carte mobile | 🔲 À faire |
| Documents | 🔲 À faire |

| Écran Web | Statut |
|-----------|--------|
| Dashboard | 🔲 À faire |
| Carte centrale | 🔲 À faire |
| Timeline lot | 🔲 À faire |
| Reporting | 🔲 À faire |
| Administration | 🔲 À faire |
